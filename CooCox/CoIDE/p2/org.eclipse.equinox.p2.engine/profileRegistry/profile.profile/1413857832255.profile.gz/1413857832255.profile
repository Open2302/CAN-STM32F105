<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='profile' timestamp='1413857832255'>
  <properties size='6'>
    <property name='org.eclipse.equinox.p2.installFolder' value='E:\Inno setup\export\CoIDE'/>
    <property name='org.eclipse.equinox.p2.cache' value='E:\Inno setup\export\CoIDE'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='false'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.nl=zh_CN,osgi.ws=win32,osgi.arch=x86,osgi.os=win32'/>
    <property name='eclipse.touchpoint.launcherName' value='CoIDE.exe'/>
  </properties>
  <units size='170'>
    <unit id='a.jre.javase' version='1.6.0' singleton='false'>
      <provides size='159'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='a.jre.javase' version='1.6.0'/>
        <provided namespace='java.package' name='javax.accessibility' version='0.0.0'/>
        <provided namespace='java.package' name='javax.activation' version='0.0.0'/>
        <provided namespace='java.package' name='javax.activity' version='0.0.0'/>
        <provided namespace='java.package' name='javax.annotation' version='0.0.0'/>
        <provided namespace='java.package' name='javax.annotation.processing' version='0.0.0'/>
        <provided namespace='java.package' name='javax.crypto' version='0.0.0'/>
        <provided namespace='java.package' name='javax.crypto.interfaces' version='0.0.0'/>
        <provided namespace='java.package' name='javax.crypto.spec' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.event' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.metadata' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.plugins.bmp' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.plugins.jpeg' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.stream' version='0.0.0'/>
        <provided namespace='java.package' name='javax.jws' version='0.0.0'/>
        <provided namespace='java.package' name='javax.jws.soap' version='0.0.0'/>
        <provided namespace='java.package' name='javax.lang.model' version='0.0.0'/>
        <provided namespace='java.package' name='javax.lang.model.element' version='0.0.0'/>
        <provided namespace='java.package' name='javax.lang.model.type' version='0.0.0'/>
        <provided namespace='java.package' name='javax.lang.model.util' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.loading' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.modelmbean' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.monitor' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.openmbean' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.relation' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.remote' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.remote.rmi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.timer' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming.directory' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming.event' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming.ldap' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.net' version='0.0.0'/>
        <provided namespace='java.package' name='javax.net.ssl' version='0.0.0'/>
        <provided namespace='java.package' name='javax.print' version='0.0.0'/>
        <provided namespace='java.package' name='javax.print.attribute' version='0.0.0'/>
        <provided namespace='java.package' name='javax.print.attribute.standard' version='0.0.0'/>
        <provided namespace='java.package' name='javax.print.event' version='0.0.0'/>
        <provided namespace='java.package' name='javax.rmi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.rmi.CORBA' version='0.0.0'/>
        <provided namespace='java.package' name='javax.rmi.ssl' version='0.0.0'/>
        <provided namespace='java.package' name='javax.script' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.callback' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.kerberos' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.login' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.x500' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.cert' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.sasl' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sound.midi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sound.midi.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sound.sampled' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sound.sampled.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sql' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sql.rowset' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sql.rowset.serial' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sql.rowset.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.border' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.colorchooser' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.event' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.filechooser' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf.basic' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf.metal' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf.multi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf.synth' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.table' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.text' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.text.html' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.text.html.parser' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.text.rtf' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.tree' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.undo' version='0.0.0'/>
        <provided namespace='java.package' name='javax.tools' version='0.0.0'/>
        <provided namespace='java.package' name='javax.transaction' version='0.0.0'/>
        <provided namespace='java.package' name='javax.transaction.xa' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.bind' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.bind.annotation' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.bind.annotation.adapters' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.bind.attachment' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.bind.helpers' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.bind.util' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dom' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dsig' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dsig.dom' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dsig.keyinfo' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dsig.spec' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.datatype' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.namespace' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.parsers' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.soap' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.stream' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.stream.events' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.stream.util' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform.dom' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform.sax' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform.stax' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform.stream' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.validation' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.ws' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.ws.handler' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.ws.handler.soap' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.ws.http' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.ws.soap' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.ws.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.ws.wsaddressing' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.xpath' version='0.0.0'/>
        <provided namespace='java.package' name='org.ietf.jgss' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.CORBA' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.CORBA_2_3' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.CORBA_2_3.portable' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.CORBA.DynAnyPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.CORBA.ORBPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.CORBA.portable' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.CORBA.TypeCodePackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.CosNaming' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.CosNaming.NamingContextExtPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.CosNaming.NamingContextPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.Dynamic' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.DynamicAny' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.DynamicAny.DynAnyFactoryPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.DynamicAny.DynAnyPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.IOP' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.IOP.CodecFactoryPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.IOP.CodecPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.Messaging' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.PortableInterceptor' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.PortableInterceptor.ORBInitInfoPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.PortableServer' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.PortableServer.CurrentPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.PortableServer.POAManagerPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.PortableServer.POAPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.PortableServer.portable' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.PortableServer.ServantLocatorPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.SendingContext' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.stub.java.rmi' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.bootstrap' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.css' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.events' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.html' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.ls' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.ranges' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.stylesheets' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.traversal' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.views' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.xpath' version='0.0.0'/>
        <provided namespace='java.package' name='org.xml.sax' version='0.0.0'/>
        <provided namespace='java.package' name='org.xml.sax.ext' version='0.0.0'/>
        <provided namespace='java.package' name='org.xml.sax.helpers' version='0.0.0'/>
      </provides>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
    </unit>
    <unit id='com.ibm.icu' version='4.4.2.v20110823'>
      <update id='com.ibm.icu' range='[0.0.0,4.4.2.v20110823)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='International Components for Unicode for Java (ICU4J)'/>
        <property name='df_LT.providerName' value='IBM Corporation'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='21'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='com.ibm.icu' version='4.4.2.v20110823'/>
        <provided namespace='osgi.bundle' name='com.ibm.icu' version='4.4.2.v20110823'/>
        <provided namespace='java.package' name='com.ibm.icu.lang' version='4.4.2.2'/>
        <provided namespace='java.package' name='com.ibm.icu.math' version='4.4.2.2'/>
        <provided namespace='java.package' name='com.ibm.icu.text' version='4.4.2.2'/>
        <provided namespace='java.package' name='com.ibm.icu.util' version='4.4.2.2'/>
        <provided namespace='java.package' name='com.ibm.icu.impl' version='0.0.0'/>
        <provided namespace='java.package' name='com.ibm.icu.impl.data' version='0.0.0'/>
        <provided namespace='java.package' name='com.ibm.icu.impl.data.icudt44b' version='0.0.0'/>
        <provided namespace='java.package' name='com.ibm.icu.impl.data.icudt44b.brkitr' version='0.0.0'/>
        <provided namespace='java.package' name='com.ibm.icu.impl.data.icudt44b.coll' version='0.0.0'/>
        <provided namespace='java.package' name='com.ibm.icu.impl.data.icudt44b.curr' version='0.0.0'/>
        <provided namespace='java.package' name='com.ibm.icu.impl.data.icudt44b.lang' version='0.0.0'/>
        <provided namespace='java.package' name='com.ibm.icu.impl.data.icudt44b.rbnf' version='0.0.0'/>
        <provided namespace='java.package' name='com.ibm.icu.impl.data.icudt44b.region' version='0.0.0'/>
        <provided namespace='java.package' name='com.ibm.icu.impl.data.icudt44b.translit' version='0.0.0'/>
        <provided namespace='java.package' name='com.ibm.icu.impl.data.icudt44b.zone' version='0.0.0'/>
        <provided namespace='java.package' name='com.ibm.icu.impl.duration' version='0.0.0'/>
        <provided namespace='java.package' name='com.ibm.icu.impl.locale' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='com.ibm.icu' version='4.4.2.v20110823'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: com.ibm.icu; singleton:=true&#xA;Bundle-Version: 4.4.2.v20110823
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='config.a.jre.javase' version='1.6.0' singleton='false'>
      <hostRequirements size='1'>
        <required namespace='org.eclipse.equinox.p2.iu' name='a.jre.javase' range='1.6.0'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='config.a.jre.javase' version='1.6.0'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.iu' name='a.jre.javase' range='1.6.0'/>
      </requires>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='install'>

          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='coocox_model_bundle' version='1.0.0' singleton='false'>
      <update id='coocox_model_bundle' range='[0.0.0,1.0.0)' severity='0'/>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.name' value='Coocox_model_bundle'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='coocox_model_bundle' version='1.0.0'/>
        <provided namespace='osgi.bundle' name='coocox_model_bundle' version='1.0.0'/>
        <provided namespace='java.package' name='org.coocox.codb.common.dto' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.codb.common.exception' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.codb.common.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.codb.common.model.stat' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.codb.common.vo' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='coocox_model_bundle' version='1.0.0'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: coocox_model_bundle&#xA;Bundle-Version: 1.0.0
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='javax.servlet' version='2.5.0.v201103041518' singleton='false'>
      <update id='javax.servlet' range='[0.0.0,2.5.0.v201103041518)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.bundleProvider' value='Eclipse.org'/>
        <property name='df_LT.bundleName' value='Servlet API Bundle'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleProvider'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='javax.servlet' version='2.5.0.v201103041518'/>
        <provided namespace='osgi.bundle' name='javax.servlet' version='2.5.0.v201103041518'/>
        <provided namespace='java.package' name='javax.servlet' version='2.5.0'/>
        <provided namespace='java.package' name='javax.servlet.http' version='2.5.0'/>
        <provided namespace='java.package' name='javax.servlet.resources' version='2.5.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='javax.servlet' version='2.5.0.v201103041518'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: javax.servlet&#xA;Bundle-Version: 2.5.0.v201103041518
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='javax.servlet.jsp' version='2.0.0.v201101211617' singleton='false'>
      <update id='javax.servlet.jsp' range='[0.0.0,2.0.0.v201101211617)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.bundleProvider' value='Eclipse.org'/>
        <property name='df_LT.bundleName' value='Java Server Pages API Bundle'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleProvider'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='javax.servlet.jsp' version='2.0.0.v201101211617'/>
        <provided namespace='osgi.bundle' name='javax.servlet.jsp' version='2.0.0.v201101211617'/>
        <provided namespace='java.package' name='javax.servlet.jsp' version='2.0.0'/>
        <provided namespace='java.package' name='javax.servlet.jsp.el' version='2.0.0'/>
        <provided namespace='java.package' name='javax.servlet.jsp.resources' version='2.0.0'/>
        <provided namespace='java.package' name='javax.servlet.jsp.tagext' version='2.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='java.package' name='javax.servlet' range='2.4.0'/>
        <required namespace='java.package' name='javax.servlet.http' range='2.4.0'/>
        <required namespace='java.package' name='javax.servlet.resources' range='2.4.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='javax.servlet.jsp' version='2.0.0.v201101211617'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: javax.servlet.jsp&#xA;Bundle-Version: 2.0.0.v201101211617
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.ant' version='1.8.2.v20120109-1030' singleton='false'>
      <update id='org.apache.ant' range='[0.0.0,1.8.2.v20120109-1030)' severity='0'/>
      <properties size='4'>
        <property name='df_LT.Bundle-Name' value='Apache Ant'/>
        <property name='df_LT.Bundle-Vendor' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%Bundle-Name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%Bundle-Vendor'/>
      </properties>
      <provides size='74'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.ant' version='1.8.2.v20120109-1030'/>
        <provided namespace='osgi.bundle' name='org.apache.ant' version='1.8.2.v20120109-1030'/>
        <provided namespace='java.package' name='org.apache.tools.ant' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.dispatch' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.filters' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.filters.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.helper' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.input' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.launch' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.listener' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.loader' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.property' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.compilers' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.condition' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.cvslib' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.email' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.ccm' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.clearcase' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.depend' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.depend.constantpool' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.ejb' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.extension' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.extension.resolvers' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.i18n' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.image' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.j2ee' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.javacc' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.javah' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.jdepend' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.jlink' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.jsp' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.jsp.compilers' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.junit' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.native2ascii' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.net' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.perforce' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.pvcs' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.script' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.sos' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.sound' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.splash' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.ssh' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.testing' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.unix' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.vss' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.windows' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.rmic' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.types' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.types.mappers' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.types.optional' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.types.optional.depend' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.types.optional.image' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.types.resolver' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.types.resources' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.types.resources.comparators' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.types.resources.selectors' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.types.selectors' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.types.selectors.modifiedselector' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.types.spi' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.util.depend' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.util.depend.bcel' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.util.facade' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.util.java15' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.util.optional' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.util.regexp' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.bzip2' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.mail' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.tar' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.zip' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.ant' version='1.8.2.v20120109-1030'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='zipped'>
            true
          </instruction>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.ant&#xA;Bundle-Version: 1.8.2.v20120109-1030
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.commons.el' version='1.0.0.v201101211617' singleton='false'>
      <update id='org.apache.commons.el' range='[0.0.0,1.0.0.v201101211617)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.bundleProvider' value='Eclipse.org'/>
        <property name='df_LT.bundleName' value='Apache Commons JSP 2.0 Expression Language Interpreter'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleProvider'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.el' version='1.0.0.v201101211617'/>
        <provided namespace='osgi.bundle' name='org.apache.commons.el' version='1.0.0.v201101211617'/>
        <provided namespace='java.package' name='org.apache.commons.el' version='1.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.el.parser' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='java.package' name='javax.servlet' range='[2.4.0,3.0.0)'/>
        <required namespace='java.package' name='javax.servlet.http' range='[2.4.0,3.0.0)'/>
        <required namespace='java.package' name='javax.servlet.jsp' range='[2.0.0,2.1.0)'/>
        <required namespace='java.package' name='javax.servlet.jsp.el' range='[2.0.0,2.1.0)'/>
        <required namespace='java.package' name='javax.servlet.jsp.resources' range='[2.0.0,2.1.0)'/>
        <required namespace='java.package' name='javax.servlet.jsp.tagext' range='[2.0.0,2.1.0)'/>
        <required namespace='java.package' name='javax.servlet.resources' range='[2.4.0,3.0.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.commons.el' version='1.0.0.v201101211617'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.commons.el&#xA;Bundle-Version: 1.0.0.v201101211617
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.commons.logging' version='1.0.4.v201101211617' singleton='false'>
      <update id='org.apache.commons.logging' range='[0.0.0,1.0.4.v201101211617)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.bundleProvider' value='Eclipse Orbit'/>
        <property name='df_LT.bundleName' value='Apache Commons Logging Plug-in'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleProvider'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.logging' version='1.0.4.v201101211617'/>
        <provided namespace='osgi.bundle' name='org.apache.commons.logging' version='1.0.4.v201101211617'/>
        <provided namespace='java.package' name='org.apache.commons.logging' version='1.0.4'/>
        <provided namespace='java.package' name='org.apache.commons.logging.impl' version='1.0.4'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.commons.logging' version='1.0.4.v201101211617'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.commons.logging&#xA;Bundle-Version: 1.0.4.v201101211617
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.jasper' version='5.5.17.v201101211617' singleton='false'>
      <update id='org.apache.jasper' range='[0.0.0,5.5.17.v201101211617)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.bundleProvider' value='Eclipse.org'/>
        <property name='df_LT.bundleName' value='Apache Jasper 2 Plug-in'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleProvider'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='15'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.jasper' version='5.5.17.v201101211617'/>
        <provided namespace='osgi.bundle' name='org.apache.jasper' version='5.5.17.v201101211617'/>
        <provided namespace='java.package' name='org.apache.jasper' version='5.5.17'/>
        <provided namespace='java.package' name='org.apache.jasper.compiler' version='5.5.17'/>
        <provided namespace='java.package' name='org.apache.jasper.compiler.tagplugin' version='5.5.17'/>
        <provided namespace='java.package' name='org.apache.jasper.resources' version='5.5.17'/>
        <provided namespace='java.package' name='org.apache.jasper.runtime' version='5.5.17'/>
        <provided namespace='java.package' name='org.apache.jasper.security' version='5.5.17'/>
        <provided namespace='java.package' name='org.apache.jasper.servlet' version='5.5.17'/>
        <provided namespace='java.package' name='org.apache.jasper.tagplugins.jstl' version='5.5.17'/>
        <provided namespace='java.package' name='org.apache.jasper.tagplugins.jstl.core' version='5.5.17'/>
        <provided namespace='java.package' name='org.apache.jasper.util' version='5.5.17'/>
        <provided namespace='java.package' name='org.apache.jasper.xmlparser' version='5.5.17'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='18'>
        <required namespace='java.package' name='javax.servlet' range='[2.4.0,3.0.0)'/>
        <required namespace='java.package' name='javax.servlet.http' range='[2.4.0,3.0.0)'/>
        <required namespace='java.package' name='javax.servlet.jsp' range='[2.0.0,2.1.0)'/>
        <required namespace='java.package' name='javax.servlet.jsp.el' range='[2.0.0,2.1.0)'/>
        <required namespace='java.package' name='javax.servlet.jsp.resources' range='[2.0.0,2.1.0)'/>
        <required namespace='java.package' name='javax.servlet.jsp.tagext' range='[2.0.0,2.1.0)'/>
        <required namespace='java.package' name='javax.servlet.resources' range='[2.4.0,3.0.0)'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.apache.commons.el' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.apache.commons.logging' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.apache.tools.ant' range='0.0.0' optional='true'/>
        <required namespace='java.package' name='org.apache.tools.ant.taskdefs' range='0.0.0' optional='true'/>
        <required namespace='java.package' name='org.apache.tools.ant.types' range='0.0.0' optional='true'/>
        <required namespace='java.package' name='org.apache.tools.ant.util' range='0.0.0' optional='true'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.ext' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.jasper' version='5.5.17.v201101211617'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.jasper&#xA;Bundle-Version: 5.5.17.v201101211617
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.lucene' version='2.9.1.v201101211721' singleton='false'>
      <update id='org.apache.lucene' range='[0.0.0,2.9.1.v201101211721)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Apache Lucene'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='19'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.lucene' version='2.9.1.v201101211721'/>
        <provided namespace='osgi.bundle' name='org.apache.lucene' version='2.9.1.v201101211721'/>
        <provided namespace='java.package' name='org.apache.lucene' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis.standard' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis.tokenattributes' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.document' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.index' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.messages' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.queryParser' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.search' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.search.function' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.search.payloads' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.search.spans' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.store' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.util' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.util.cache' version='2.9.1'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='osgi.bundle' name='org.apache.lucene.core' range='[2.9.1,3.0.0)'/>
        <required namespace='osgi.bundle' name='org.apache.lucene.analysis' range='[2.9.1,3.0.0)' optional='true'/>
        <required namespace='osgi.bundle' name='org.apache.lucene.highlighter' range='[2.9.1,3.0.0)' optional='true'/>
        <required namespace='osgi.bundle' name='org.apache.lucene.memory' range='[2.9.1,3.0.0)' optional='true'/>
        <required namespace='osgi.bundle' name='org.apache.lucene.queries' range='[2.9.1,3.0.0)' optional='true'/>
        <required namespace='osgi.bundle' name='org.apache.lucene.snowball' range='[2.9.1,3.0.0)' optional='true'/>
        <required namespace='osgi.bundle' name='org.apache.lucene.spellchecker' range='[2.9.1,3.0.0)' optional='true'/>
        <required namespace='osgi.bundle' name='org.apache.lucene.misc' range='[2.9.1,3.0.0)' optional='true'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.lucene' version='2.9.1.v201101211721'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.lucene&#xA;Bundle-Version: 2.9.1.v201101211721
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.lucene.analysis' version='2.9.1.v201101211721' singleton='false'>
      <update id='org.apache.lucene.analysis' range='[0.0.0,2.9.1.v201101211721)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Apache Lucene Analysis'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='26'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.lucene.analysis' version='2.9.1.v201101211721'/>
        <provided namespace='osgi.bundle' name='org.apache.lucene.analysis' version='2.9.1.v201101211721'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis.ar' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis.br' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis.cjk' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis.cn' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis.compound' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis.compound.hyphenation' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis.cz' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis.de' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis.el' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis.fa' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis.fr' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis.miscellaneous' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis.ngram' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis.nl' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis.payloads' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis.position' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis.query' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis.reverse' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis.ru' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis.shingle' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis.sinks' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis.th' version='2.9.1'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.apache.lucene.core' range='[2.9.1,3.0.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.lucene.analysis' version='2.9.1.v201101211721'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.lucene.analysis&#xA;Bundle-Version: 2.9.1.v201101211721
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.lucene.core' version='2.9.1.v201101211721' singleton='false'>
      <update id='org.apache.lucene.core' range='[0.0.0,2.9.1.v201101211721)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.bundle.name' value='Apache Lucene Core'/>
        <property name='df_LT.provider.name' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundle.name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%provider.name'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='19'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.lucene.core' version='2.9.1.v201101211721'/>
        <provided namespace='osgi.bundle' name='org.apache.lucene.core' version='2.9.1.v201101211721'/>
        <provided namespace='java.package' name='org.apache.lucene' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis.standard' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis.tokenattributes' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.document' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.index' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.messages' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.queryParser' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.search' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.search.function' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.search.payloads' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.search.spans' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.store' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.util' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.util.cache' version='2.9.1'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.lucene.core' version='2.9.1.v201101211721'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.lucene.core&#xA;Bundle-Version: 2.9.1.v201101211721
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.coocox.builder.core' version='1.0.0.201410211009'>
      <update id='org.coocox.builder.core' range='[0.0.0,1.0.0.201410211009)' severity='0'/>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.name' value='CooCox Builder Core'/>
        <property name='org.eclipse.equinox.p2.provider' value='CooCox'/>
      </properties>
      <provides size='4'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.coocox.builder.core' version='1.0.0.201410211009'/>
        <provided namespace='osgi.bundle' name='org.coocox.builder.core' version='1.0.0.201410211009'/>
        <provided namespace='java.package' name='org.coocox.builder.core' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='4'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ant.core' range='3.2.302'/>
        <required namespace='osgi.bundle' name='org.apache.ant' range='1.8.2'/>
        <required namespace='java.package' name='org.coocox.utils.tool' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.coocox.builder.core' version='1.0.0.201410211009'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.coocox.builder.core;singleton:=true&#xA;Bundle-Version: 1.0.0.201410211009
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.coocox.builder.ui' version='1.0.0.201410211009'>
      <update id='org.coocox.builder.ui' range='[0.0.0,1.0.0.201410211009)' severity='0'/>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.name' value='CooCox Builder UI'/>
        <property name='org.eclipse.equinox.p2.provider' value='CooCox'/>
      </properties>
      <provides size='17'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.coocox.builder.ui' version='1.0.0.201410211009'/>
        <provided namespace='osgi.bundle' name='org.coocox.builder.ui' version='1.0.0.201410211009'/>
        <provided namespace='java.package' name='org.coocox.builder.ui' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.builder.ui.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.builder.ui.config' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.builder.ui.config.control' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.builder.ui.config.editor' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.builder.ui.config_debug' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.builder.ui.console' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.builder.ui.listener' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.builder.ui.persistent' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.builder.ui.project' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.builder.ui.project.manage' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.builder.ui.project.newdriver' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.builder.ui.statusLine' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.builder.ui.views' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='39'>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.forms' range='3.5.101'/>
        <required namespace='osgi.bundle' name='org.coocox.builder.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.console' range='3.5.100'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface.text' range='3.7.2'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filesystem' range='1.3.100'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='3.7.101'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.editors' range='3.7.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.navigator' range='3.5.101'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.navigator.resources' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.ui' range='5.3.2'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.core' range='5.3.2'/>
        <required namespace='osgi.bundle' name='org.coocox.coassistant' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.codebugger.configuration' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.utils' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.ceditor.patch' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.device.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.component.front.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.model.control' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.model' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.ide' range='3.7.0'/>
        <required namespace='osgi.bundle' name='org.coocox.codebugger.gdbjtag.ui' range='5.0.100'/>
        <required namespace='osgi.bundle' name='org.coocox.codebugger.gdbjtag.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ltk.ui.refactoring' range='3.6.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ltk.core.refactoring' range='3.5.201'/>
        <required namespace='osgi.bundle' name='org.coocox.component.board.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.customize' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.user.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='coocox_model_bundle' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='3.4.300'/>
        <required namespace='osgi.bundle' name='org.eclipse.debug.ui' range='3.7.102'/>
        <required namespace='osgi.bundle' name='org.coocox.codb.client.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.converter.core' range='1.0.0'/>
        <required namespace='java.package' name='org.coocox.coassistant.view' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.codb.common.util' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.codebugger.gdbjtag.core' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.codebugger.internal.api' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.debug.core' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.coocox.builder.ui' version='1.0.0.201410211009'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.coocox.builder.ui;singleton:=true&#xA;Bundle-Version: 1.0.0.201410211009
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.coocox.ceditor.patch' version='1.0.0.201410211009'>
      <update id='org.coocox.ceditor.patch' range='[0.0.0,1.0.0.201410211009)' severity='0'/>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.name' value='Patch'/>
      </properties>
      <provides size='4'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.coocox.ceditor.patch' version='1.0.0.201410211009'/>
        <provided namespace='osgi.bundle' name='org.coocox.ceditor.patch' version='1.0.0.201410211009'/>
        <provided namespace='java.package' name='org.coocox.ceditor.api' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='3.7.101'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.core' range='5.3.2'/>
        <required namespace='osgi.bundle' name='org.coocox.builder.core' range='1.0.0'/>
        <required namespace='java.package' name='org.coocox.utils.tool' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.coocox.ceditor.patch' version='1.0.0.201410211009'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.coocox.ceditor.patch;singleton:=true&#xA;Bundle-Version: 1.0.0.201410211009
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.coocox.coassistant' version='1.0.0.201410211009' singleton='false'>
      <update id='org.coocox.coassistant' range='[0.0.0,1.0.0.201410211009)' severity='0'/>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.name' value='Coassistant'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.coocox.coassistant' version='1.0.0.201410211009'/>
        <provided namespace='osgi.bundle' name='org.coocox.coassistant' version='1.0.0.201410211009'/>
        <provided namespace='java.package' name='org.coocox.coassistant.commands' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.coassistant.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.coassistant.view' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='13'>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.forms' range='3.5.101'/>
        <required namespace='osgi.bundle' name='org.eclipse.debug.ui' range='3.7.102'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.debug.core' range='7.1.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.debug.mi.core' range='7.1.1'/>
        <required namespace='osgi.bundle' name='org.coocox.utils' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.model.control' range='1.0.0'/>
        <required namespace='java.package' name='org.coocox.codb.common.util' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.device.core' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.sqlite.dao' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.sqlite.dao.impl' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.cdt.debug.ui.memory.memorybrowser' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.coocox.coassistant' version='1.0.0.201410211009'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.coocox.coassistant&#xA;Bundle-Version: 1.0.0.201410211009
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.coocox.codb.client.core' version='1.0.0.201410211009' singleton='false'>
      <update id='org.coocox.codb.client.core' range='[0.0.0,1.0.0.201410211009)' severity='0'/>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.name' value='CoDB Client Core'/>
        <property name='org.eclipse.equinox.p2.provider' value='CooCox'/>
      </properties>
      <provides size='11'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.coocox.codb.client.core' version='1.0.0.201410211009'/>
        <provided namespace='osgi.bundle' name='org.coocox.codb.client.core' version='1.0.0.201410211009'/>
        <provided namespace='java.package' name='org.apache.commons.httpclient' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.codb.client.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.codb.client.core.api' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.codb.client.core.api.impl' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.codb.client.core.exception' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.codb.client.core.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.codb.client.core.service' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.codb.client.core.task' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.codb.common.util' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.junit4' range='4.8.1'/>
        <required namespace='osgi.bundle' name='org.coocox.codb.common.protocol' range='1.0.0'/>
        <required namespace='osgi.bundle' name='coocox_model_bundle' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.sqlite.rn' range='1.0.0'/>
        <required namespace='java.package' name='org.coocox.utils' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.coocox.codb.client.core' version='1.0.0.201410211009'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.coocox.codb.client.core&#xA;Bundle-Version: 1.0.0.201410211009
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.coocox.codb.common.protocol' version='1.0.0.201410211009' singleton='false'>
      <update id='org.coocox.codb.common.protocol' range='[0.0.0,1.0.0.201410211009)' severity='0'/>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.name' value='CoDB C/S Protocol'/>
        <property name='org.eclipse.equinox.p2.provider' value='CooCox'/>
      </properties>
      <provides size='4'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.coocox.codb.common.protocol' version='1.0.0.201410211009'/>
        <provided namespace='osgi.bundle' name='org.coocox.codb.common.protocol' version='1.0.0.201410211009'/>
        <provided namespace='java.package' name='org.coocox.codb.common.protocol' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.coocox.codb.common.protocol' version='1.0.0.201410211009'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.coocox.codb.common.protocol&#xA;Bundle-Version: 1.0.0.201410211009
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.coocox.codb.common.util' version='1.0.0.201410211009'>
      <update id='org.coocox.codb.common.util' range='[0.0.0,1.0.0.201410211009)' severity='0'/>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.name' value='CoDB Util'/>
        <property name='org.eclipse.equinox.p2.provider' value='CooCox'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.coocox.codb.common.util' version='1.0.0.201410211009'/>
        <provided namespace='osgi.bundle' name='org.coocox.codb.common.util' version='1.0.0.201410211009'/>
        <provided namespace='java.package' name='org.codehaus.jackson' version='0.0.0'/>
        <provided namespace='java.package' name='org.codehaus.jackson.map' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.codb.common.util' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='coocox_model_bundle' range='1.0.0'/>
        <required namespace='java.package' name='org.apache.tools.zip' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.coocox.codb.common.util' version='1.0.0.201410211009'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.coocox.codb.common.util;singleton:=true&#xA;Bundle-Version: 1.0.0.201410211009
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.coocox.codebugger.configuration' version='1.0.0.201410211009'>
      <update id='org.coocox.codebugger.configuration' range='[0.0.0,1.0.0.201410211009)' severity='0'/>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.name' value='Configuration'/>
        <property name='org.eclipse.equinox.p2.provider' value='shiwei'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.coocox.codebugger.configuration' version='1.0.0.201410211009'/>
        <provided namespace='osgi.bundle' name='org.coocox.codebugger.configuration' version='1.0.0.201410211009'/>
        <provided namespace='java.package' name='org.coocox.codebugger.api' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.codebugger.configuration' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.codebugger.configuration.commands' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.codebugger.configuration.editor' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.codebugger.configuration.ui' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.codebugger.configuration.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.codebugger.internal.api' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='27'>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='3.7.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='3.7.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.forms' range='3.5.101'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.ide' range='3.7.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.debug.ui' range='7.1.2'/>
        <required namespace='osgi.bundle' name='org.eclipse.debug.ui' range='3.7.102'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.core' range='5.3.2'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.debug.mi.core' range='7.1.1'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.debug.core' range='7.1.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.dsf.ui' range='2.2.1'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.debug.ui.memory.memorybrowser' range='1.2.100'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.debug.ui.memory.search' range='1.2.1'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.debug.ui.memory.traditional' range='1.2.1'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.debug.ui.memory.transport' range='2.1.0'/>
        <required namespace='osgi.bundle' name='org.coocox.coassistant' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.device.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.codebugger.gdbjtag.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.utils' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.model.control' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.model' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.codebugger.console' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.codebugger.debug.gdbjtag.io' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.codebugger.gdbjtag.core' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.codebugger.gdbjtag.ui' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.emf.common.util' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.ui.console' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.ui.navigator' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.coocox.codebugger.configuration' version='1.0.0.201410211009'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.coocox.codebugger.configuration;singleton:=true&#xA;Bundle-Version: 1.0.0.201410211009
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.coocox.codebugger.gdbjtag.core' version='5.0.100.201410211009'>
      <update id='org.coocox.codebugger.gdbjtag.core' range='[0.0.0,5.0.100.201410211009)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse CDT'/>
        <property name='df_LT.pluginName' value='Eclipse GDB Hardware Debug Core Plug-in'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='14'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.coocox.codebugger.gdbjtag.core' version='5.0.100.201410211009'/>
        <provided namespace='osgi.bundle' name='org.coocox.codebugger.gdbjtag.core' version='5.0.100.201410211009'/>
        <provided namespace='java.package' name='org.apache.commons.codec' version='1.5.0'/>
        <provided namespace='java.package' name='org.apache.commons.codec.binary' version='1.5.0'/>
        <provided namespace='java.package' name='org.apache.commons.codec.digest' version='1.5.0'/>
        <provided namespace='java.package' name='org.apache.commons.codec.language' version='1.5.0'/>
        <provided namespace='java.package' name='org.apache.commons.codec.net' version='1.5.0'/>
        <provided namespace='java.package' name='org.coocox.codebugger.console' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.codebugger.debug.gdbjtag.io' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.codebugger.gdbjtag.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.codebugger.gdbjtag.core.jtagdevice' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.codebugger.gdbjtag.gdbLocation' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='21'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='3.7.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.debug.core' range='3.7.1'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.debug.core' range='7.1.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.debug.mi.core' range='7.1.1'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.core' range='5.3.2'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.launch' range='7.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.console' range='3.5.100'/>
        <required namespace='osgi.bundle' name='org.coocox.utils' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.device.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.model.control' range='1.0.0'/>
        <required namespace='java.package' name='org.coocox.codebugger.trace.socket' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.cdt.debug.ui' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.variables' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.jface.dialogs' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.jface.resource' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.jface.text' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.swt' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.swt.graphics' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.swt.widgets' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.ui' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.ui.progress' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.coocox.codebugger.gdbjtag.core' version='5.0.100.201410211009'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.coocox.codebugger.gdbjtag.core;singleton:=true&#xA;Bundle-Version: 5.0.100.201410211009
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.coocox.codebugger.gdbjtag.ui' version='5.0.100.201410211009'>
      <update id='org.coocox.codebugger.gdbjtag.ui' range='[0.0.0,5.0.100.201410211009)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse CDT'/>
        <property name='df_LT.pluginName' value='Eclipse GDB Hardware Debug UI Plug-in'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.coocox.codebugger.gdbjtag.ui' version='5.0.100.201410211009'/>
        <provided namespace='osgi.bundle' name='org.coocox.codebugger.gdbjtag.ui' version='5.0.100.201410211009'/>
        <provided namespace='java.package' name='org.coocox.codebugger.configuration.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.codebugger.gdbjtag.ui' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='18'>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='3.7.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='3.7.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.debug.ui' range='3.7.102'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.ui' range='5.3.2'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.variables' range='3.2.500'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.ide' range='3.7.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.debug.core' range='7.1.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.launch' range='7.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.debug.mi.core' range='7.1.1'/>
        <required namespace='osgi.bundle' name='org.coocox.codebugger.gdbjtag.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.device.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.utils' range='1.0.0'/>
        <required namespace='java.package' name='org.coocox.codebugger.debug.gdbjtag.io' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.codebugger.gdbjtag.core' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.cdt.core' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.cdt.core.model' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.cdt.core.settings.model' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.cdt.utils.pty' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.coocox.codebugger.gdbjtag.ui' version='5.0.100.201410211009'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.coocox.codebugger.gdbjtag.ui;singleton:=true&#xA;Bundle-Version: 5.0.100.201410211009
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.coocox.codebugger.trace.ui' version='1.0.0.201410211009'>
      <update id='org.coocox.codebugger.trace.ui' range='[0.0.0,1.0.0.201410211009)' severity='0'/>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.name' value='Ui'/>
        <property name='org.eclipse.equinox.p2.provider' value='shiwei'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.coocox.codebugger.trace.ui' version='1.0.0.201410211009'/>
        <provided namespace='osgi.bundle' name='org.coocox.codebugger.trace.ui' version='1.0.0.201410211009'/>
        <provided namespace='java.package' name='org.coocox.codebugger.trace.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.codebugger.trace.socket' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.utils' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.console' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.model.control' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.ui.console' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.coocox.codebugger.trace.ui' version='1.0.0.201410211009'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.coocox.codebugger.trace.ui;singleton:=true&#xA;Bundle-Version: 1.0.0.201410211009
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.coocox.codoc.core' version='1.0.0.201410211009' singleton='false'>
      <update id='org.coocox.codoc.core' range='[0.0.0,1.0.0.201410211009)' severity='0'/>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.name' value='Codoc'/>
      </properties>
      <provides size='4'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.coocox.codoc.core' version='1.0.0.201410211009'/>
        <provided namespace='osgi.bundle' name='org.coocox.codoc.core' version='1.0.0.201410211009'/>
        <provided namespace='java.package' name='org.coocox.codoc.doxygen' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.utils' range='1.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.coocox.codoc.core' version='1.0.0.201410211009'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.coocox.codoc.core&#xA;Bundle-Version: 1.0.0.201410211009
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.coocox.coide.help' version='1.0.0.201410211009'>
      <update id='org.coocox.coide.help' range='[0.0.0,1.0.0.201410211009)' severity='0'/>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.name' value='Help'/>
        <property name='org.eclipse.equinox.p2.provider' value='coocox'/>
      </properties>
      <provides size='3'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.coocox.coide.help' version='1.0.0.201410211009'/>
        <provided namespace='osgi.bundle' name='org.coocox.coide.help' version='1.0.0.201410211009'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='9'>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.help' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.help.appserver' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.help.base' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.help.ui' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.help.webapp' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.forms' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.http.jetty' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.coocox.coide.help' version='1.0.0.201410211009'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.coocox.coide.help;singleton:=true&#xA;Bundle-Version: 1.0.0.201410211009
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.coocox.coide.rcp' version='1.0.0.201410211009'>
      <update id='org.coocox.coide.rcp' range='[0.0.0,1.0.0.201410211009)' severity='0'/>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.name' value='CoIDE'/>
        <property name='org.eclipse.equinox.p2.provider' value='CooCox'/>
      </properties>
      <provides size='3'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.coocox.coide.rcp' version='1.0.0.201410211009'/>
        <provided namespace='osgi.bundle' name='org.coocox.coide.rcp' version='1.0.0.201410211009'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='30'>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.builder.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.component.front.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.debug.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.coassistant' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.codebugger.configuration' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.utils' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.extension.build' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.extension.example' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.customize' range='1.0.0'/>
        <required namespace='osgi.bundle' name='coocox_model_bundle' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.user.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.codb.client.core' range='1.0.0'/>
        <required namespace='java.package' name='org.coocox.coassistant.view' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.codebugger.configuration.actions' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.codebugger.debug.gdbjtag.io' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.codebugger.trace.actions' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.component.board.ui.actions' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.component.board.ui.editor' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.component.core' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.example.ui' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.userspace.actions' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.welcome.ui.actions' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.cdt.debug.core.model' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.cdt.debug.internal.ui.actions' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.cdt.debug.ui' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.ui.ide' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.ui.internal.ide' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.ui.internal.ide.model' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.coocox.coide.rcp' version='1.0.0.201410211009'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.coocox.coide.rcp; singleton:=true&#xA;Bundle-Version: 1.0.0.201410211009
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.coocox.coide.rcp.product' version='0.0.0'>
      <update id='org.coocox.coide.rcp.product' range='0.0.0' severity='0'/>
      <properties size='3'>
        <property name='org.eclipse.equinox.p2.name' value='CooCox CoIDE'/>
        <property name='lineUp' value='true'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.coocox.coide.rcp.product' version='0.0.0'/>
      </provides>
      <requires size='167'>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher.win32.win32.x86' range='[1.1.100.v20110502,1.1.100.v20110502]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.security.win32.x86' range='[1.0.200.v20100503,1.0.200.v20100503]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface' range='[3.7.0.v20110928-1505,3.7.0.v20110928-1505]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.text' range='[3.7.2.v20111213-1208,3.7.2.v20111213-1208]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.editors' range='[3.7.0.v20110928-1504,3.7.0.v20110928-1504]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.win32' range='[3.2.200.v20110928-1505,3.2.200.v20110928-1505]'>
          <filter>
            (osgi.ws=win32)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.draw2d' range='[3.7.2.v20111017-2020,3.7.2.v20111017-2020]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.hamcrest.core' range='[1.1.0.v20090501071000,1.1.0.v20090501071000]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.navigator' range='[3.5.101.v20120106-1355,3.5.101.v20120106-1355]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.forms' range='[3.5.101.v20111011-1919,3.5.101.v20111011-1919]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='coocox_model_bundle' range='[1.0.0,1.0.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.coocox.repository.customize' range='[1.0.0.201410211009,1.0.0.201410211009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.runtime.compatibility' range='[3.2.100.v20100505,3.2.100.v20100505]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.coocox.gnugcc.help' range='[1.0.0.201410211009,1.0.0.201410211009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cdt.core.win32' range='[5.2.0.201202111925,5.2.0.201202111925]'>
          <filter>
            (osgi.os=win32)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.core' range='[2.1.1.v20120113-1346,2.1.1.v20120113-1346]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.coocox.codb.common.protocol' range='[1.0.0.201410211009,1.0.0.201410211009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='a.jre.javase' range='[1.6.0,1.6.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.common' range='[3.6.0.v20110523,3.6.0.v20110523]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.coocox.component.widget' range='[1.0.0.201410211009,1.0.0.201410211009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher' range='[1.2.0.v20110502,1.2.0.v20110502]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.jasper' range='[5.5.17.v201101211617,5.5.17.v201101211617]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.debug.ui' range='[3.7.102.v20111129-1423_r372,3.7.102.v20111129-1423_r372]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.console' range='[3.5.100.v20111007_r372,3.5.100.v20111007_r372]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.runtime.compatibility.registry' range='[3.5.0.v20110505,3.5.0.v20110505]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.views.properties.tabbed' range='[3.5.200.v20110928-1505,3.5.200.v20110928-1505]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.app' range='[1.3.100.v20110321,1.3.100.v20110321]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.coocox.sqlite.rn' range='[1.0.0.201410211009,1.0.0.201410211009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.lucene.analysis' range='[2.9.1.v201101211721,2.9.1.v201101211721]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='javax.servlet.jsp' range='[2.0.0.v201101211617,2.0.0.v201101211617]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cdt.launch' range='[7.0.0.201202111925,7.0.0.201202111925]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.coocox.coassistant' range='[1.0.0.201410211009,1.0.0.201410211009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.coocox.model' range='[1.0.0,1.0.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.junit' range='[4.8.2.v4_8_2_v20110321-1705,4.8.2.v4_8_2_v20110321-1705]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.coocox.device.manage' range='[1.0.0.201410211009,1.0.0.201410211009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata' range='[2.1.0.v20110815-1419,2.1.0.v20110815-1419]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.coocox.codebugger.gdbjtag.core' range='[5.0.100.201410211009,5.0.100.201410211009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.coocox.codebugger.trace.ui' range='[1.0.0.201410211009,1.0.0.201410211009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cdt.core.win32.x86' range='[5.2.0.201202111925,5.2.0.201202111925]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.observable' range='[1.4.0.I20110222-0800,1.4.0.I20110222-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.coocox.example.core' range='[1.0.0.201410211009,1.0.0.201410211009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cdt.debug.core' range='[7.1.0.201202111925,7.1.0.201202111925]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.osgi' range='[3.7.2.v20120110-1415,3.7.2.v20120110-1415]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.http.jetty' range='[2.0.100.v20110502,2.0.100.v20110502]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.resources' range='[3.7.101.v20120125-1505,3.7.101.v20120125-1505]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ant.core' range='[3.2.302.v20120110-1739,3.2.302.v20120110-1739]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.coocox.codb.common.util' range='[1.0.0.201410211009,1.0.0.201410211009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.source.default' range='[1.0.0,1.0.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cdt.debug.ui' range='[7.1.2.201202111925,7.1.2.201202111925]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.common' range='[3.6.0.v20110523,3.6.0.v20110523]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.variables' range='[3.2.500.v20110928-1503,3.2.500.v20110928-1503]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.coocox.example.ui' range='[1.0.0.201410211009,1.0.0.201410211009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.repository' range='[2.1.1.v20120113-1346,2.1.1.v20120113-1346]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher' range='[1.2.0.v20110502,1.2.0.v20110502]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cdt.dsf' range='[2.2.0.201202111925,2.2.0.201202111925]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.coocox.extension.example' range='[1.0.0.201410211009,1.0.0.201410211009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help' range='[3.5.100.v20110426,3.5.100.v20110426]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi' range='[3.7.2.v20120110-1415,3.7.2.v20120110-1415]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.lucene.core' range='[2.9.1.v201101211721,2.9.1.v201101211721]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.ide' range='[3.7.0.v20110928-1505,3.7.0.v20110928-1505]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.search' range='[3.7.0.v20110928-1504,3.7.0.v20110928-1504]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help.ui' range='[3.5.101.r37_20110819,3.5.101.r37_20110819]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.logging' range='[1.0.4.v201101211617,1.0.4.v201101211617]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.coocox.customize' range='[1.0.0.201410211009,1.0.0.201410211009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.coocox.coide.rcp.product.configuration' range='raw:[-M,-M]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.coocox.component.basic.manage.ui' range='[1.0.0.201410211009,1.0.0.201410211009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.coocox.converter.core' range='[1.0.0.201410211009,1.0.0.201410211009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cdt.core' range='[5.3.2.201202111925,5.3.2.201202111925]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.coocox.codebugger.gdbjtag.ui' range='[5.0.100.201410211009,5.0.100.201410211009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.debug.core' range='[3.7.1.v20111129-2031,3.7.1.v20111129-2031]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.team.ui' range='[3.6.101.R37x_v20111109-0800,3.6.101.R37x_v20111109-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore' range='[2.7.0.v20120127-1122,2.7.0.v20120127-1122]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.services' range='[3.3.0.v20110513,3.3.0.v20110513]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.jobs' range='[3.5.101.v20120113-1953,3.5.101.v20120113-1953]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.engine' range='[2.1.1.R37x_v20111003,2.1.1.R37x_v20111003]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.coocox.device.core' range='[1.0.0.201410211009,1.0.0.201410211009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cdt.debug.ui.memory.transport' range='[2.1.0.201202111925,2.1.0.201202111925]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.databinding' range='[1.5.0.I20100907-0800,1.5.0.I20100907-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='config.a.jre.javase' range='[1.6.0,1.6.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.coocox.component.basic.manage.core' range='[1.0.0.201410211009,1.0.0.201410211009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.coocox.utils' range='[1.0.0.201410211009,1.0.0.201410211009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.coocox.component.board.core' range='[1.0.0.201410211009,1.0.0.201410211009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.coocox.user.ui' range='[1.0.0.201410211009,1.0.0.201410211009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.coocox.coide.help' range='[1.0.0.201410211009,1.0.0.201410211009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.coocox.component.board.manage.ui' range='[1.0.0.201410211009,1.0.0.201410211009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.preferences' range='[3.4.2.v20120111-2020,3.4.2.v20120111-2020]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help.appserver' range='[3.1.400.v20110425,3.1.400.v20110425]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt' range='[3.7.2.v3740f,3.7.2.v3740f]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.coocox.ceditor.patch' range='[1.0.0.201410211009,1.0.0.201410211009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.win32.x86' range='[1.1.300.v20110423-0524,1.1.300.v20110423-0524]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.coocox.userspace' range='[1.0.0.201410211009,1.0.0.201410211009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.coocox.welcome.ui' range='[1.0.0.201410211009,1.0.0.201410211009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.coocox.builder.core' range='[1.0.0.201410211009,1.0.0.201410211009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.coocox.codb.client.core' range='[1.0.0.201410211009,1.0.0.201410211009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.coocox.component.driver.manage.ui' range='[1.0.0.201410211009,1.0.0.201410211009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.workbench.texteditor' range='[3.7.0.v20110928-1504,3.7.0.v20110928-1504]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.coocox.coide.rcp' range='[1.0.0.201410211009,1.0.0.201410211009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cdt.debug.ui.memory.traditional' range='[1.2.1.201202111925,1.2.1.201202111925]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.workbench' range='[3.7.1.v20120104-1859,3.7.1.v20120104-1859]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.http.registry' range='[1.1.100.v20110502,1.1.100.v20110502]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.coocox.coide.rcp.product_root.win32.win32.x86' range='[1.0.0,1.0.0]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.coocox.component.front.ui' range='[1.0.0.201410211009,1.0.0.201410211009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.http.servlet' range='[1.1.200.v20110502,1.1.200.v20110502]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.navigator.resources' range='[3.4.200.I20100601-0800,3.4.200.I20100601-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.coocox.component.board.ui' range='[1.0.0.201410211009,1.0.0.201410211009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui' range='[3.7.0.v20110928-1505,3.7.0.v20110928-1505]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.property' range='[1.4.0.I20110222-0800,1.4.0.I20110222-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.jsp.jasper' range='[1.0.300.v20110502,1.0.300.v20110502]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filebuffers' range='[3.5.200.v20110928-1504,3.5.200.v20110928-1504]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.ibm.icu' range='[4.4.2.v20110823,4.4.2.v20110823]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.coocox.integrate.component' range='[1.0.0.201410211009,1.0.0.201410211009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.org.eclipse.update.feature.default' range='[1.0.0,1.0.0]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem' range='[1.3.100.v20110423-0524,1.3.100.v20110423-0524]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.jsp.jasper.registry' range='[1.0.200.v20100503,1.0.200.v20100503]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cdt.debug.mi.core' range='[7.1.1.201202111925,7.1.1.201202111925]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.core.runtime' range='[3.7.0.v20110110,3.7.0.v20110110]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.junit4' range='[4.8.1.v20100525,4.8.1.v20100525]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.coocox.common.ui' range='[1.0.0.201410211009,1.0.0.201410211009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.text' range='[3.5.101.v20110928-1504,3.5.101.v20110928-1504]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.el' range='[1.0.0.v201101211617,1.0.0.v201101211617]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding' range='[1.4.0.I20110111-0800,1.4.0.I20110111-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.coocox.userspace.manage.ui' range='[1.0.0.201410211009,1.0.0.201410211009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.coocox.lib.cassandra' range='[1.0.0,1.0.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.compare.core' range='[3.5.200.I20110208-0800,3.5.200.I20110208-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.coocox.example.manage.ui' range='[1.0.0.201410211009,1.0.0.201410211009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.coocox.common.manage.ui' range='[1.0.0.201410211009,1.0.0.201410211009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.security' range='[1.1.1.R37x_v20110822-1018,1.1.1.R37x_v20110822-1018]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.compare' range='[3.5.202.R37x_v20111109-0800,3.5.202.R37x_v20111109-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata.repository' range='[1.2.0.v20110815-1419,1.2.0.v20110815-1419]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help.webapp' range='[3.6.1.r37_20110929,3.6.1.r37_20110929]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.views' range='[3.6.0.v20110928-1505,3.6.0.v20110928-1505]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.update.configurator' range='[3.3.100.v20100512,3.3.100.v20100512]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.osgi.bundle.default' range='[1.0.0,1.0.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cdt.debug.ui.memory.search' range='[1.2.1.201202111925,1.2.1.201202111925]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.runtime' range='[3.7.0.v20110110,3.7.0.v20110110]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.resources.win32.x86' range='[3.5.100.v20110423-0524,3.5.100.v20110423-0524]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help.base' range='[3.6.2.v201202080800,3.6.2.v201202080800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.coocox.builder.ui' range='[1.0.0.201410211009,1.0.0.201410211009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.ant' range='[1.8.2.v20120109-1030,1.8.2.v20120109-1030]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cdt.debug.ui.memory.memorybrowser' range='[1.2.100.201202111925,1.2.100.201202111925]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.registry' range='[3.5.101.R37x_v20110810-1611,3.5.101.R37x_v20110810-1611]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.coocox.codoc.core' range='[1.0.0.201410211009,1.0.0.201410211009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.common' range='[2.7.0.v20120127-1122,2.7.0.v20120127-1122]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.coocox.coide.rcp.product_root.win32.win32.x86' range='raw:[-M,-M]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.team.core' range='[3.6.0.I20110525-0800,3.6.0.I20110525-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.coocox.codebugger.configuration' range='[1.0.0.201410211009,1.0.0.201410211009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.coocox.component.front.core' range='[1.0.0.201410211009,1.0.0.201410211009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.coocox.component.driver.manage.core' range='[1.0.0.201410211009,1.0.0.201410211009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.contenttype' range='[3.4.100.v20110423-0524,3.4.100.v20110423-0524]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.mortbay.jetty.util' range='[6.1.23.v201012071420,6.1.23.v201012071420]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.coocox.model.control' range='[1.0.0.201410211009,1.0.0.201410211009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cdt.dsf.ui' range='[2.2.1.201202111925,2.2.1.201202111925]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cdt.gdb' range='[7.0.0.201202111925,7.0.0.201202111925]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.coocox.example.manage.core' range='[1.0.0.201410211009,1.0.0.201410211009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.commands' range='[3.6.0.I20110111-0800,3.6.0.I20110111-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.expressions' range='[3.4.300.v20110228,3.4.300.v20110228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cdt.ui' range='[5.3.2.201202111925,5.3.2.201202111925]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ltk.ui.refactoring' range='[3.6.0.v20110928-1453,3.6.0.v20110928-1453]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.lucene' range='[2.9.1.v201101211721,2.9.1.v201101211721]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.coocox.extension.build' range='[1.0.0.201410211009,1.0.0.201410211009]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.update.configurator' range='[3.3.100.v20100512,3.3.100.v20100512]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='javax.servlet' range='[2.5.0.v201103041518,2.5.0.v201103041518]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.win32.win32.x86' range='[3.7.2.v3740f,3.7.2.v3740f]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.win32.win32.x86' range='[1.1.100.v20110502,1.1.100.v20110502]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ltk.core.refactoring' range='[3.5.201.r372_v20111101-0700,3.5.201.r372_v20111101-0700]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.mortbay.jetty.server' range='[6.1.23.v201012071420,6.1.23.v201012071420]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.coocox.component.board.manage.core' range='[1.0.0.201410211009,1.0.0.201410211009]'/>
      </requires>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
    </unit>
    <unit id='org.coocox.coide.rcp.product_root.win32.win32.x86' version='1.0.0'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.coocox.coide.rcp.product_root.win32.win32.x86' version='1.0.0'/>
      </provides>
      <filter>
        (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <artifacts size='1'>
        <artifact classifier='binary' id='org.coocox.coide.rcp.product_root.win32.win32.x86' version='1.0.0'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='install'>
            unzip(source:@artifact, target:${installFolder});
          </instruction>
          <instruction key='uninstall'>
            cleanupzip(source:@artifact, target:${installFolder});
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.coocox.common.manage.ui' version='1.0.0.201410211009'>
      <update id='org.coocox.common.manage.ui' range='[0.0.0,1.0.0.201410211009)' severity='0'/>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.name' value='Ui'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.coocox.common.manage.ui' version='1.0.0.201410211009'/>
        <provided namespace='osgi.bundle' name='org.coocox.common.manage.ui' version='1.0.0.201410211009'/>
        <provided namespace='java.package' name='org.coocox.common.manage.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.common.manage.ui' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.component.front.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.user.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.sqlite.rn' range='1.0.0'/>
        <required namespace='osgi.bundle' name='coocox_model_bundle' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.component.board.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.example.core' range='1.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.coocox.common.manage.ui' version='1.0.0.201410211009'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.coocox.common.manage.ui;singleton:=true&#xA;Bundle-Version: 1.0.0.201410211009
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.coocox.common.ui' version='1.0.0.201410211009'>
      <update id='org.coocox.common.ui' range='[0.0.0,1.0.0.201410211009)' severity='0'/>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.name' value='Ui'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.coocox.common.ui' version='1.0.0.201410211009'/>
        <provided namespace='osgi.bundle' name='org.coocox.common.ui' version='1.0.0.201410211009'/>
        <provided namespace='java.package' name='org.coocox.common.ui.action' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.common.ui.extension' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.common.ui.page' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.common.ui.widgets' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='14'>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='3.7.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.device.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.forms' range='3.5.101'/>
        <required namespace='osgi.bundle' name='org.coocox.utils' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.component.front.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.user.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.component.basic.manage.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.component.driver.manage.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.draw2d' range='3.7.2'/>
        <required namespace='osgi.bundle' name='org.coocox.sqlite.rn' range='1.0.0'/>
        <required namespace='osgi.bundle' name='coocox_model_bundle' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.codb.client.core' range='1.0.0'/>
        <required namespace='java.package' name='org.coocox.builder.ui.persistent' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.coocox.common.ui' version='1.0.0.201410211009'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.coocox.common.ui;singleton:=true&#xA;Bundle-Version: 1.0.0.201410211009
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.coocox.component.basic.manage.core' version='1.0.0.201410211009' singleton='false'>
      <update id='org.coocox.component.basic.manage.core' range='[0.0.0,1.0.0.201410211009)' severity='0'/>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.name' value='BasicComponentCore'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.coocox.component.basic.manage.core' version='1.0.0.201410211009'/>
        <provided namespace='osgi.bundle' name='org.coocox.component.basic.manage.core' version='1.0.0.201410211009'/>
        <provided namespace='java.package' name='org.coocox.component.basic.manage.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.component.basic.manage.core.util' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='9'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='coocox_model_bundle' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.component.front.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.device.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.codb.common.util' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.sqlite.rn' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.common.manage.ui' range='1.0.0'/>
        <required namespace='java.package' name='org.codehaus.jackson' range='0.0.0'/>
        <required namespace='java.package' name='org.codehaus.jackson.map' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.coocox.component.basic.manage.core' version='1.0.0.201410211009'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.coocox.component.basic.manage.core&#xA;Bundle-Version: 1.0.0.201410211009
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.coocox.component.basic.manage.ui' version='1.0.0.201410211009'>
      <update id='org.coocox.component.basic.manage.ui' range='[0.0.0,1.0.0.201410211009)' severity='0'/>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.name' value='BasicComponentCommit'/>
      </properties>
      <provides size='11'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.coocox.component.basic.manage.ui' version='1.0.0.201410211009'/>
        <provided namespace='osgi.bundle' name='org.coocox.component.basic.manage.ui' version='1.0.0.201410211009'/>
        <provided namespace='java.package' name='org.coocox.component.basic.manage.ui' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.component.basic.manage.ui.command' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.component.basic.manage.ui.dialog' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.component.basic.manage.ui.extensionpoint' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.component.basic.manage.ui.factory' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.component.basic.manage.ui.pagestack' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.component.basic.manage.ui.window' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.component.basic.manage.ui.wizard' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='16'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='3.7.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.forms' range='3.5.101'/>
        <required namespace='osgi.bundle' name='coocox_model_bundle' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.component.basic.manage.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.sqlite.rn' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.utils' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.component.front.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.device.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.codoc.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.codb.client.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.user.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.codb.common.util' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.common.manage.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.customize' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='3.7.101'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.coocox.component.basic.manage.ui' version='1.0.0.201410211009'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.coocox.component.basic.manage.ui;singleton:=true&#xA;Bundle-Version: 1.0.0.201410211009
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.coocox.component.board.core' version='1.0.0.201410211009' singleton='false'>
      <update id='org.coocox.component.board.core' range='[0.0.0,1.0.0.201410211009)' severity='0'/>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.name' value='Core'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.coocox.component.board.core' version='1.0.0.201410211009'/>
        <provided namespace='osgi.bundle' name='org.coocox.component.board.core' version='1.0.0.201410211009'/>
        <provided namespace='java.package' name='org.coocox.component.board.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.component.board.core.database' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.component.board.core.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.component.board.core.model.impl' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.component.front.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.example.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.sqlite.rn' range='1.0.0'/>
        <required namespace='osgi.bundle' name='coocox_model_bundle' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.codb.client.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.customize' range='1.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.coocox.component.board.core' version='1.0.0.201410211009'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.coocox.component.board.core&#xA;Bundle-Version: 1.0.0.201410211009
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.coocox.component.board.manage.core' version='1.0.0.201410211009' singleton='false'>
      <update id='org.coocox.component.board.manage.core' range='[0.0.0,1.0.0.201410211009)' severity='0'/>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.name' value='Core'/>
      </properties>
      <provides size='4'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.coocox.component.board.manage.core' version='1.0.0.201410211009'/>
        <provided namespace='osgi.bundle' name='org.coocox.component.board.manage.core' version='1.0.0.201410211009'/>
        <provided namespace='java.package' name='org.coocox.component.board.manage.core' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='9'>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.component.front.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.component.board.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='coocox_model_bundle' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.example.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.device.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.user.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.common.manage.ui' range='1.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.coocox.component.board.manage.core' version='1.0.0.201410211009'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.coocox.component.board.manage.core&#xA;Bundle-Version: 1.0.0.201410211009
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.coocox.component.board.manage.ui' version='1.0.0.201410211009'>
      <update id='org.coocox.component.board.manage.ui' range='[0.0.0,1.0.0.201410211009)' severity='0'/>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.name' value='Ui'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.coocox.component.board.manage.ui' version='1.0.0.201410211009'/>
        <provided namespace='osgi.bundle' name='org.coocox.component.board.manage.ui' version='1.0.0.201410211009'/>
        <provided namespace='java.package' name='org.coocox.component.board.manage.ui.command' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.component.board.manage.ui.dialog' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.component.board.manage.ui.extensionpoint' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='16'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.forms' range='3.5.101'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.ide' range='3.7.0'/>
        <required namespace='osgi.bundle' name='coocox_model_bundle' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.utils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.component.board.manage.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.sqlite.rn' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.component.board.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.user.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.component.front.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.device.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.example.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.codb.client.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.common.manage.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.customize' range='1.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.coocox.component.board.manage.ui' version='1.0.0.201410211009'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.coocox.component.board.manage.ui;singleton:=true&#xA;Bundle-Version: 1.0.0.201410211009
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.coocox.component.board.ui' version='1.0.0.201410211009'>
      <update id='org.coocox.component.board.ui' range='[0.0.0,1.0.0.201410211009)' severity='0'/>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.name' value='Ui'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.coocox.component.board.ui' version='1.0.0.201410211009'/>
        <provided namespace='osgi.bundle' name='org.coocox.component.board.ui' version='1.0.0.201410211009'/>
        <provided namespace='java.package' name='org.coocox.component.board.ui' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.component.board.ui.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.component.board.ui.commands' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.component.board.ui.editor' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.component.board.ui.extension' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.component.board.ui.listener' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.component.board.ui.table' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='26'>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='3.7.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='3.7.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.forms' range='3.5.101'/>
        <required namespace='osgi.bundle' name='org.eclipse.draw2d' range='3.7.2'/>
        <required namespace='osgi.bundle' name='org.coocox.component.widget' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.utils' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.user.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.sqlite.rn' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.model' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.model.control' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.device.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.component.board.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.component.front.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.example.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='coocox_model_bundle' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.component.board.manage.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.component.basic.manage.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.component.driver.manage.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.example.manage.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.common.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.builder.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.codb.client.core' range='1.0.0'/>
        <required namespace='java.package' name='org.coocox.codoc.doxygen' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.component.driver.manage.core' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.customize.option' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.example.actions' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.coocox.component.board.ui' version='1.0.0.201410211009'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.coocox.component.board.ui;singleton:=true&#xA;Bundle-Version: 1.0.0.201410211009
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.coocox.component.driver.manage.core' version='1.0.0.201410211009' singleton='false'>
      <update id='org.coocox.component.driver.manage.core' range='[0.0.0,1.0.0.201410211009)' severity='0'/>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.name' value='Core'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.coocox.component.driver.manage.core' version='1.0.0.201410211009'/>
        <provided namespace='osgi.bundle' name='org.coocox.component.driver.manage.core' version='1.0.0.201410211009'/>
        <provided namespace='java.package' name='org.coocox.component.driver.manage.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.component.driver.manage.core.util' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.component.front.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.device.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.sqlite.rn' range='1.0.0'/>
        <required namespace='osgi.bundle' name='coocox_model_bundle' range='1.0.0'/>
        <required namespace='java.package' name='org.coocox.user.ui.account' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.coocox.component.driver.manage.core' version='1.0.0.201410211009'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.coocox.component.driver.manage.core&#xA;Bundle-Version: 1.0.0.201410211009
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.coocox.component.driver.manage.ui' version='1.0.0.201410211009'>
      <update id='org.coocox.component.driver.manage.ui' range='[0.0.0,1.0.0.201410211009)' severity='0'/>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.name' value='Ui'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.coocox.component.driver.manage.ui' version='1.0.0.201410211009'/>
        <provided namespace='osgi.bundle' name='org.coocox.component.driver.manage.ui' version='1.0.0.201410211009'/>
        <provided namespace='java.package' name='org.coocox.component.driver.manage.ui.commands' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.component.driver.manage.ui.extensionpoint' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.component.driver.manage.ui.modify' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='13'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='3.7.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.forms' range='3.5.101'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='3.7.101'/>
        <required namespace='osgi.bundle' name='org.coocox.component.front.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.component.driver.manage.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.sqlite.rn' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.utils' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.codb.client.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.user.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='coocox_model_bundle' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.device.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.codoc.core' range='1.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.coocox.component.driver.manage.ui' version='1.0.0.201410211009'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.coocox.component.driver.manage.ui;singleton:=true&#xA;Bundle-Version: 1.0.0.201410211009
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.coocox.component.front.core' version='1.0.0.201410211009' singleton='false'>
      <update id='org.coocox.component.front.core' range='[0.0.0,1.0.0.201410211009)' severity='0'/>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.name' value='Core'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.coocox.component.front.core' version='1.0.0.201410211009'/>
        <provided namespace='osgi.bundle' name='org.coocox.component.front.core' version='1.0.0.201410211009'/>
        <provided namespace='java.package' name='org.coocox.component.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.component.core.database' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.component.core.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.component.core.model.commit' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.component.internal.core.model' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='9'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.device.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.sqlite.rn' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.codb.client.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='coocox_model_bundle' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.customize' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.user.ui' range='1.0.0'/>
        <required namespace='java.package' name='org.coocox.component.core.database' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.jface.util' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.coocox.component.front.core' version='1.0.0.201410211009'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.coocox.component.front.core&#xA;Bundle-Version: 1.0.0.201410211009
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.coocox.component.front.ui' version='1.0.0.201410211009'>
      <update id='org.coocox.component.front.ui' range='[0.0.0,1.0.0.201410211009)' severity='0'/>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.name' value='Ui'/>
      </properties>
      <provides size='14'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.coocox.component.front.ui' version='1.0.0.201410211009'/>
        <provided namespace='osgi.bundle' name='org.coocox.component.front.ui' version='1.0.0.201410211009'/>
        <provided namespace='java.package' name='org.coocox.component.manage.ui.extension' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.component.ui' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.component.ui.commands' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.component.ui.doxygen' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.component.ui.driver.action' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.component.ui.editors' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.component.ui.editors.repository' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.component.ui.help' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.component.ui.hover' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.component.ui.typenametree' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.component.ui.viewers' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='28'>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.component.front.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.forms' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.device.manage' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.component.widget' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.utils' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.device.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.user.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.codoc.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.draw2d' range='3.7.2'/>
        <required namespace='osgi.bundle' name='org.coocox.sqlite.rn' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.component.driver.manage.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.component.driver.manage.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='coocox_model_bundle' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.component.basic.manage.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.example.manage.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.component.board.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.component.board.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.example.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.component.board.manage.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.common.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.codb.client.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.builder.ui' range='1.0.0'/>
        <required namespace='java.package' name='org.coocox.coide.diy.actions' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.filesystem' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.resources' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.ui.ide' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.coocox.component.front.ui' version='1.0.0.201410211009'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.coocox.component.front.ui;singleton:=true&#xA;Bundle-Version: 1.0.0.201410211009
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.coocox.component.widget' version='1.0.0.201410211009' singleton='false'>
      <update id='org.coocox.component.widget' range='[0.0.0,1.0.0.201410211009)' severity='0'/>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.name' value='Widget'/>
      </properties>
      <provides size='4'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.coocox.component.widget' version='1.0.0.201410211009'/>
        <provided namespace='osgi.bundle' name='org.coocox.component.widget' version='1.0.0.201410211009'/>
        <provided namespace='java.package' name='org.component.widget' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.utils' range='1.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.coocox.component.widget' version='1.0.0.201410211009'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.coocox.component.widget&#xA;Bundle-Version: 1.0.0.201410211009
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.coocox.converter.core' version='1.0.0.201410211009'>
      <update id='org.coocox.converter.core' range='[0.0.0,1.0.0.201410211009)' severity='0'/>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.name' value='Core'/>
      </properties>
      <provides size='4'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.coocox.converter.core' version='1.0.0.201410211009'/>
        <provided namespace='osgi.bundle' name='org.coocox.converter.core' version='1.0.0.201410211009'/>
        <provided namespace='java.package' name='org.coocox.converter.core.opration' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.model' range='1.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.coocox.converter.core' version='1.0.0.201410211009'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.coocox.converter.core;singleton:=true&#xA;Bundle-Version: 1.0.0.201410211009
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.coocox.customize' version='1.0.0.201410211009' singleton='false'>
      <update id='org.coocox.customize' range='[0.0.0,1.0.0.201410211009)' severity='0'/>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.name' value='Customized'/>
      </properties>
      <provides size='4'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.coocox.customize' version='1.0.0.201410211009'/>
        <provided namespace='osgi.bundle' name='org.coocox.customize' version='1.0.0.201410211009'/>
        <provided namespace='java.package' name='org.coocox.customize.option' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.forms' range='3.5.101'/>
        <required namespace='osgi.bundle' name='org.coocox.device.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.utils' range='1.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.coocox.customize' version='1.0.0.201410211009'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.coocox.customize&#xA;Bundle-Version: 1.0.0.201410211009
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.coocox.device.core' version='1.0.0.201410211009' singleton='false'>
      <update id='org.coocox.device.core' range='[0.0.0,1.0.0.201410211009)' severity='0'/>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.name' value='Device'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.coocox.device.core' version='1.0.0.201410211009'/>
        <provided namespace='osgi.bundle' name='org.coocox.device.core' version='1.0.0.201410211009'/>
        <provided namespace='java.package' name='org.coocox.device.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.device.internal.core' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='9'>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.sqlite.rn' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.codb.client.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.codb.common.util' range='1.0.0'/>
        <required namespace='osgi.bundle' name='coocox_model_bundle' range='1.0.0'/>
        <required namespace='java.package' name='org.codehaus.jackson' range='0.0.0'/>
        <required namespace='java.package' name='org.codehaus.jackson.map' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.codb.common.dto' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.coocox.device.core' version='1.0.0.201410211009'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.coocox.device.core&#xA;Bundle-Version: 1.0.0.201410211009
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.coocox.device.manage' version='1.0.0.201410211009'>
      <update id='org.coocox.device.manage' range='[0.0.0,1.0.0.201410211009)' severity='0'/>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.name' value='Diy'/>
        <property name='org.eclipse.equinox.p2.provider' value='CooCox.org'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.coocox.device.manage' version='1.0.0.201410211009'/>
        <provided namespace='osgi.bundle' name='org.coocox.device.manage' version='1.0.0.201410211009'/>
        <provided namespace='java.package' name='org.coocox.coide.diy' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.coide.diy.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.coide.diy.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.coide.diy.extensionpoint' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='15'>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.forms' range='3.5.101'/>
        <required namespace='osgi.bundle' name='org.coocox.component.front.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.device.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.codb.common.util' range='1.0.0'/>
        <required namespace='osgi.bundle' name='coocox_model_bundle' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.component.board.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.codb.client.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.component.board.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.builder.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.repository.customize' range='1.0.0'/>
        <required namespace='java.package' name='org.codehaus.jackson' range='0.0.0'/>
        <required namespace='java.package' name='org.codehaus.jackson.map' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.user.ui.account' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.coocox.device.manage' version='1.0.0.201410211009'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.coocox.device.manage;singleton:=true&#xA;Bundle-Version: 1.0.0.201410211009
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.coocox.example.core' version='1.0.0.201410211009' singleton='false'>
      <update id='org.coocox.example.core' range='[0.0.0,1.0.0.201410211009)' severity='0'/>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.name' value='Core'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.coocox.example.core' version='1.0.0.201410211009'/>
        <provided namespace='osgi.bundle' name='org.coocox.example.core' version='1.0.0.201410211009'/>
        <provided namespace='java.package' name='org.coocox.example.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.example.core.impl' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='10'>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.utils' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.device.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.component.front.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.core' range='5.3.2'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='3.7.101'/>
        <required namespace='osgi.bundle' name='org.coocox.sqlite.rn' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.codb.client.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='coocox_model_bundle' range='1.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.coocox.example.core' version='1.0.0.201410211009'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.coocox.example.core&#xA;Bundle-Version: 1.0.0.201410211009
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.coocox.example.manage.core' version='1.0.0.201410211009' singleton='false'>
      <update id='org.coocox.example.manage.core' range='[0.0.0,1.0.0.201410211009)' severity='0'/>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.name' value='ExampleManagerCore'/>
      </properties>
      <provides size='4'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.coocox.example.manage.core' version='1.0.0.201410211009'/>
        <provided namespace='osgi.bundle' name='org.coocox.example.manage.core' version='1.0.0.201410211009'/>
        <provided namespace='java.package' name='org.coocox.example.manage.core' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='coocox_model_bundle' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.example.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.component.front.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.user.ui' range='1.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.coocox.example.manage.core' version='1.0.0.201410211009'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.coocox.example.manage.core&#xA;Bundle-Version: 1.0.0.201410211009
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.coocox.example.manage.ui' version='1.0.0.201410211009'>
      <update id='org.coocox.example.manage.ui' range='[0.0.0,1.0.0.201410211009)' severity='0'/>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.name' value='ExampleManager'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.coocox.example.manage.ui' version='1.0.0.201410211009'/>
        <provided namespace='osgi.bundle' name='org.coocox.example.manage.ui' version='1.0.0.201410211009'/>
        <provided namespace='java.package' name='org.coocox.example.manage.ui.command' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.example.manage.ui.extensionpoint' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='15'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='3.7.0'/>
        <required namespace='osgi.bundle' name='org.coocox.example.manage.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.utils' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.component.front.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.user.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.example.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='coocox_model_bundle' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.ide' range='3.7.0'/>
        <required namespace='osgi.bundle' name='org.coocox.device.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.sqlite.rn' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.codb.client.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.codoc.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.customize' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.resources' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.coocox.example.manage.ui' version='1.0.0.201410211009'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.coocox.example.manage.ui;singleton:=true&#xA;Bundle-Version: 1.0.0.201410211009
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.coocox.example.ui' version='1.0.0.201410211009'>
      <update id='org.coocox.example.ui' range='[0.0.0,1.0.0.201410211009)' severity='0'/>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.name' value='Example'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.coocox.example.ui' version='1.0.0.201410211009'/>
        <provided namespace='osgi.bundle' name='org.coocox.example.ui' version='1.0.0.201410211009'/>
        <provided namespace='java.package' name='org.coocox.example' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.example.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.example.ui' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.example.ui.extensionpoint' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.example.ui.views' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='21'>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.utils' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.editors' range='3.7.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filesystem' range='1.3.100'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface.text' range='3.7.2'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.core' range='5.3.2'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='3.7.101'/>
        <required namespace='osgi.bundle' name='org.coocox.device.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.user.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.example.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.ide' range='3.7.0'/>
        <required namespace='osgi.bundle' name='coocox_model_bundle' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.example.manage.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.component.front.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.codb.client.core' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.codb.client.core.api.impl' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.codb.client.core.service' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.common.ui.action' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.cdt.internal.ui.editor' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.ui.part' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.coocox.example.ui' version='1.0.0.201410211009'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.coocox.example.ui;singleton:=true&#xA;Bundle-Version: 1.0.0.201410211009
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.coocox.extension.build' version='1.0.0.201410211009'>
      <update id='org.coocox.extension.build' range='[0.0.0,1.0.0.201410211009)' severity='0'/>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.name' value='Build'/>
      </properties>
      <provides size='4'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.coocox.extension.build' version='1.0.0.201410211009'/>
        <provided namespace='osgi.bundle' name='org.coocox.extension.build' version='1.0.0.201410211009'/>
        <provided namespace='java.package' name='org.coocox.extension.build' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='19'>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.builder.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.component.front.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.device.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.forms' range='3.5.101'/>
        <required namespace='osgi.bundle' name='org.coocox.component.front.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.example.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.integrate.component' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.apache.jasper' range='5.5.17'/>
        <required namespace='osgi.bundle' name='org.coocox.utils' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='3.7.101'/>
        <required namespace='osgi.bundle' name='org.coocox.component.board.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.component.board.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.example.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.model.control' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.component.driver.manage.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.example.manage.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.welcome.ui' range='1.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.coocox.extension.build' version='1.0.0.201410211009'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.coocox.extension.build;singleton:=true&#xA;Bundle-Version: 1.0.0.201410211009
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.coocox.extension.example' version='1.0.0.201410211009'>
      <update id='org.coocox.extension.example' range='[0.0.0,1.0.0.201410211009)' severity='0'/>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.name' value='Example'/>
      </properties>
      <provides size='3'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.coocox.extension.example' version='1.0.0.201410211009'/>
        <provided namespace='osgi.bundle' name='org.coocox.extension.example' version='1.0.0.201410211009'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='16'>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='3.7.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.forms' range='3.5.101'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.editors' range='3.7.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='3.7.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='3.7.101'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface.text' range='3.7.2'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.core' range='5.3.2'/>
        <required namespace='osgi.bundle' name='org.coocox.utils' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.ide' range='3.7.0'/>
        <required namespace='osgi.bundle' name='org.coocox.builder.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.navigator' range='3.5.101'/>
        <required namespace='osgi.bundle' name='org.coocox.integrate.component' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.component.front.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.example.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.example.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.example.manage.ui' range='1.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.coocox.extension.example' version='1.0.0.201410211009'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.coocox.extension.example;singleton:=true&#xA;Bundle-Version: 1.0.0.201410211009
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.coocox.gnugcc.help' version='1.0.0.201410211009'>
      <update id='org.coocox.gnugcc.help' range='[0.0.0,1.0.0.201410211009)' severity='0'/>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.name' value='Help'/>
        <property name='org.eclipse.equinox.p2.provider' value='coocox'/>
      </properties>
      <provides size='3'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.coocox.gnugcc.help' version='1.0.0.201410211009'/>
        <provided namespace='osgi.bundle' name='org.coocox.gnugcc.help' version='1.0.0.201410211009'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.help' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.help.appserver' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.help.base' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.help.ui' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.help.webapp' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.http.jetty' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.coocox.gnugcc.help' version='1.0.0.201410211009'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.coocox.gnugcc.help;singleton:=true&#xA;Bundle-Version: 1.0.0.201410211009
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.coocox.integrate.component' version='1.0.0.201410211009'>
      <update id='org.coocox.integrate.component' range='[0.0.0,1.0.0.201410211009)' severity='0'/>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.name' value='Component'/>
      </properties>
      <provides size='4'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.coocox.integrate.component' version='1.0.0.201410211009'/>
        <provided namespace='osgi.bundle' name='org.coocox.integrate.component' version='1.0.0.201410211009'/>
        <provided namespace='java.package' name='org.coocox.integrate.component.views' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='23'>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.component.front.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.builder.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.component.front.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.forms' range='3.5.101'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='3.7.101'/>
        <required namespace='osgi.bundle' name='org.eclipse.debug.core' range='3.7.1'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.navigator' range='3.5.101'/>
        <required namespace='osgi.bundle' name='org.coocox.ceditor.patch' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.codebugger.gdbjtag.core' range='5.0.100'/>
        <required namespace='osgi.bundle' name='org.coocox.codebugger.configuration' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.example.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.utils' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.device.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.example.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.ide' range='3.7.0'/>
        <required namespace='osgi.bundle' name='org.coocox.component.widget' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.draw2d' range='3.7.2'/>
        <required namespace='osgi.bundle' name='org.coocox.component.board.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.component.board.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.common.ui' range='1.0.0'/>
        <required namespace='java.package' name='org.coocox.codb.common.util' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.coocox.integrate.component' version='1.0.0.201410211009'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.coocox.integrate.component;singleton:=true&#xA;Bundle-Version: 1.0.0.201410211009
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.coocox.lib.cassandra' version='1.0.0' singleton='false'>
      <update id='org.coocox.lib.cassandra' range='[0.0.0,1.0.0)' severity='0'/>
      <properties size='3'>
        <property name='org.eclipse.equinox.p2.name' value='Cassandra'/>
        <property name='file.name' value='D:\Eclipse\plugins\org.coocox.lib.cassandra_1.0.0.jar'/>
        <property name='file.lastModified' value='1293439592000'/>
      </properties>
      <provides size='269'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.coocox.lib.cassandra' version='1.0.0'/>
        <provided namespace='osgi.bundle' name='org.coocox.lib.cassandra' version='1.0.0'/>
        <provided namespace='java.package' name='antlr' version='0.0.0'/>
        <provided namespace='java.package' name='antlr.ASdebug' version='0.0.0'/>
        <provided namespace='java.package' name='antlr.actions.cpp' version='0.0.0'/>
        <provided namespace='java.package' name='antlr.actions.csharp' version='0.0.0'/>
        <provided namespace='java.package' name='antlr.actions.java' version='0.0.0'/>
        <provided namespace='java.package' name='antlr.actions.python' version='0.0.0'/>
        <provided namespace='java.package' name='antlr.build' version='0.0.0'/>
        <provided namespace='java.package' name='antlr.collections' version='0.0.0'/>
        <provided namespace='java.package' name='antlr.collections.impl' version='0.0.0'/>
        <provided namespace='java.package' name='antlr.debug' version='0.0.0'/>
        <provided namespace='java.package' name='antlr.debug.misc' version='0.0.0'/>
        <provided namespace='java.package' name='antlr.preprocessor' version='0.0.0'/>
        <provided namespace='java.package' name='com.eaio.util.lang' version='0.0.0'/>
        <provided namespace='java.package' name='com.eaio.uuid' version='0.0.0'/>
        <provided namespace='java.package' name='com.google.common.annotations' version='0.0.0'/>
        <provided namespace='java.package' name='com.google.common.base' version='0.0.0'/>
        <provided namespace='java.package' name='com.google.common.base.internal' version='0.0.0'/>
        <provided namespace='java.package' name='com.google.common.collect' version='0.0.0'/>
        <provided namespace='java.package' name='com.reardencommerce.kernel.collections.shared.evictable' version='0.0.0'/>
        <provided namespace='java.package' name='jline' version='0.0.0'/>
        <provided namespace='java.package' name='org.antlr' version='0.0.0'/>
        <provided namespace='java.package' name='org.antlr.analysis' version='0.0.0'/>
        <provided namespace='java.package' name='org.antlr.codegen' version='0.0.0'/>
        <provided namespace='java.package' name='org.antlr.grammar.v2' version='0.0.0'/>
        <provided namespace='java.package' name='org.antlr.grammar.v3' version='0.0.0'/>
        <provided namespace='java.package' name='org.antlr.gunit' version='0.0.0'/>
        <provided namespace='java.package' name='org.antlr.gunit.swingui' version='0.0.0'/>
        <provided namespace='java.package' name='org.antlr.gunit.swingui.images' version='0.0.0'/>
        <provided namespace='java.package' name='org.antlr.gunit.swingui.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.antlr.gunit.swingui.parsers' version='0.0.0'/>
        <provided namespace='java.package' name='org.antlr.gunit.swingui.runner' version='0.0.0'/>
        <provided namespace='java.package' name='org.antlr.misc' version='0.0.0'/>
        <provided namespace='java.package' name='org.antlr.runtime' version='0.0.0'/>
        <provided namespace='java.package' name='org.antlr.runtime.debug' version='0.0.0'/>
        <provided namespace='java.package' name='org.antlr.runtime.misc' version='0.0.0'/>
        <provided namespace='java.package' name='org.antlr.runtime.tree' version='0.0.0'/>
        <provided namespace='java.package' name='org.antlr.stringtemplate' version='0.0.0'/>
        <provided namespace='java.package' name='org.antlr.stringtemplate.language' version='0.0.0'/>
        <provided namespace='java.package' name='org.antlr.stringtemplate.misc' version='0.0.0'/>
        <provided namespace='java.package' name='org.antlr.stringtemplate.test' version='0.0.0'/>
        <provided namespace='java.package' name='org.antlr.tool' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.avro' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.avro.file' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.avro.genavro' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.avro.generic' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.avro.io' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.avro.io.parsing' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.avro.ipc' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.avro.ipc.stats' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.avro.reflect' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.avro.specific' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.avro.tool' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.avro.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.cassandra.auth' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.cassandra.avro' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.cassandra.cache' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.cassandra.cli' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.cassandra.client' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.cassandra.concurrent' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.cassandra.config' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.cassandra.db' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.cassandra.db.commitlog' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.cassandra.db.filter' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.cassandra.db.marshal' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.cassandra.dht' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.cassandra.gms' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.cassandra.hadoop' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.cassandra.io' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.cassandra.io.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.cassandra.locator' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.cassandra.net' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.cassandra.net.io' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.cassandra.net.sink' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.cassandra.service' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.cassandra.streaming' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.cassandra.thrift' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.cassandra.tools' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.cassandra.utils' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.cli' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.codec' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.codec.binary' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.codec.digest' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.codec.language' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.codec.net' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.collections' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.collections.bag' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.collections.bidimap' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.collections.buffer' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.collections.collection' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.collections.comparators' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.collections.functors' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.collections.iterators' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.collections.keyvalue' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.collections.list' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.collections.map' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.collections.set' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.lang' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.lang.builder' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.lang.enums' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.lang.exception' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.lang.math' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.lang.mutable' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.lang.text' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.lang.time' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.conf' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.filecache' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.fs' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.fs.ftp' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.fs.kfs' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.fs.permission' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.fs.s3' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.fs.s3native' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.fs.shell' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.hdfs' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.hdfs.protocol' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.hdfs.server.balancer' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.hdfs.server.common' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.hdfs.server.datanode' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.hdfs.server.datanode.metrics' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.hdfs.server.namenode' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.hdfs.server.namenode.metrics' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.hdfs.server.protocol' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.hdfs.tools' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.http' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.io' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.io.compress' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.io.compress.bzip2' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.io.compress.zlib' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.io.file.tfile' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.io.retry' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.io.serializer' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.ipc' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.ipc.metrics' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.log' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.mapred' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.mapred.jobcontrol' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.mapred.join' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.mapred.lib' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.mapred.lib.aggregate' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.mapred.lib.db' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.mapred.pipes' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.mapred.tools' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.mapreduce' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.mapreduce.lib.input' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.mapreduce.lib.map' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.mapreduce.lib.output' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.mapreduce.lib.partition' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.mapreduce.lib.reduce' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.metrics' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.metrics.file' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.metrics.ganglia' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.metrics.jvm' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.metrics.spi' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.metrics.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.net' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.record' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.record.compiler' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.record.compiler.ant' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.record.compiler.generated' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.record.meta' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.security' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.security.authorize' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.util.bloom' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.hadoop.util.hash' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.ivy' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.ivy.ant' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.ivy.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.ivy.core.cache' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.ivy.core.check' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.ivy.core.deliver' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.ivy.core.event' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.ivy.core.event.download' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.ivy.core.event.publish' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.ivy.core.event.resolve' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.ivy.core.event.retrieve' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.ivy.core.install' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.ivy.core.module.descriptor' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.ivy.core.module.id' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.ivy.core.module.status' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.ivy.core.publish' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.ivy.core.report' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.ivy.core.repository' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.ivy.core.resolve' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.ivy.core.retrieve' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.ivy.core.search' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.ivy.core.settings' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.ivy.core.sort' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.ivy.plugins' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.ivy.plugins.circular' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.ivy.plugins.conflict' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.ivy.plugins.latest' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.ivy.plugins.lock' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.ivy.plugins.matcher' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.ivy.plugins.namespace' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.ivy.plugins.parser' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.ivy.plugins.parser.m2' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.ivy.plugins.parser.xml' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.ivy.plugins.report' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.ivy.plugins.repository' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.ivy.plugins.repository.file' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.ivy.plugins.repository.sftp' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.ivy.plugins.repository.ssh' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.ivy.plugins.repository.url' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.ivy.plugins.repository.vfs' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.ivy.plugins.repository.vsftp' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.ivy.plugins.resolver' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.ivy.plugins.resolver.packager' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.ivy.plugins.resolver.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.ivy.plugins.trigger' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.ivy.plugins.version' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.ivy.tools.analyser' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.ivy.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.ivy.util.cli' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.ivy.util.extendable' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.ivy.util.filter' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.ivy.util.url' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.log4j' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.log4j.chainsaw' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.log4j.config' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.log4j.helpers' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.log4j.jdbc' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.log4j.jmx' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.log4j.lf5' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.log4j.lf5.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.log4j.lf5.viewer' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.log4j.lf5.viewer.categoryexplorer' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.log4j.lf5.viewer.configure' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.log4j.net' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.log4j.nt' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.log4j.or' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.log4j.or.jms' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.log4j.or.sax' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.log4j.spi' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.log4j.varia' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.log4j.xml' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.thrift' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.thrift.meta_data' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.thrift.protocol' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.thrift.server' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.thrift.transport' version='0.0.0'/>
        <provided namespace='java.package' name='org.cliffc.high_scale_lib' version='0.0.0'/>
        <provided namespace='java.package' name='org.codehaus.jackson' version='0.0.0'/>
        <provided namespace='java.package' name='org.codehaus.jackson.annotate' version='0.0.0'/>
        <provided namespace='java.package' name='org.codehaus.jackson.impl' version='0.0.0'/>
        <provided namespace='java.package' name='org.codehaus.jackson.io' version='0.0.0'/>
        <provided namespace='java.package' name='org.codehaus.jackson.map' version='0.0.0'/>
        <provided namespace='java.package' name='org.codehaus.jackson.map.annotate' version='0.0.0'/>
        <provided namespace='java.package' name='org.codehaus.jackson.map.deser' version='0.0.0'/>
        <provided namespace='java.package' name='org.codehaus.jackson.map.ext' version='0.0.0'/>
        <provided namespace='java.package' name='org.codehaus.jackson.map.introspect' version='0.0.0'/>
        <provided namespace='java.package' name='org.codehaus.jackson.map.ser' version='0.0.0'/>
        <provided namespace='java.package' name='org.codehaus.jackson.map.type' version='0.0.0'/>
        <provided namespace='java.package' name='org.codehaus.jackson.map.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.codehaus.jackson.node' version='0.0.0'/>
        <provided namespace='java.package' name='org.codehaus.jackson.schema' version='0.0.0'/>
        <provided namespace='java.package' name='org.codehaus.jackson.sym' version='0.0.0'/>
        <provided namespace='java.package' name='org.codehaus.jackson.type' version='0.0.0'/>
        <provided namespace='java.package' name='org.codehaus.jackson.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.json.simple' version='0.0.0'/>
        <provided namespace='java.package' name='org.json.simple.parser' version='0.0.0'/>
        <provided namespace='java.package' name='org.slf4j' version='0.0.0'/>
        <provided namespace='java.package' name='org.slf4j.helpers' version='0.0.0'/>
        <provided namespace='java.package' name='org.slf4j.impl' version='0.0.0'/>
        <provided namespace='java.package' name='org.slf4j.spi' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.coocox.lib.cassandra' version='1.0.0'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.coocox.lib.cassandra&#xA;Bundle-Version: 1.0.0
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.coocox.model' version='1.0.0'>
      <update id='org.coocox.model' range='[0.0.0,1.0.0)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='www.example.org'/>
        <property name='df_LT.pluginName' value='ConfigurationModel Model'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.coocox.model' version='1.0.0'/>
        <provided namespace='osgi.bundle' name='org.coocox.model' version='1.0.0'/>
        <provided namespace='java.package' name='projectmodel' version='0.0.0'/>
        <provided namespace='java.package' name='projectmodel.impl' version='0.0.0'/>
        <provided namespace='java.package' name='projectmodel.util' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.ecore' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.coocox.model' version='1.0.0'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.coocox.model;singleton:=true&#xA;Bundle-Version: 1.0.0
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.coocox.model.control' version='1.0.0.201410211009' singleton='false'>
      <update id='org.coocox.model.control' range='[0.0.0,1.0.0.201410211009)' severity='0'/>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.name' value='Control'/>
      </properties>
      <provides size='4'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.coocox.model.control' version='1.0.0.201410211009'/>
        <provided namespace='osgi.bundle' name='org.coocox.model.control' version='1.0.0.201410211009'/>
        <provided namespace='java.package' name='org.coocox.model.control.option' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='4'>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.model' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.utils' range='1.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.coocox.model.control' version='1.0.0.201410211009'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.coocox.model.control&#xA;Bundle-Version: 1.0.0.201410211009
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.coocox.repository.customize' version='1.0.0.201410211009' singleton='false'>
      <update id='org.coocox.repository.customize' range='[0.0.0,1.0.0.201410211009)' severity='0'/>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.name' value='Customize'/>
        <property name='org.eclipse.equinox.p2.provider' value='coocox'/>
      </properties>
      <provides size='4'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.coocox.repository.customize' version='1.0.0.201410211009'/>
        <provided namespace='osgi.bundle' name='org.coocox.repository.customize' version='1.0.0.201410211009'/>
        <provided namespace='java.package' name='org.coocox.repository.customize.actions' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='12'>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.forms' range='3.5.101'/>
        <required namespace='osgi.bundle' name='org.coocox.device.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.sqlite.rn' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.codb.client.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.component.front.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.component.board.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.example.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.codb.common.util' range='1.0.0'/>
        <required namespace='java.package' name='org.coocox.codb.common.dto' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.codb.common.model' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.coocox.repository.customize' version='1.0.0.201410211009'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.coocox.repository.customize&#xA;Bundle-Version: 1.0.0.201410211009
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.coocox.sqlite.rn' version='1.0.0.201410211009' singleton='false'>
      <update id='org.coocox.sqlite.rn' range='[0.0.0,1.0.0.201410211009)' severity='0'/>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.name' value='Rn'/>
        <property name='org.eclipse.equinox.p2.provider' value='coocox'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.coocox.sqlite.rn' version='1.0.0.201410211009'/>
        <provided namespace='osgi.bundle' name='org.coocox.sqlite.rn' version='1.0.0.201410211009'/>
        <provided namespace='java.package' name='org.coocox.sqlite.dao' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.sqlite.dao.impl' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.sqlite.dbsource' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.sqlite.page.bean' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.sqlite.rn' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='coocox_model_bundle' range='1.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.coocox.sqlite.rn' version='1.0.0.201410211009'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.coocox.sqlite.rn&#xA;Bundle-Version: 1.0.0.201410211009
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.coocox.user.ui' version='1.0.0.201410211009'>
      <update id='org.coocox.user.ui' range='[0.0.0,1.0.0.201410211009)' severity='0'/>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.name' value='Test'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.coocox.user.ui' version='1.0.0.201410211009'/>
        <provided namespace='osgi.bundle' name='org.coocox.user.ui' version='1.0.0.201410211009'/>
        <provided namespace='java.package' name='org.coocox.user.ui' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.user.ui.account' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.forms' range='3.5.101'/>
        <required namespace='osgi.bundle' name='org.coocox.utils' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.sqlite.rn' range='1.0.0'/>
        <required namespace='osgi.bundle' name='coocox_model_bundle' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.codb.client.core' range='1.0.0'/>
        <required namespace='java.package' name='org.coocox.utils.resource' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.coocox.user.ui' version='1.0.0.201410211009'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.coocox.user.ui;singleton:=true&#xA;Bundle-Version: 1.0.0.201410211009
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.coocox.userspace' version='1.0.0.201410211009'>
      <update id='org.coocox.userspace' range='[0.0.0,1.0.0.201410211009)' severity='0'/>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.name' value='UserSpace'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.coocox.userspace' version='1.0.0.201410211009'/>
        <provided namespace='osgi.bundle' name='org.coocox.userspace' version='1.0.0.201410211009'/>
        <provided namespace='java.package' name='org.coocox.userspace.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.userspace.table' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='22'>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='coocox_model_bundle' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.codb.client.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.sqlite.rn' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.draw2d' range='3.7.2'/>
        <required namespace='osgi.bundle' name='org.coocox.utils' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.builder.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.component.front.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.component.board.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.user.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.example.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.userspace.manage.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.component.front.ui' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.common.ui.action' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.component.basic.manage.core' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.component.board.ui' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.component.board.ui.actions' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.component.core' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.device.core' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.example' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.example.actions' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.coocox.userspace' version='1.0.0.201410211009'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.coocox.userspace;singleton:=true&#xA;Bundle-Version: 1.0.0.201410211009
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.coocox.userspace.manage.ui' version='1.0.0.201410211009' singleton='false'>
      <update id='org.coocox.userspace.manage.ui' range='[0.0.0,1.0.0.201410211009)' severity='0'/>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.name' value='Ui'/>
      </properties>
      <provides size='4'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.coocox.userspace.manage.ui' version='1.0.0.201410211009'/>
        <provided namespace='osgi.bundle' name='org.coocox.userspace.manage.ui' version='1.0.0.201410211009'/>
        <provided namespace='java.package' name='org.coocox.userspace.manage.ui.command' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='24'>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.example.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.component.board.core' range='1.0.0'/>
        <required namespace='java.package' name='org.coocox.coide.diy.extensionpoint' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.common.ui.action' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.common.ui.extension' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.common.ui.widgets' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.component.basic.manage.ui.command' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.component.board.core' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.component.board.core.model' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.component.board.manage.ui.command' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.component.board.ui.actions' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.component.board.ui.commands' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.component.board.ui.listener' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.component.core.model' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.component.driver.manage.ui.commands' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.component.ui.doxygen' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.component.ui.help' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.device.core' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.example.core' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.example.manage.ui.command' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.example.ui' range='0.0.0'/>
        <required namespace='java.package' name='org.coocox.uitils.sync' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.coocox.userspace.manage.ui' version='1.0.0.201410211009'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.coocox.userspace.manage.ui&#xA;Bundle-Version: 1.0.0.201410211009
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.coocox.utils' version='1.0.0.201410211009' singleton='false'>
      <update id='org.coocox.utils' range='[0.0.0,1.0.0.201410211009)' severity='0'/>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.name' value='Utils'/>
        <property name='org.eclipse.equinox.p2.provider' value='Clark.Zhou'/>
      </properties>
      <provides size='11'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.coocox.utils' version='1.0.0.201410211009'/>
        <provided namespace='osgi.bundle' name='org.coocox.utils' version='1.0.0.201410211009'/>
        <provided namespace='java.package' name='org.coocox.uitils.rcp' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.uitils.sync' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.utils' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.utils.io' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.utils.mvc' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.utils.resource' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.utils.tool' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.utils.ui' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.ide' range='3.7.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='3.7.101'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filesystem' range='1.3.100'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='3.7.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.debug.core' range='3.7.1'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.forms' range='3.5.101'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.editors' range='3.7.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.coocox.utils' version='1.0.0.201410211009'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.coocox.utils&#xA;Bundle-Version: 1.0.0.201410211009
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.coocox.welcome.ui' version='1.0.0.201410211009'>
      <update id='org.coocox.welcome.ui' range='[0.0.0,1.0.0.201410211009)' severity='0'/>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.name' value='Ui'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.coocox.welcome.ui' version='1.0.0.201410211009'/>
        <provided namespace='osgi.bundle' name='org.coocox.welcome.ui' version='1.0.0.201410211009'/>
        <provided namespace='java.package' name='org.coocox.welcome.ui.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.coocox.welcome.ui.command' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='11'>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.forms' range='3.5.101'/>
        <required namespace='osgi.bundle' name='org.coocox.component.front.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.component.board.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.device.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.utils' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.builder.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.codb.client.core' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.user.ui' range='1.0.0'/>
        <required namespace='osgi.bundle' name='coocox_model_bundle' range='1.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.coocox.welcome.ui' version='1.0.0.201410211009'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.coocox.welcome.ui;singleton:=true&#xA;Bundle-Version: 1.0.0.201410211009
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ant.core' version='3.2.302.v20120110-1739'>
      <update id='org.eclipse.ant.core' range='[0.0.0,3.2.302.v20120110-1739)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Ant Build Tool Core'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ant.core' version='3.2.302.v20120110-1739'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ant.core' version='3.2.302.v20120110-1739'/>
        <provided namespace='java.package' name='org.eclipse.ant.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ant.internal.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ant.internal.core.contentDescriber' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.core.variables' range='[3.1.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.2.0,4.0.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ant.core' version='3.2.302.v20120110-1739'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ant.core; singleton:=true&#xA;Bundle-Version: 3.2.302.v20120110-1739
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.cdt.core' version='5.3.2.201202111925'>
      <update id='org.eclipse.cdt.core' range='[0.0.0,5.3.2.201202111925)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.providerName' value='Eclipse CDT'/>
        <property name='df_LT.pluginName' value='C/C++ Development Tools Core'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.cdt'/>
        <property name='maven-artifactId' value='org.eclipse.cdt.core'/>
        <property name='maven-version' value='5.3.2-SNAPSHOT'/>
      </properties>
      <provides size='99'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cdt.core' version='5.3.2.201202111925'/>
        <provided namespace='osgi.bundle' name='org.eclipse.cdt.core' version='5.3.2.201202111925'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.browser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.cdtvariables' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.dom' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.dom.ast' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.dom.ast.c' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.dom.ast.cpp' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.dom.ast.gnu' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.dom.ast.gnu.c' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.dom.ast.gnu.cpp' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.dom.parser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.dom.parser.c' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.dom.parser.cpp' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.dom.rewrite' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.envvar' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.errorparsers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.formatter' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.index' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.index.export' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.index.provider' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.language' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.model.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.parser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.parser.ast' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.parser.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.resources' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.settings.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.settings.model.extension' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.settings.model.extension.impl' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.settings.model.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.templateengine' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.templateengine.process' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.templateengine.process.processes' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.browser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.cdtvariables' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.dom' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.dom.parser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.dom.parser.c' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.dom.parser.cpp' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.dom.parser.cpp.semantics' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.dom.rewrite' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.dom.rewrite.astwriter' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.dom.rewrite.changegenerator' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.dom.rewrite.commenthandler' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.dom.rewrite.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.envvar' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.index' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.index.composite' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.index.composite.c' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.index.composite.cpp' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.index.provider' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.indexer' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.language' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.model.ext' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.parser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.parser.problem' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.parser.scanner' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.parser.token' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.parser.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.pdom' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.pdom.db' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.pdom.dom' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.pdom.dom.c' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.pdom.dom.cpp' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.pdom.export' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.pdom.indexer' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.resources' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.settings.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.errorparsers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.formatter' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.formatter.align' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.formatter.scanner' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.utils' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.utils.cdtvariables' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.utils.coff' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.utils.coff.parser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.utils.debug' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.utils.debug.dwarf' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.utils.debug.stabs' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.utils.debug.tools' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.utils.elf' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.utils.elf.parser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.utils.envvar' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.utils.macho' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.utils.macho.parser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.utils.pty' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.utils.som' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.utils.som.parser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.utils.spawner' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.utils.xcoff' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.utils.xcoff.parser' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='9'>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.7.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.contenttype' range='[3.3.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.text' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.variables' range='[3.1.100,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filebuffers' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filesystem' range='[1.1.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ltk.core.refactoring' range='3.4.0'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.cdt.core' version='5.3.2.201202111925'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.cdt.core; singleton:=true&#xA;Bundle-Version: 5.3.2.201202111925
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.cdt.core.win32' version='5.2.0.201202111925'>
      <update id='org.eclipse.cdt.core.win32' range='[0.0.0,5.2.0.201202111925)' severity='0'/>
      <properties size='7'>
        <property name='df_LT.providerName' value='Eclipse CDT'/>
        <property name='org.eclipse.equinox.p2.name' value='%fragmentName.win32'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.cdt'/>
        <property name='maven-artifactId' value='org.eclipse.cdt.core.win32'/>
        <property name='maven-version' value='5.2.0-SNAPSHOT'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cdt.core.win32' version='5.2.0.201202111925'/>
        <provided namespace='osgi.bundle' name='org.eclipse.cdt.core.win32' version='5.2.0.201202111925'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='osgi.fragment' name='org.eclipse.cdt.core' version='5.2.0.201202111925'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.core' range='[5.2.0,6.0.0)'/>
      </requires>
      <filter>
        (osgi.os=win32)
      </filter>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.cdt.core.win32' version='5.2.0.201202111925'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.cdt.core.win32; singleton:=true&#xA;Bundle-Version: 5.2.0.201202111925&#xA;Fragment-Host: org.eclipse.cdt.core;bundle-version=&quot;[5.2.0,6.0.0)&quot;
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.cdt.core.win32.x86' version='5.2.0.201202111925'>
      <update id='org.eclipse.cdt.core.win32.x86' range='[0.0.0,5.2.0.201202111925)' severity='0'/>
      <properties size='6'>
        <property name='org.eclipse.equinox.p2.name' value='%fragmentName.win32.x86'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.cdt'/>
        <property name='maven-artifactId' value='org.eclipse.cdt.core.win32.x86'/>
        <property name='maven-version' value='5.2.0-SNAPSHOT'/>
      </properties>
      <provides size='4'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cdt.core.win32.x86' version='5.2.0.201202111925'/>
        <provided namespace='osgi.bundle' name='org.eclipse.cdt.core.win32.x86' version='5.2.0.201202111925'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='osgi.fragment' name='org.eclipse.cdt.core' version='5.2.0.201202111925'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.core' range='[5.2.0,6.0.0)'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86)(osgi.os=win32))
      </filter>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.cdt.core.win32.x86' version='5.2.0.201202111925'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.cdt.core.win32.x86;singleton:=true&#xA;Bundle-Version: 5.2.0.201202111925&#xA;Fragment-Host: org.eclipse.cdt.core;bundle-version=&quot;[5.2.0,6.0.0)&quot;
          </instruction>
          <instruction key='zipped'>
            true
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.cdt.debug.core' version='7.1.0.201202111925'>
      <update id='org.eclipse.cdt.debug.core' range='[0.0.0,7.1.0.201202111925)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse CDT'/>
        <property name='df_LT.pluginName' value='C/C++ Development Tools Debug Model'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='21'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cdt.debug.core' version='7.1.0.201202111925'/>
        <provided namespace='osgi.bundle' name='org.eclipse.cdt.debug.core' version='7.1.0.201202111925'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.core.breakpointactions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.core.cdi' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.core.cdi.event' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.core.cdi.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.core.cdi.model.type' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.core.command' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.core.disassembly' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.core.executables' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.core.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.core.model.provisional' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.core.sourcelookup' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.internal.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.internal.core.breakpoints' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.internal.core.executables' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.internal.core.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.internal.core.sourcelookup' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.debug.core' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.core' range='[5.0.0,6.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filesystem' range='1.2.0'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.cdt.debug.core' version='7.1.0.201202111925'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.cdt.debug.core; singleton:=true&#xA;Bundle-Version: 7.1.0.201202111925
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.cdt.debug.mi.core' version='7.1.1.201202111925'>
      <update id='org.eclipse.cdt.debug.mi.core' range='[0.0.0,7.1.1.201202111925)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse CDT'/>
        <property name='df_LT.pluginName' value='C/C++ Development Tools GDB/MI CDI Debugger Core'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='16'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cdt.debug.mi.core' version='7.1.1.201202111925'/>
        <provided namespace='osgi.bundle' name='org.eclipse.cdt.debug.mi.core' version='7.1.1.201202111925'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.mi.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.mi.core.cdi' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.mi.core.cdi.event' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.mi.core.cdi.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.mi.core.cdi.model.type' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.mi.core.command' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.mi.core.command.factories' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.mi.core.command.factories.linux' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.mi.core.command.factories.macos' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.mi.core.command.factories.win32' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.mi.core.event' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.mi.core.output' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.debug.core' range='[7.0.0,8.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.debug.core' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.core' range='[5.0.0,6.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.variables' range='3.2.200'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.gdb' range='7.0.0'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.cdt.debug.mi.core' version='7.1.1.201202111925'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.cdt.debug.mi.core; singleton:=true&#xA;Bundle-Version: 7.1.1.201202111925
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.cdt.debug.ui' version='7.1.2.201202111925'>
      <update id='org.eclipse.cdt.debug.ui' range='[0.0.0,7.1.2.201202111925)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse CDT'/>
        <property name='df_LT.pluginName' value='C/C++ Development Tools Debugger UI'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='35'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cdt.debug.ui' version='7.1.2.201202111925'/>
        <provided namespace='osgi.bundle' name='org.eclipse.cdt.debug.ui' version='7.1.2.201202111925'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.internal.ui' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.internal.ui.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.internal.ui.commands' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.internal.ui.dialogfields' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.internal.ui.dialogs' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.internal.ui.disassembly.commands' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.internal.ui.disassembly.dsf' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.internal.ui.disassembly.editor' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.internal.ui.disassembly.rendering' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.internal.ui.disassembly.viewer' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.internal.ui.editors' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.internal.ui.elements.adapters' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.internal.ui.launch' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.internal.ui.pinclone' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.internal.ui.preferences' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.internal.ui.propertypages' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.internal.ui.sourcelookup' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.internal.ui.views' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.internal.ui.views.executables' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.internal.ui.views.memory' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.internal.ui.views.modules' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.internal.ui.views.signals' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.ui' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.ui.breakpointactions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.ui.breakpoints' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.ui.disassembly' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.ui.editors' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.ui.importexecutable' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.ui.preferences' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.ui.provisional' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.ui.sourcelookup' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='17'>
        <required namespace='osgi.bundle' name='org.eclipse.ui.ide' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface.text' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.workbench.texteditor' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.editors' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.debug.ui' range='[3.7.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.debug.core' range='[3.7.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.debug.core' range='[7.0.0,8.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.ui' range='[5.0.0,6.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.core' range='[5.0.0,6.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.console' range='[3.1.100,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.views' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filesystem' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='0.0.0'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.cdt.debug.ui' version='7.1.2.201202111925'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.cdt.debug.ui; singleton:=true&#xA;Bundle-Version: 7.1.2.201202111925
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.cdt.debug.ui.memory.memorybrowser' version='1.2.100.201202111925'>
      <update id='org.eclipse.cdt.debug.ui.memory.memorybrowser' range='[0.0.0,1.2.100.201202111925)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse CDT'/>
        <property name='df_LT.pluginName' value='Memory Browser'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cdt.debug.ui.memory.memorybrowser' version='1.2.100.201202111925'/>
        <provided namespace='osgi.bundle' name='org.eclipse.cdt.debug.ui.memory.memorybrowser' version='1.2.100.201202111925'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.ui.memory.memorybrowser' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='9'>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.debug.core' range='3.5.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.debug.ui' range='3.5.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.debug.core' range='7.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.debug.ui' range='7.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.model.control' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.coocox.utils' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.debug.ui.memory.traditional' range='1.2.1'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.cdt.debug.ui.memory.memorybrowser' version='1.2.100.201202111925'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.cdt.debug.ui.memory.memorybrowser;singleton:=true&#xA;Bundle-Version: 1.2.100.201202111925
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.cdt.debug.ui.memory.search' version='1.2.1.201202111925'>
      <update id='org.eclipse.cdt.debug.ui.memory.search' range='[0.0.0,1.2.1.201202111925)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.providerName' value='Eclipse CDT'/>
        <property name='df_LT.pluginName' value='Memory Search'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.cdt'/>
        <property name='maven-artifactId' value='org.eclipse.cdt.debug.ui.memory.search'/>
        <property name='maven-version' value='1.2.1-SNAPSHOT'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cdt.debug.ui.memory.search' version='1.2.1.201202111925'/>
        <provided namespace='osgi.bundle' name='org.eclipse.cdt.debug.ui.memory.search' version='1.2.1.201202111925'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.ui.memory.search' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='9'>
        <required namespace='osgi.bundle' name='org.eclipse.debug.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.debug.ui' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.swt' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.search' range='3.4.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.debug.ui' range='6.0.0'/>
        <required namespace='java.package' name='org.eclipse.debug.ui.memory' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.cdt.debug.ui.memory.search' version='1.2.1.201202111925'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.cdt.debug.ui.memory.search;singleton:=true&#xA;Bundle-Version: 1.2.1.201202111925
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.cdt.debug.ui.memory.traditional' version='1.2.1.201202111925'>
      <update id='org.eclipse.cdt.debug.ui.memory.traditional' range='[0.0.0,1.2.1.201202111925)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.providerName' value='Eclipse CDT'/>
        <property name='df_LT.pluginName' value='Traditional Memory Rendering'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.cdt'/>
        <property name='maven-artifactId' value='org.eclipse.cdt.debug.ui.memory.traditional'/>
        <property name='maven-version' value='1.2.1-SNAPSHOT'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cdt.debug.ui.memory.traditional' version='1.2.1.201202111925'/>
        <provided namespace='osgi.bundle' name='org.eclipse.cdt.debug.ui.memory.traditional' version='1.2.1.201202111925'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.ui.memory.traditional' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='osgi.bundle' name='org.eclipse.debug.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.debug.ui' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.swt' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.search' range='3.4.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.debug.core' range='7.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.cdt.debug.ui.memory.traditional' version='1.2.1.201202111925'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.cdt.debug.ui.memory.traditional;singleton:=true&#xA;Bundle-Version: 1.2.1.201202111925
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.cdt.debug.ui.memory.transport' version='2.1.0.201202111925'>
      <update id='org.eclipse.cdt.debug.ui.memory.transport' range='[0.0.0,2.1.0.201202111925)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.providerName' value='Eclipse CDT'/>
        <property name='df_LT.pluginName' value='Memory Transport Plug-in'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.cdt'/>
        <property name='maven-artifactId' value='org.eclipse.cdt.debug.ui.memory.transport'/>
        <property name='maven-version' value='2.1.0-SNAPSHOT'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cdt.debug.ui.memory.transport' version='2.1.0.201202111925'/>
        <provided namespace='osgi.bundle' name='org.eclipse.cdt.debug.ui.memory.transport' version='2.1.0.201202111925'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.ui.memory.transport' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.ui.memory.transport.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.debug.ui.memory.transport.model' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='osgi.bundle' name='org.eclipse.debug.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.debug.ui' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.swt' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.cdt.debug.ui.memory.transport' version='2.1.0.201202111925'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.cdt.debug.ui.memory.transport;singleton:=true&#xA;Bundle-Version: 2.1.0.201202111925
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.cdt.dsf' version='2.2.0.201202111925'>
      <update id='org.eclipse.cdt.dsf' range='[0.0.0,2.2.0.201202111925)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.providerName' value='Eclipse CDT'/>
        <property name='df_LT.pluginName' value='Debug Services Framework Core'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.cdt'/>
        <property name='maven-artifactId' value='org.eclipse.cdt.dsf'/>
        <property name='maven-version' value='2.2.0-SNAPSHOT'/>
      </properties>
      <provides size='14'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cdt.dsf' version='2.2.0.201202111925'/>
        <provided namespace='osgi.bundle' name='org.eclipse.cdt.dsf' version='2.2.0.201202111925'/>
        <provided namespace='java.package' name='org.eclipse.cdt.dsf.concurrent' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.dsf.datamodel' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.dsf.debug.internal.provisional.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.dsf.debug.internal.provisional.service' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.dsf.debug.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.dsf.debug.service' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.dsf.debug.service.command' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.dsf.debug.sourcelookup' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.dsf.internal' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.dsf.service' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='4'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.debug.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.debug.core' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.cdt.dsf' version='2.2.0.201202111925'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.cdt.dsf;singleton:=true&#xA;Bundle-Version: 2.2.0.201202111925
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.cdt.dsf.ui' version='2.2.1.201202111925'>
      <update id='org.eclipse.cdt.dsf.ui' range='[0.0.0,2.2.1.201202111925)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse CDT'/>
        <property name='df_LT.pluginName' value='Debugger Services Framework UI'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='44'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cdt.dsf.ui' version='2.2.1.201202111925'/>
        <provided namespace='osgi.bundle' name='org.eclipse.cdt.dsf.ui' version='2.2.1.201202111925'/>
        <provided namespace='java.package' name='org.eclipse.cdt.dsf.debug.internal.ui' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.dsf.debug.internal.ui.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.dsf.debug.internal.ui.debugview.layout' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.dsf.debug.internal.ui.debugview.layout.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.dsf.debug.internal.ui.disassembly' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.dsf.debug.internal.ui.disassembly.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.dsf.debug.internal.ui.disassembly.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.dsf.debug.internal.ui.disassembly.preferences' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.dsf.debug.internal.ui.disassembly.presentation' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.dsf.debug.internal.ui.disassembly.provisional' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.dsf.debug.internal.ui.disassembly.text' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.dsf.debug.internal.ui.disassembly.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.dsf.debug.internal.ui.preferences' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.dsf.debug.internal.ui.viewmodel' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.dsf.debug.internal.ui.viewmodel.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.dsf.debug.internal.ui.viewmodel.detailsupport' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.dsf.debug.internal.ui.viewmodel.numberformat.detail' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.dsf.debug.ui' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.dsf.debug.ui.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.dsf.debug.ui.contexts' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.dsf.debug.ui.memory' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.dsf.debug.ui.sourcelookup' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.dsf.debug.ui.viewmodel' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.dsf.debug.ui.viewmodel.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.dsf.debug.ui.viewmodel.breakpoints' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.dsf.debug.ui.viewmodel.expression' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.dsf.debug.ui.viewmodel.launch' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.dsf.debug.ui.viewmodel.launch.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.dsf.debug.ui.viewmodel.modules' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.dsf.debug.ui.viewmodel.modules.detail' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.dsf.debug.ui.viewmodel.numberformat' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.dsf.debug.ui.viewmodel.register' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.dsf.debug.ui.viewmodel.update' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.dsf.debug.ui.viewmodel.variable' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.dsf.internal.ui' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.dsf.ui.concurrent' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.dsf.ui.viewmodel' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.dsf.ui.viewmodel.datamodel' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.dsf.ui.viewmodel.properties' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.dsf.ui.viewmodel.update' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='14'>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='3.5.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='3.5.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.debug.ui' range='3.5.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.dsf' range='2.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.core' range='5.1.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.debug.core' range='6.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.debug.ui' range='6.1.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface.text' range='3.4.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.editors' range='3.4.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.ide' range='3.5.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.ui' range='5.1.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='3.4.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filesystem' range='1.2.0'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.cdt.dsf.ui' version='2.2.1.201202111925'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.cdt.dsf.ui;singleton:=true&#xA;Bundle-Version: 2.2.1.201202111925
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.cdt.gdb' version='7.0.0.201202111925'>
      <update id='org.eclipse.cdt.gdb' range='[0.0.0,7.0.0.201202111925)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.providerName' value='Eclipse CDT'/>
        <property name='df_LT.pluginName' value='GDB Common'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.cdt'/>
        <property name='maven-artifactId' value='org.eclipse.cdt.gdb'/>
        <property name='maven-version' value='7.0.0-SNAPSHOT'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cdt.gdb' version='7.0.0.201202111925'/>
        <provided namespace='osgi.bundle' name='org.eclipse.cdt.gdb' version='7.0.0.201202111925'/>
        <provided namespace='java.package' name='org.eclipse.cdt.gdb.eventbkpts' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.gdb.internal' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.gdb.internal.eventbkpts' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='3.6.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.cdt.gdb' version='7.0.0.201202111925'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.cdt.gdb;singleton:=true&#xA;Bundle-Version: 7.0.0.201202111925
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.cdt.launch' version='7.0.0.201202111925'>
      <update id='org.eclipse.cdt.launch' range='[0.0.0,7.0.0.201202111925)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.providerName' value='Eclipse CDT'/>
        <property name='df_LT.pluginName' value='C/C++ Development Tools Launching Support'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.cdt'/>
        <property name='maven-artifactId' value='org.eclipse.cdt.launch'/>
        <property name='maven-version' value='7.0.0-SNAPSHOT'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cdt.launch' version='7.0.0.201202111925'/>
        <provided namespace='osgi.bundle' name='org.eclipse.cdt.launch' version='7.0.0.201202111925'/>
        <provided namespace='java.package' name='org.eclipse.cdt.launch' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.launch.internal' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.launch.internal.refactoring' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.launch.internal.ui' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.launch.ui' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='14'>
        <required namespace='osgi.bundle' name='org.eclipse.ui.ide' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.debug.core' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.debug.ui' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.core' range='[5.0.0,6.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.ui' range='[5.0.0,6.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.debug.core' range='[7.0.0,8.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.debug.ui' range='[7.0.0,8.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.variables' range='[3.1.100,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ltk.core.refactoring' range='[3.5.0,4.0.0)'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.cdt.launch' version='7.0.0.201202111925'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.cdt.launch; singleton:=true&#xA;Bundle-Version: 7.0.0.201202111925
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.cdt.ui' version='5.3.2.201202111925'>
      <update id='org.eclipse.cdt.ui' range='[0.0.0,5.3.2.201202111925)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse CDT'/>
        <property name='df_LT.pluginName' value='C/C++ Development Tools UI'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='93'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cdt.ui' version='5.3.2.201202111925'/>
        <provided namespace='osgi.bundle' name='org.eclipse.cdt.ui' version='5.3.2.201202111925'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.corext' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.corext.codemanipulation' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.corext.fix' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.corext.template.c' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.corext.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.browser.opentype' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.build' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.buildconsole' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.callhierarchy' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.compare' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.cview' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.dialogs' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.dialogs.cpaths' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.dnd' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.editor' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.editor.asm' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.filters' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.help' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.includebrowser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.indexview' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.language' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.navigator' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.newui' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.preferences' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.preferences.formatter' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.refactoring' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.refactoring.dialogs' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.refactoring.extractconstant' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.refactoring.extractfunction' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.refactoring.extractlocalvariable' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.refactoring.gettersandsetters' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.refactoring.hidemethod' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.refactoring.implementmethod' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.refactoring.rename' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.refactoring.togglefunction' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.refactoring.utils' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.resources' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.search' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.search.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.text' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.text.asm' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.text.c.hover' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.text.contentassist' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.text.correction' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.text.correction.proposals' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.text.doctools' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.text.folding' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.text.spelling' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.text.spelling.engine' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.text.template' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.text.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.typehierarchy' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.viewsupport' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.wizards' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.wizards.classwizard' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.wizards.dialogfields' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.wizards.filewizard' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.wizards.folderwizard' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.wizards.indexwizards' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.wizards.settingswizards' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.ui.workingsets' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.ui' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.ui.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.ui.browser.typeinfo' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.ui.dialogs' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.ui.internal.templateengine.wizard' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.ui.newui' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.ui.refactoring' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.ui.refactoring.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.ui.resources' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.ui.templateengine' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.ui.templateengine.event' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.ui.templateengine.pages' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.ui.templateengine.processes' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.ui.templateengine.uitree' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.ui.templateengine.uitree.uiwidgets' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.ui.text' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.ui.text.c.hover' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.ui.text.contentassist' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.ui.text.doctools' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.ui.text.doctools.doxygen' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.ui.text.doctools.generic' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.ui.text.folding' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.ui.wizards' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.ui.wizards.conversion' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.utils.ui.controls' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='21'>
        <required namespace='osgi.bundle' name='org.eclipse.ui.ide' range='[3.3.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.views' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface.text' range='[3.4.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.workbench.texteditor' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.editors' range='[3.3.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='[3.3.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.forms' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.search' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.compare' range='[3.3.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.core' range='[5.2.0,6.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.console' range='[3.1.100,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.7.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.help' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.navigator' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filesystem' range='[1.1.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.variables' range='[3.1.100,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ltk.core.refactoring' range='3.4.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ltk.ui.refactoring' range='3.4.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.navigator.resources' range='3.3.100'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.cdt.ui' version='5.3.2.201202111925'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.cdt.ui; singleton:=true&#xA;Bundle-Version: 5.3.2.201202111925
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.compare' version='3.5.202.R37x_v20111109-0800'>
      <update id='org.eclipse.compare' range='[0.0.0,3.5.202.R37x_v20111109-0800)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Compare Support'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='11'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.compare' version='3.5.202.R37x_v20111109-0800'/>
        <provided namespace='osgi.bundle' name='org.eclipse.compare' version='3.5.202.R37x_v20111109-0800'/>
        <provided namespace='java.package' name='org.eclipse.compare' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.compare.contentmergeviewer' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.compare.internal' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.compare.internal.merge' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.compare.internal.patch' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.compare.patch' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.compare.structuremergeviewer' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='13'>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='[3.4.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface.text' range='[3.3.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.ide' range='[3.3.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.views' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.workbench.texteditor' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.editors' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.forms' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.compare.core' range='[3.5.0,4.0.0)'/>
        <required namespace='java.package' name='com.ibm.icu.util' range='0.0.0'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.compare' version='3.5.202.R37x_v20111109-0800'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.compare; singleton:=true&#xA;Bundle-Version: 3.5.202.R37x_v20111109-0800
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.compare.core' version='3.5.200.I20110208-0800' singleton='false'>
      <update id='org.eclipse.compare.core' range='[0.0.0,3.5.200.I20110208-0800)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Core Compare Support'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.compare.core' version='3.5.200.I20110208-0800'/>
        <provided namespace='osgi.bundle' name='org.eclipse.compare.core' version='3.5.200.I20110208-0800'/>
        <provided namespace='java.package' name='org.eclipse.compare.internal.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.compare.internal.core.patch' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.compare.patch' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.compare.rangedifferencer' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.2.0,4.0.0)'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='3.6.1'/>
        <required namespace='java.package' name='com.ibm.icu.util' range='3.6.1'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.compare.core' version='3.5.200.I20110208-0800'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.compare.core&#xA;Bundle-Version: 3.5.200.I20110208-0800
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.commands' version='3.6.0.I20110111-0800' singleton='false'>
      <update id='org.eclipse.core.commands' range='[0.0.0,3.6.0.I20110111-0800)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Commands'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='11'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.commands' version='3.6.0.I20110111-0800'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.commands' version='3.6.0.I20110111-0800'/>
        <provided namespace='java.package' name='org.eclipse.core.commands' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.commands.common' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.commands.contexts' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.commands.operations' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.commands.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.commands.operations' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.commands.util' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.commands' version='3.6.0.I20110111-0800'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.commands&#xA;Bundle-Version: 3.6.0.I20110111-0800
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.contenttype' version='3.4.100.v20110423-0524'>
      <update id='org.eclipse.core.contenttype' range='[0.0.0,3.4.100.v20110423-0524)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Eclipse Content Mechanism'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.contenttype' version='3.4.100.v20110423-0524'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.contenttype' version='3.4.100.v20110423-0524'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.content' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.content' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='11'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.preferences' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.ext' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.contenttype' version='3.4.100.v20110423-0524'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.contenttype; singleton:=true&#xA;Bundle-Version: 3.4.100.v20110423-0524
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.databinding' version='1.4.0.I20110111-0800' singleton='false'>
      <update id='org.eclipse.core.databinding' range='[0.0.0,1.4.0.I20110111-0800)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='JFace Data Binding'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding' version='1.4.0.I20110111-0800'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.databinding' version='1.4.0.I20110111-0800'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.conversion' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.validation' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.databinding' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.databinding.conversion' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.databinding.validation' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.databinding.observable' range='[1.3.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.databinding.property' range='[1.3.0,2.0.0)'/>
        <required namespace='java.package' name='com.ibm.icu.math' range='0.0.0' optional='true'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.4.0,2.0.0)' optional='true'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='[1.3.3,2.0.0)' optional='true'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='[1.0.0,2.0.0)' optional='true'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.databinding' version='1.4.0.I20110111-0800'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.databinding&#xA;Bundle-Version: 1.4.0.I20110111-0800
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.databinding.observable' version='1.4.0.I20110222-0800' singleton='false'>
      <update id='org.eclipse.core.databinding.observable' range='[0.0.0,1.4.0.I20110222-0800)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='JFace Data Binding Observables'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='14'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.observable' version='1.4.0.I20110222-0800'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.databinding.observable' version='1.4.0.I20110222-0800'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.observable' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.observable.list' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.observable.map' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.observable.masterdetail' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.observable.set' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.observable.value' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.databinding.identity' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.databinding.observable' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.databinding.observable.masterdetail' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='4'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.4.0,2.0.0)' optional='true'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='[1.3.3,2.0.0)' optional='true'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='[1.0.0,2.0.0)' optional='true'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.databinding.observable' version='1.4.0.I20110222-0800'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.databinding.observable&#xA;Bundle-Version: 1.4.0.I20110222-0800
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.databinding.property' version='1.4.0.I20110222-0800' singleton='false'>
      <update id='org.eclipse.core.databinding.property' range='[0.0.0,1.4.0.I20110222-0800)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='JFace Data Binding'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='14'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.property' version='1.4.0.I20110222-0800'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.databinding.property' version='1.4.0.I20110222-0800'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.property' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.property.list' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.property.map' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.property.set' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.property.value' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.databinding.property' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.databinding.property.list' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.databinding.property.map' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.databinding.property.set' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.databinding.property.value' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.databinding.observable' range='[1.3.0,2.0.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.databinding.property' version='1.4.0.I20110222-0800'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.databinding.property&#xA;Bundle-Version: 1.4.0.I20110222-0800
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.expressions' version='3.4.300.v20110228'>
      <update id='org.eclipse.core.expressions' range='[0.0.0,3.4.300.v20110228)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Expression Language'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.expressions' version='3.4.300.v20110228'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.expressions' version='3.4.300.v20110228'/>
        <provided namespace='java.package' name='org.eclipse.core.expressions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.expressions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.expressions.propertytester' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.expressions.util' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.3.0,4.0.0)'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.expressions' version='3.4.300.v20110228'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.expressions; singleton:=true&#xA;Bundle-Version: 3.4.300.v20110228
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.filebuffers' version='3.5.200.v20110928-1504'>
      <update id='org.eclipse.core.filebuffers' range='[0.0.0,3.5.200.v20110928-1504)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='File Buffers'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filebuffers' version='3.5.200.v20110928-1504'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.filebuffers' version='3.5.200.v20110928-1504'/>
        <provided namespace='java.package' name='org.eclipse.core.filebuffers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.filebuffers.manipulation' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.filebuffers' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.7.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='[3.5.0,4.0.0)' optional='true'/>
        <required namespace='osgi.bundle' name='org.eclipse.text' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filesystem' range='[1.2.0,2.0.0)'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.filebuffers' version='3.5.200.v20110928-1504'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.filebuffers; singleton:=true&#xA;Bundle-Version: 3.5.200.v20110928-1504
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.filesystem' version='1.3.100.v20110423-0524'>
      <update id='org.eclipse.core.filesystem' range='[0.0.0,1.3.100.v20110423-0524)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Core File Systems'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem' version='1.3.100.v20110423-0524'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.filesystem' version='1.3.100.v20110423-0524'/>
        <provided namespace='java.package' name='org.eclipse.core.filesystem' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.filesystem.provider' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.filesystem' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.filesystem.local' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='[3.2.0,4.0.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.filesystem' version='1.3.100.v20110423-0524'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.filesystem; singleton:=true&#xA;Bundle-Version: 1.3.100.v20110423-0524
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.filesystem.win32.x86' version='1.1.300.v20110423-0524'>
      <update id='org.eclipse.core.filesystem.win32.x86' range='[0.0.0,1.1.300.v20110423-0524)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.fragmentName' value='Core File System for Windows'/>
        <property name='org.eclipse.equinox.p2.name' value='%fragmentName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='fragment'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.win32.x86' version='1.1.300.v20110423-0524'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.filesystem.win32.x86' version='1.1.300.v20110423-0524'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='osgi.fragment' name='org.eclipse.core.filesystem' version='1.1.300.v20110423-0524'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.eclipse.core.filesystem' range='[1.1.0,2.0.0)'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86)(osgi.os=win32))
      </filter>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.filesystem.win32.x86' version='1.1.300.v20110423-0524'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.filesystem.win32.x86; singleton:=true&#xA;Bundle-Version: 1.1.300.v20110423-0524&#xA;Fragment-Host: org.eclipse.core.filesystem;bundle-version=&quot;[1.1.0,2.0.0)&quot;
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.jobs' version='3.5.101.v20120113-1953'>
      <update id='org.eclipse.core.jobs' range='[0.0.0,3.5.101.v20120113-1953)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Eclipse Jobs Mechanism'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.jobs' version='3.5.101.v20120113-1953'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.jobs' version='3.5.101.v20120113-1953'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.jobs' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.jobs' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.jobs' version='3.5.101.v20120113-1953'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.jobs; singleton:=true&#xA;Bundle-Version: 3.5.101.v20120113-1953
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.resources' version='3.7.101.v20120125-1505'>
      <update id='org.eclipse.core.resources' range='[0.0.0,3.7.101.v20120125-1505)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Core Resource Management'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='22'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.resources' version='3.7.101.v20120125-1505'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.resources' version='3.7.101.v20120125-1505'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.dtree' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.events' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.localstore' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.properties' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.propertytester' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.refresh' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.resources' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.resources.mapping' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.resources.projectvariables' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.resources.refresh.win32' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.utils' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.watson' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.resources' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.resources.filtermatchers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.resources.mapping' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.resources.refresh' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.resources.team' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.resources.variableresolvers' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='4'>
        <required namespace='osgi.bundle' name='org.eclipse.ant.core' range='[3.1.0,4.0.0)' optional='true'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filesystem' range='[1.3.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.7.0,4.0.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.resources' version='3.7.101.v20120125-1505'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.resources; singleton:=true&#xA;Bundle-Version: 3.7.101.v20120125-1505
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.resources.win32.x86' version='3.5.100.v20110423-0524'>
      <update id='org.eclipse.core.resources.win32.x86' range='[0.0.0,3.5.100.v20110423-0524)' severity='0'/>
      <properties size='3'>
        <property name='org.eclipse.equinox.p2.name' value='%win32FragmentName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='4'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.resources.win32.x86' version='3.5.100.v20110423-0524'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.resources.win32.x86' version='3.5.100.v20110423-0524'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='osgi.fragment' name='org.eclipse.core.resources' version='3.5.100.v20110423-0524'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='[3.5.0,4.0.0)'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86)(osgi.os=win32))
      </filter>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.resources.win32.x86' version='3.5.100.v20110423-0524'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.resources.win32.x86;singleton:=true&#xA;Bundle-Version: 3.5.100.v20110423-0524&#xA;Fragment-Host: org.eclipse.core.resources;bundle-version=&quot;[3.5.0,4.0.0)&quot;
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.runtime' version='3.7.0.v20110110'>
      <update id='org.eclipse.core.runtime' range='[0.0.0,3.7.0.v20110110)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Core Runtime'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.runtime' version='3.7.0.v20110110'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.runtime' version='3.7.0.v20110110'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.preferences.legacy' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.runtime' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime' version='3.4.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='9'>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='[3.7.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.jobs' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.4.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.preferences' range='[3.4.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.contenttype' range='[3.3.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime.compatibility.auth' range='[3.2.0,4.0.0)' optional='true'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.app' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.internal.runtime.auth' range='0.0.0' optional='true'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.runtime' version='3.7.0.v20110110'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.runtime; singleton:=true&#xA;Bundle-Version: 3.7.0.v20110110
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.runtime.compatibility' version='3.2.100.v20100505'>
      <update id='org.eclipse.core.runtime.compatibility' range='[0.0.0,3.2.100.v20100505)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Core Runtime Plug-in Compatibility'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.runtime.compatibility' version='3.2.100.v20100505'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.runtime.compatibility' version='3.2.100.v20100505'/>
        <provided namespace='java.package' name='org.eclipse.core.boot' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.boot' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.compatibility' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.plugins' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.model' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.update.configurator' range='[3.1.100,4.0.0)'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.runtime.compatibility' version='3.2.100.v20100505'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.runtime.compatibility; singleton:=true&#xA;Bundle-Version: 3.2.100.v20100505
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.runtime.compatibility.registry' version='3.5.0.v20110505' singleton='false'>
      <update id='org.eclipse.core.runtime.compatibility.registry' range='[0.0.0,3.5.0.v20110505)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.fragmentName' value='Eclipse Registry Compatibility Fragment'/>
        <property name='org.eclipse.equinox.p2.name' value='%fragmentName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='fragment'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.runtime.compatibility.registry' version='3.5.0.v20110505'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.runtime.compatibility.registry' version='3.5.0.v20110505'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='osgi.fragment' name='org.eclipse.equinox.registry' version='3.5.0.v20110505'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.5.0,3.6.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.runtime.compatibility.registry' version='3.5.0.v20110505'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.runtime.compatibility.registry&#xA;Bundle-Version: 3.5.0.v20110505&#xA;Fragment-Host: org.eclipse.equinox.registry;bundle-version=&quot;[3.5.0,3.6.0)&quot;
          </instruction>
          <instruction key='zipped'>
            true
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.variables' version='3.2.500.v20110928-1503'>
      <update id='org.eclipse.core.variables' range='[0.0.0,3.2.500.v20110928-1503)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Core Variables'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.variables' version='3.2.500.v20110928-1503'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.variables' version='3.2.500.v20110928-1503'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.variables' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.variables' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.3.0,4.0.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.variables' version='3.2.500.v20110928-1503'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.variables; singleton:=true&#xA;Bundle-Version: 3.2.500.v20110928-1503
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.debug.core' version='3.7.1.v20111129-2031'>
      <update id='org.eclipse.debug.core' range='[0.0.0,3.7.1.v20111129-2031)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Debug Core'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='14'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.debug.core' version='3.7.1.v20111129-2031'/>
        <provided namespace='osgi.bundle' name='org.eclipse.debug.core' version='3.7.1.v20111129-2031'/>
        <provided namespace='java.package' name='org.eclipse.debug.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.core.commands' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.core.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.core.sourcelookup' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.core.sourcelookup.containers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.core.commands' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.core.sourcelookup' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.core.sourcelookup.containers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.core.variables' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.variables' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filesystem' range='[1.2.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='[3.4.0,4.0.0)'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.debug.core' version='3.7.1.v20111129-2031'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.debug.core; singleton:=true&#xA;Bundle-Version: 3.7.1.v20111129-2031
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.debug.ui' version='3.7.102.v20111129-1423_r372'>
      <update id='org.eclipse.debug.ui' range='[0.0.0,3.7.102.v20111129-1423_r372)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Debug UI'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='49'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.debug.ui' version='3.7.102.v20111129-1423_r372'/>
        <provided namespace='osgi.bundle' name='org.eclipse.debug.ui' version='3.7.102.v20111129-1423_r372'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.actions.breakpointGroups' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.actions.breakpoints' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.actions.expressions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.actions.variables' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.actions.variables.details' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.breakpoints.provisional' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.commands.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.contextlaunching' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.contexts' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.elements.adapters' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.importexport.breakpoints' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.importexport.launchconfigurations' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.launchConfigurations' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.memory' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.memory.provisional' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.model.elements' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.preferences' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.sourcelookup' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.sourcelookup.browsers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.stringsubstitution' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.viewers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.viewers.breadcrumb' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.viewers.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.viewers.model.provisional' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.viewers.provisional' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.viewers.update' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.views' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.views.breakpoints' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.views.console' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.views.expression' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.views.launch' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.views.memory' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.views.memory.renderings' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.views.modules' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.views.registers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.views.variables' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.views.variables.details' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.ui' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.ui.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.ui.console' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.ui.contexts' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.ui.memory' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.ui.sourcelookup' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='14'>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='[3.4.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.variables' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.console' range='[3.4.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.help' range='[3.4.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.debug.core' range='[3.7.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface.text' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.workbench.texteditor' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.ide' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.editors' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filesystem' range='[1.2.0,2.0.0)'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.ui.forms.widgets' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.debug.ui' version='3.7.102.v20111129-1423_r372'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.debug.ui; singleton:=true&#xA;Bundle-Version: 3.7.102.v20111129-1423_r372
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.draw2d' version='3.7.2.v20111017-2020' singleton='false'>
      <update id='org.eclipse.draw2d' range='[0.0.0,3.7.2.v20111017-2020)' severity='0'/>
      <properties size='4'>
        <property name='df_LT.Plugin.name' value='Graphical Editing Framework Draw2d'/>
        <property name='df_LT.Plugin.providerName' value='Eclipse Modeling Project'/>
        <property name='org.eclipse.equinox.p2.name' value='%Plugin.name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%Plugin.providerName'/>
      </properties>
      <provides size='12'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.draw2d' version='3.7.2.v20111017-2020'/>
        <provided namespace='osgi.bundle' name='org.eclipse.draw2d' version='3.7.2.v20111017-2020'/>
        <provided namespace='java.package' name='org.eclipse.draw2d' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.draw2d.graph' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.draw2d.geometry' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.draw2d.images' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.draw2d.internal' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.draw2d.parts' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.draw2d.text' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.draw2d.widgets' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.swt' range='[3.2.0,4.0.0)'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='[3.8.1,5.0.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.draw2d' version='3.7.2.v20111017-2020'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-ManifestVersion: 2&#xA;Export-Package: org.eclipse.draw2d,org.eclipse.draw2d.graph,org.eclipse.draw2d.geometry,org.eclipse.draw2d.images,org.eclipse.draw2d.internal;x-internal:=true,org.eclipse.draw2d.parts,org.eclipse.draw2d.text,org.eclipse.draw2d.widgets&#xA;Bundle-RequiredExecutionEnvironment: J2SE-1.4&#xA;Bundle-Localization: plugin&#xA;Require-Bundle: org.eclipse.swt;visibility:=reexport;bundle-version=&quot;[3.2.0,4.0.0)&quot;&#xA;Bundle-Name: %Plugin.name&#xA;Bundle-Version: 3.7.2.v20111017-2020&#xA;Bundle-Vendor: %Plugin.providerName&#xA;Bundle-SymbolicName: org.eclipse.draw2d&#xA;Import-Package: com.ibm.icu.text;version=&quot;[3.8.1,5.0.0)&quot;&#xA;Bundle-ActivationPolicy: lazy&#xA;Manifest-Version: 1.0
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.emf.common' version='2.7.0.v20120127-1122'>
      <update id='org.eclipse.emf.common' range='[0.0.0,2.7.0.v20120127-1122)' severity='0'/>
      <properties size='6'>
        <property name='df_LT.providerName' value='Eclipse Modeling Project'/>
        <property name='df_LT.pluginName' value='EMF Common'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='buckminster.build.id' value='R201201271122'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.common' version='2.7.0.v20120127-1122'/>
        <provided namespace='osgi.bundle' name='org.eclipse.emf.common' version='2.7.0.v20120127-1122'/>
        <provided namespace='java.package' name='org.eclipse.emf.common' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.common.archive' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.common.command' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.common.notify' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.common.notify.impl' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.common.util' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.7.0,4.0.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.emf.common' version='2.7.0.v20120127-1122'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.emf.common;singleton:=true&#xA;Bundle-Version: 2.7.0.v20120127-1122
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.emf.ecore' version='2.7.0.v20120127-1122'>
      <update id='org.eclipse.emf.ecore' range='[0.0.0,2.7.0.v20120127-1122)' severity='0'/>
      <properties size='6'>
        <property name='df_LT.providerName' value='Eclipse Modeling Project'/>
        <property name='df_LT.pluginName' value='EMF Ecore'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='buckminster.build.id' value='R201201271122'/>
      </properties>
      <provides size='17'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore' version='2.7.0.v20120127-1122'/>
        <provided namespace='osgi.bundle' name='org.eclipse.emf.ecore' version='2.7.0.v20120127-1122'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.impl' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.plugin' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.resource' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.resource.impl' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xml.namespace' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xml.namespace.impl' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xml.namespace.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xml.type' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xml.type.impl' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xml.type.internal' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xml.type.util' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.7.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.common' range='[2.7.0,3.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='[3.7.0,4.0.0)' optional='true'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.emf.ecore' version='2.7.0.v20120127-1122'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.emf.ecore; singleton:=true&#xA;Bundle-Version: 2.7.0.v20120127-1122
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.app' version='1.3.100.v20110321'>
      <update id='org.eclipse.equinox.app' range='[0.0.0,1.3.100.v20110321)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.pluginName' value='Equinox Application Container'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.app' version='1.3.100.v20110321'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.app' version='1.3.100.v20110321'/>
        <provided namespace='java.package' name='org.eclipse.equinox.app' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.app' version='0.0.0'/>
        <provided namespace='java.package' name='org.osgi.service.application' version='1.1.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='16'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.4.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.event' range='1.0.0' optional='true'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.console' range='0.0.0' optional='true'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.runnable' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.storagemanager' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.condpermadmin' range='0.0.0' optional='true'/>
        <required namespace='java.package' name='org.osgi.service.event' range='1.0.0' optional='true'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.app' version='1.3.100.v20110321'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.app; singleton:=true&#xA;Bundle-Version: 1.3.100.v20110321
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.common' version='3.6.0.v20110523'>
      <update id='org.eclipse.equinox.common' range='[0.0.0,3.6.0.v20110523)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.pluginName' value='Common Eclipse Runtime'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.common' version='3.6.0.v20110523'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.common' version='3.6.0.v20110523'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.boot' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.runtime' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime' version='3.4.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.events' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='12'>
        <required namespace='java.package' name='org.eclipse.equinox.log' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='[1.1.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.localization' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.urlconversion' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.service.log' range='[1.3.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.service.url' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.common' version='3.6.0.v20110523'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.common; singleton:=true&#xA;Bundle-Version: 3.6.0.v20110523
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.http.jetty' version='2.0.100.v20110502' singleton='false'>
      <update id='org.eclipse.equinox.http.jetty' range='[0.0.0,2.0.100.v20110502)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.bundleName' value='Jetty Http Service'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.http.jetty' version='2.0.100.v20110502'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.http.jetty' version='2.0.100.v20110502'/>
        <provided namespace='java.package' name='org.eclipse.equinox.http.jetty' version='1.1.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='14'>
        <required namespace='java.package' name='javax.servlet' range='[2.5.0,2.6.0)'/>
        <required namespace='java.package' name='javax.servlet.http' range='[2.5.0,2.6.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.http.servlet' range='1.0.0'/>
        <required namespace='java.package' name='org.mortbay.component' range='[6.1.0,7.0.0)'/>
        <required namespace='java.package' name='org.mortbay.jetty' range='[6.1.0,7.0.0)'/>
        <required namespace='java.package' name='org.mortbay.jetty.bio' range='[6.1.0,7.0.0)'/>
        <required namespace='java.package' name='org.mortbay.jetty.handler' range='[6.1.0,7.0.0)'/>
        <required namespace='java.package' name='org.mortbay.jetty.nio' range='[6.1.0,7.0.0)'/>
        <required namespace='java.package' name='org.mortbay.jetty.security' range='[6.1.0,7.0.0)'/>
        <required namespace='java.package' name='org.mortbay.jetty.servlet' range='[6.1.0,7.0.0)'/>
        <required namespace='java.package' name='org.mortbay.log' range='[6.1.0,7.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.cm' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.service.startlevel' range='1.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.http.jetty' version='2.0.100.v20110502'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.http.jetty&#xA;Bundle-Version: 2.0.100.v20110502
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.http.registry' version='1.1.100.v20110502'>
      <update id='org.eclipse.equinox.http.registry' range='[0.0.0,1.1.100.v20110502)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.bundleName' value='Http Service Registry Extensions'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.http.registry' version='1.1.100.v20110502'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.http.registry' version='1.1.100.v20110502'/>
        <provided namespace='java.package' name='org.eclipse.equinox.http.registry' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='0.0.0'/>
        <required namespace='java.package' name='javax.servlet' range='2.3.0'/>
        <required namespace='java.package' name='javax.servlet.http' range='2.3.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.http' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.3.1'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.http.registry' version='1.1.100.v20110502'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.http.registry;singleton:=true&#xA;Bundle-Version: 1.1.100.v20110502
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.http.servlet' version='1.1.200.v20110502' singleton='false'>
      <update id='org.eclipse.equinox.http.servlet' range='[0.0.0,1.1.200.v20110502)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.bundleName' value='Http Services Servlet'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.http.servlet' version='1.1.200.v20110502'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.http.servlet' version='1.1.200.v20110502'/>
        <provided namespace='java.package' name='org.eclipse.equinox.http.servlet' version='1.1.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='4'>
        <required namespace='java.package' name='javax.servlet' range='2.3.0'/>
        <required namespace='java.package' name='javax.servlet.http' range='2.3.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.http' range='[1.2.0,1.3.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.http.servlet' version='1.1.200.v20110502'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.http.servlet&#xA;Bundle-Version: 1.1.200.v20110502
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.jsp.jasper' version='1.0.300.v20110502' singleton='false'>
      <update id='org.eclipse.equinox.jsp.jasper' range='[0.0.0,1.0.300.v20110502)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.bundleName' value='Jasper Jsp Support Bundle'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.jsp.jasper' version='1.0.300.v20110502'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.jsp.jasper' version='1.0.300.v20110502'/>
        <provided namespace='java.package' name='org.eclipse.equinox.jsp.jasper' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='java.package' name='javax.servlet' range='[2.4.0,3.0.0)'/>
        <required namespace='java.package' name='javax.servlet.http' range='[2.4.0,3.0.0)'/>
        <required namespace='java.package' name='javax.servlet.jsp' range='[2.0.0,2.1.0)'/>
        <required namespace='java.package' name='org.apache.jasper.servlet' range='[0.0.0,6.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.http' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.3.1'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.jsp.jasper' version='1.0.300.v20110502'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.jsp.jasper&#xA;Bundle-Version: 1.0.300.v20110502
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.jsp.jasper.registry' version='1.0.200.v20100503' singleton='false'>
      <update id='org.eclipse.equinox.jsp.jasper.registry' range='[0.0.0,1.0.200.v20100503)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.bundleName' value='Jasper Jsp Registry Support Plug-in'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.jsp.jasper.registry' version='1.0.200.v20100503'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.jsp.jasper.registry' version='1.0.200.v20100503'/>
        <provided namespace='java.package' name='org.eclipse.equinox.jsp.jasper.registry' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.jsp.jasper' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.3.0'/>
        <required namespace='java.package' name='javax.servlet' range='2.4.0'/>
        <required namespace='java.package' name='javax.servlet.http' range='2.4.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.jsp.jasper.registry' version='1.0.200.v20100503'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.jsp.jasper.registry&#xA;Bundle-Version: 1.0.200.v20100503
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.launcher' version='1.2.0.v20110502'>
      <update id='org.eclipse.equinox.launcher' range='[0.0.0,1.2.0.v20110502)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.pluginName' value='Equinox Launcher'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='launcher'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher' version='1.2.0.v20110502'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.launcher' version='1.2.0.v20110502'/>
        <provided namespace='java.package' name='org.eclipse.core.launcher' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.launcher' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.launcher' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.launcher' version='1.2.0.v20110502'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.launcher;singleton:=true&#xA;Bundle-Version: 1.2.0.v20110502
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.launcher.win32.win32.x86' version='1.1.100.v20110502'>
      <update id='org.eclipse.equinox.launcher.win32.win32.x86' range='[0.0.0,1.1.100.v20110502)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.pluginName' value='Equinox Launcher Win32 X86 Fragment'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='launcher.win32.win32.x86'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.win32.win32.x86' version='1.1.100.v20110502'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.launcher.win32.win32.x86' version='1.1.100.v20110502'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='osgi.fragment' name='org.eclipse.equinox.launcher' version='1.1.100.v20110502'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.launcher' range='[1.0.0,1.3.0)'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.launcher.win32.win32.x86' version='1.1.100.v20110502'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.launcher.win32.win32.x86; singleton:=true&#xA;Bundle-Version: 1.1.100.v20110502&#xA;Fragment-Host: org.eclipse.equinox.launcher;bundle-version=&quot;[1.0.0,1.3.0)&quot;
          </instruction>
          <instruction key='zipped'>
            true
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.core' version='2.1.1.v20120113-1346'>
      <update id='org.eclipse.equinox.p2.core' range='[0.0.0,2.1.1.v20120113-1346)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.pluginName' value='Equinox Provisioning Core'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.core' version='2.1.1.v20120113-1346'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.core' version='2.1.1.v20120113-1346'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.core.eventbus' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.core' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.core.spi' version='2.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.5.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.eventmgr' range='1.2.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.5.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.core' version='2.1.1.v20120113-1346'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.core;singleton:=true&#xA;Bundle-Version: 2.1.1.v20120113-1346
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.engine' version='2.1.1.R37x_v20111003'>
      <update id='org.eclipse.equinox.p2.engine' range='[0.0.0,2.1.1.R37x_v20111003)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.pluginName' value='Equinox Provisioning Engine'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.engine' version='2.1.1.R37x_v20111003'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.engine' version='2.1.1.R37x_v20111003'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.engine' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.engine.phases' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.engine' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.engine.query' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.engine.spi' version='2.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='34'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.jobs' range='[3.4.0,4.0.0)'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.internal.preferences' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.preferences' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.index' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.repository.io' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.persistence' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.core.eventbus' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.index' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.spi' range='2.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.security.storage' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.security' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.signedcontent' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <required namespace='java.package' name='org.osgi.service.prefs' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.4.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.engine' version='2.1.1.R37x_v20111003'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.engine;singleton:=true&#xA;Bundle-Version: 2.1.1.R37x_v20111003
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.metadata' version='2.1.0.v20110815-1419'>
      <update id='org.eclipse.equinox.p2.metadata' range='[0.0.0,2.1.0.v20110815-1419)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.pluginName' value='Equinox Provisioning Metadata'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='13'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata' version='2.1.0.v20110815-1419'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.metadata' version='2.1.0.v20110815-1419'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.expression' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.expression.parser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.index' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.query' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.metadata' version='2.1.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.metadata.index' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.query' version='2.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.localization' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.metadata' version='2.1.0.v20110815-1419'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.metadata;singleton:=true&#xA;Bundle-Version: 2.1.0.v20110815-1419
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.metadata.repository' version='1.2.0.v20110815-1419'>
      <update id='org.eclipse.equinox.p2.metadata.repository' range='[0.0.0,1.2.0.v20110815-1419)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.pluginName' value='Equinox Provisioning Metadata Repository'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata.repository' version='1.2.0.v20110815-1419'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.metadata.repository' version='1.2.0.v20110815-1419'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.repository' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.repository.io' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.metadata.io' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='25'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.index' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.persistence' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.repository.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.core.eventbus' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.index' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.prefs' range='1.1.1'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.metadata.repository' version='1.2.0.v20110815-1419'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.metadata.repository;singleton:=true&#xA;Bundle-Version: 1.2.0.v20110815-1419
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.repository' version='2.1.1.v20120113-1346'>
      <update id='org.eclipse.equinox.p2.repository' range='[0.0.0,2.1.1.v20120113-1346)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.pluginName' value='Equinox Provisioning Repository'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='14'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.repository' version='2.1.1.v20120113-1346'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.repository' version='2.1.1.v20120113-1346'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.persistence' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.repository' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.repository.helpers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.repository' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.repository' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact.spi' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata.spi' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.repository.spi' version='2.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='24'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='3.3.0'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.jobs' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.preferences' range='3.2.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.repository.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.core.eventbus' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.security.storage' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.service.prefs' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.4.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.repository' version='2.1.1.v20120113-1346'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.repository;singleton:=true&#xA;Bundle-Version: 2.1.1.v20120113-1346
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.preferences' version='3.4.2.v20120111-2020'>
      <update id='org.eclipse.equinox.preferences' range='[0.0.0,3.4.2.v20120111-2020)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.pluginName' value='Eclipse Preferences Mechanism'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.preferences' version='3.4.2.v20120111-2020'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.preferences' version='3.4.2.v20120111-2020'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.preferences' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.preferences.exchange' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.preferences' version='3.3.0'/>
        <provided namespace='java.package' name='org.osgi.service.prefs' version='1.1.1'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='11'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.2.0,4.0.0)' optional='true'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.service.prefs' range='[1.1.1,1.2.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.preferences' version='3.4.2.v20120111-2020'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.preferences; singleton:=true&#xA;Bundle-Version: 3.4.2.v20120111-2020
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.registry' version='3.5.101.R37x_v20110810-1611'>
      <update id='org.eclipse.equinox.registry' range='[0.0.0,3.5.101.R37x_v20110810-1611)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.pluginName' value='Extension Registry Support'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='11'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.registry' version='3.5.101.R37x_v20110810-1611'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.registry' version='3.5.101.R37x_v20110810-1611'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.adapter' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.registry' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.registry.osgi' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.registry.spi' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime' version='3.4.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.dynamichelpers' version='3.4.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.spi' version='3.4.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='16'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.jobs' range='0.0.0' optional='true'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.console' range='0.0.0' optional='true'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='0.0.0' optional='true'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.localization' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.resolver' range='0.0.0' optional='true'/>
        <required namespace='java.package' name='org.eclipse.osgi.storagemanager' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.registry' version='3.5.101.R37x_v20110810-1611'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.registry;singleton:=true&#xA;Bundle-Version: 3.5.101.R37x_v20110810-1611
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.security' version='1.1.1.R37x_v20110822-1018'>
      <update id='org.eclipse.equinox.security' range='[0.0.0,1.1.1.R37x_v20110822-1018)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.pluginName' value='Equinox Java Authentication and Authorization Service (JAAS)'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='16'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.security' version='1.1.1.R37x_v20110822-1018'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.security' version='1.1.1.R37x_v20110822-1018'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.auth' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.auth.events' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.auth.ext.loader' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.auth.nls' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.credentials' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.storage' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.storage.friends' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.security.auth' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.security.auth.credentials' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.security.auth.module' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.security.storage' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.security.storage.provider' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='18'>
        <required namespace='java.package' name='javax.crypto' range='0.0.0'/>
        <required namespace='java.package' name='javax.crypto.spec' range='0.0.0'/>
        <required namespace='java.package' name='javax.security.auth' range='0.0.0'/>
        <required namespace='java.package' name='javax.security.auth.callback' range='0.0.0'/>
        <required namespace='java.package' name='javax.security.auth.login' range='0.0.0'/>
        <required namespace='java.package' name='javax.security.auth.spi' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.internal.runtime' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.jobs' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.preferences' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='[1.1.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='[1.1.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.4.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.prefs' range='[1.1.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='[1.3.3,2.0.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.security' version='1.1.1.R37x_v20110822-1018'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.security;singleton:=true&#xA;Bundle-Version: 1.1.1.R37x_v20110822-1018
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.security.win32.x86' version='1.0.200.v20100503'>
      <update id='org.eclipse.equinox.security.win32.x86' range='[0.0.0,1.0.200.v20100503)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.fragmentName' value='Windows Data Protection services integration'/>
        <property name='org.eclipse.equinox.p2.name' value='%fragmentName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='fragment'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.security.win32.x86' version='1.0.200.v20100503'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.security.win32.x86' version='1.0.200.v20100503'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.win32' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='osgi.fragment' name='org.eclipse.equinox.security' version='1.0.200.v20100503'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.security' range='[1.0.0,2.0.0)'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86)(osgi.os=win32))
      </filter>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.security.win32.x86' version='1.0.200.v20100503'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.security.win32.x86;singleton:=true&#xA;Bundle-Version: 1.0.200.v20100503&#xA;Fragment-Host: org.eclipse.equinox.security;bundle-version=&quot;[1.0.0,2.0.0)&quot;
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.help' version='3.5.100.v20110426'>
      <update id='org.eclipse.help' range='[0.0.0,3.5.100.v20110426)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.help_plugin_name' value='Help System Core'/>
        <property name='org.eclipse.equinox.p2.name' value='%help_plugin_name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='14'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help' version='3.5.100.v20110426'/>
        <provided namespace='osgi.bundle' name='org.eclipse.help' version='3.5.100.v20110426'/>
        <provided namespace='java.package' name='org.eclipse.help' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.context' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.criteria' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.dynamic' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.entityresolver' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.extension' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.index' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.toc' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.util' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='10'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.6.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='[3.4.200,4.0.0)'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='3.8.0'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.transform' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.transform.dom' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.transform.stream' range='0.0.0'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.help' version='3.5.100.v20110426'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.help; singleton:=true&#xA;Bundle-Version: 3.5.100.v20110426
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.help.appserver' version='3.1.400.v20110425'>
      <update id='org.eclipse.help.appserver' range='[0.0.0,3.1.400.v20110425)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.appserver_plugin_name' value='Help Application Server'/>
        <property name='org.eclipse.equinox.p2.name' value='%appserver_plugin_name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help.appserver' version='3.1.400.v20110425'/>
        <provided namespace='osgi.bundle' name='org.eclipse.help.appserver' version='3.1.400.v20110425'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.appserver' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.1.0,4.0.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.help.appserver' version='3.1.400.v20110425'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.help.appserver; singleton:=true&#xA;Bundle-Version: 3.1.400.v20110425
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.help.base' version='3.6.2.v201202080800'>
      <update id='org.eclipse.help.base' range='[0.0.0,3.6.2.v201202080800)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.help_base_plugin_name' value='Help System Base'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%help_base_plugin_name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='24'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help.base' version='3.6.2.v201202080800'/>
        <provided namespace='osgi.bundle' name='org.eclipse.help.base' version='3.6.2.v201202080800'/>
        <provided namespace='java.package' name='org.apache.lucene.demo.html' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.base' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.browser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.base' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.base.remote' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.base.scope' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.base.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.browser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.browser.macosx' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.protocols' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.search' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.search.federated' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.server' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.standalone' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.validation' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.workingset' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.xhtml' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.search' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.server' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.standalone' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='osgi.bundle' name='org.apache.lucene' range='[2.9.0,3.0.0)'/>
        <required namespace='osgi.bundle' name='org.apache.lucene.analysis' range='[2.9.0,3.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ant.core' range='3.2.200' optional='true'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='3.6.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.help' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='[3.4.200,4.0.0)'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.http.jetty' range='0.0.0' optional='true'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.help.base' version='3.6.2.v201202080800'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.help.base; singleton:=true&#xA;Bundle-Version: 3.6.2.v201202080800
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.help.ui' version='3.5.101.r37_20110819'>
      <update id='org.eclipse.help.ui' range='[0.0.0,3.5.101.r37_20110819)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.help_system_plugin_name' value='Help System UI'/>
        <property name='org.eclipse.equinox.p2.name' value='%help_system_plugin_name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='15'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help.ui' version='3.5.101.r37_20110819'/>
        <provided namespace='osgi.bundle' name='org.eclipse.help.ui' version='3.5.101.r37_20110819'/>
        <provided namespace='java.package' name='org.eclipse.help.ui' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.ui.browser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.ui.internal' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.ui.internal.browser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.ui.internal.browser.embedded' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.ui.internal.dynamic' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.ui.internal.handlers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.ui.internal.preferences' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.ui.internal.search' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.ui.internal.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.ui.internal.views' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='osgi.bundle' name='org.eclipse.help.base' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='[3.6.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.6.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.forms' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='3.4.200'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.help.ui' version='3.5.101.r37_20110819'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.help.ui; singleton:=true&#xA;Bundle-Version: 3.5.101.r37_20110819
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.help.webapp' version='3.6.1.r37_20110929'>
      <update id='org.eclipse.help.webapp' range='[0.0.0,3.6.1.r37_20110929)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.help_webapp_plugin_name' value='Help System Webapp'/>
        <property name='org.eclipse.equinox.p2.name' value='%help_webapp_plugin_name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help.webapp' version='3.6.1.r37_20110929'/>
        <provided namespace='osgi.bundle' name='org.eclipse.help.webapp' version='3.6.1.r37_20110929'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.webapp' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.webapp.data' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.webapp.service' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.webapp.servlet' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.webapp.utils' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.webapp' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='10'>
        <required namespace='osgi.bundle' name='org.eclipse.help.base' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.6.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.apache.jasper' range='5.5.17'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.jsp.jasper.registry' range='1.0.100'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.http.registry' range='1.0.200'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='3.4.200'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='3.8.0'/>
        <required namespace='java.package' name='javax.servlet' range='2.4.0'/>
        <required namespace='java.package' name='javax.servlet.http' range='2.4.0'/>
        <required namespace='java.package' name='org.osgi.service.http' range='1.2.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.help.webapp' version='3.6.1.r37_20110929'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.help.webapp;singleton:=true&#xA;Bundle-Version: 3.6.1.r37_20110929
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.jface' version='3.7.0.v20110928-1505' singleton='false'>
      <update id='org.eclipse.jface' range='[0.0.0,3.7.0.v20110928-1505)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='JFace'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='31'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface' version='3.7.0.v20110928-1505'/>
        <provided namespace='osgi.bundle' name='org.eclipse.jface' version='3.7.0.v20110928-1505'/>
        <provided namespace='java.package' name='org.eclipse.jface' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.action' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.action.images' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.bindings' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.bindings.keys' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.bindings.keys.formatting' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.commands' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.contexts' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.dialogs' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.dialogs.images' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.fieldassist' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.fieldassist.images' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.images' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.internal' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.internal.provisional.action' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.layout' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.menus' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.operation' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.preference' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.preference.images' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.resource' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.viewers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.viewers.deferred' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.window' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.wizard' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.wizard.images' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='osgi.bundle' name='org.eclipse.swt' range='[3.6.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.commands' range='[3.4.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.3.0,4.0.0)'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='0.0.0'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.jface' version='3.7.0.v20110928-1505'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.jface&#xA;Bundle-Version: 3.7.0.v20110928-1505
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.jface.databinding' version='1.5.0.I20100907-0800' singleton='false'>
      <update id='org.eclipse.jface.databinding' range='[0.0.0,1.5.0.I20100907-0800)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='JFace Data Binding for SWT and JFace'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='16'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.databinding' version='1.5.0.I20100907-0800'/>
        <provided namespace='osgi.bundle' name='org.eclipse.jface.databinding' version='1.5.0.I20100907-0800'/>
        <provided namespace='java.package' name='org.eclipse.jface.databinding.dialog' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.databinding.fieldassist' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.databinding.preference' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.databinding.swt' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.databinding.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.databinding.viewers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.databinding.wizard' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.internal.databinding.provisional.swt' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.internal.databinding.provisional.viewers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.internal.databinding.swt' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.internal.databinding.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.internal.databinding.viewers' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='osgi.bundle' name='org.eclipse.swt' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.databinding.observable' range='[1.3.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.databinding.property' range='[1.3.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.databinding' range='[1.2.0,2.0.0)'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.jface.databinding' version='1.5.0.I20100907-0800'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.jface.databinding&#xA;Bundle-Version: 1.5.0.I20100907-0800
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.jface.text' version='3.7.2.v20111213-1208' singleton='false'>
      <update id='org.eclipse.jface.text' range='[0.0.0,3.7.2.v20111213-1208)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='JFace Text'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='27'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.text' version='3.7.2.v20111213-1208'/>
        <provided namespace='osgi.bundle' name='org.eclipse.jface.text' version='3.7.2.v20111213-1208'/>
        <provided namespace='java.package' name='org.eclipse.jface.contentassist' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.contentassist.images' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.internal.text' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.internal.text.html' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.internal.text.link.contentassist' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.internal.text.revisions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.internal.text.source' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.text' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.text.contentassist' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.text.formatter' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.text.hyperlink' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.text.information' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.text.link' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.text.presentation' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.text.quickassist' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.text.reconciler' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.text.revisions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.text.rules' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.text.source' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.text.source.projection' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.text.source.projection.images' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.text.templates' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.text.templates.persistence' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.text' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.swt' range='[3.6.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface' range='[3.5.0,4.0.0)'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.jface.text' version='3.7.2.v20111213-1208'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.jface.text&#xA;Bundle-Version: 3.7.2.v20111213-1208
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ltk.core.refactoring' version='3.5.201.r372_v20111101-0700'>
      <update id='org.eclipse.ltk.core.refactoring' range='[0.0.0,3.5.201.r372_v20111101-0700)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Refactoring Core'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='13'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ltk.core.refactoring' version='3.5.201.r372_v20111101-0700'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ltk.core.refactoring' version='3.5.201.r372_v20111101-0700'/>
        <provided namespace='java.package' name='org.eclipse.ltk.core.refactoring' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ltk.core.refactoring.history' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ltk.core.refactoring.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ltk.core.refactoring.participants' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ltk.core.refactoring.resource' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ltk.internal.core.refactoring' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ltk.internal.core.refactoring.history' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ltk.internal.core.refactoring.resource' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ltk.internal.core.refactoring.resource.undostates' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='[3.4.100,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filesystem' range='[1.2.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filebuffers' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.commands' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.text' range='[3.5.0,4.0.0)'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ltk.core.refactoring' version='3.5.201.r372_v20111101-0700'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ltk.core.refactoring; singleton:=true&#xA;Bundle-Version: 3.5.201.r372_v20111101-0700
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ltk.ui.refactoring' version='3.6.0.v20110928-1453'>
      <update id='org.eclipse.ltk.ui.refactoring' range='[0.0.0,3.6.0.v20110928-1453)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Refactoring UI'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='15'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ltk.ui.refactoring' version='3.6.0.v20110928-1453'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ltk.ui.refactoring' version='3.6.0.v20110928-1453'/>
        <provided namespace='java.package' name='org.eclipse.ltk.internal.ui.refactoring' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ltk.internal.ui.refactoring.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ltk.internal.ui.refactoring.history' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ltk.internal.ui.refactoring.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ltk.internal.ui.refactoring.scripting' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ltk.internal.ui.refactoring.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ltk.ui.refactoring' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ltk.ui.refactoring.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ltk.ui.refactoring.history' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ltk.ui.refactoring.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ltk.ui.refactoring.resource' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='13'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='[3.4.100,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filebuffers' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filesystem' range='[1.2.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ltk.core.refactoring' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface.text' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.navigator' range='[3.3.200,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.compare' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.team.core' range='[3.4.100,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.team.ui' range='[3.4.100,4.0.0)'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ltk.ui.refactoring' version='3.6.0.v20110928-1453'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ltk.ui.refactoring; singleton:=true&#xA;Bundle-Version: 3.6.0.v20110928-1453
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.osgi' version='3.7.2.v20120110-1415'>
      <update id='org.eclipse.osgi' range='[0.0.0,3.7.2.v20120110-1415)' severity='0'/>
      <properties size='6'>
        <property name='df_LT.systemBundle' value='OSGi System Bundle'/>
        <property name='df_LT.eclipse.org' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%systemBundle'/>
        <property name='org.eclipse.equinox.p2.description' value='%systemBundle'/>
        <property name='org.eclipse.equinox.p2.provider' value='%eclipse.org'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='systembundle'/>
      </properties>
      <provides size='69'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi' version='3.7.2.v20120110-1415'/>
        <provided namespace='osgi.bundle' name='org.eclipse.osgi' version='3.7.2.v20120110-1415'/>
        <provided namespace='java.package' name='org.eclipse.osgi.event' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.console' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.eventmgr' version='1.2.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.log' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.launch' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.datalocation' version='1.3.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.debug' version='1.2.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.environment' version='1.3.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.localization' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.pluginconversion' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.resolver' version='1.5.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.runnable' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.security' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.urlconversion' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.signedcontent' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.storagemanager' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.util' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.log' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.framework' version='1.6.0'/>
        <provided namespace='java.package' name='org.osgi.framework.launch' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.framework.hooks.bundle' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.framework.hooks.resolver' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.framework.hooks.service' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.framework.hooks.weaving' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.framework.startlevel' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.framework.wiring' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.service.condpermadmin' version='1.1.1'/>
        <provided namespace='java.package' name='org.osgi.service.framework' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.service.log' version='1.3.0'/>
        <provided namespace='java.package' name='org.osgi.service.packageadmin' version='1.2.0'/>
        <provided namespace='java.package' name='org.osgi.service.permissionadmin' version='1.2.0'/>
        <provided namespace='java.package' name='org.osgi.service.startlevel' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.service.url' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.util.tracker' version='1.5.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.adaptor' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.internal.adaptor' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.internal.stats' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.baseadaptor' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.baseadaptor.bundlefile' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.baseadaptor.hooks' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.baseadaptor.loader' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.adaptor' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.debug' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.internal.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.internal.protocol' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.internal.protocol.bundleentry' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.internal.protocol.bundleresource' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.internal.protocol.reference' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.internal.reliablefile' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.baseadaptor' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.composite' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.loader' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.loader.buddy' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.module' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.profile' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.resolver' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.serviceregistry' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.permadmin' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.provisional.service.security' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.provisional.verifier' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.service.security' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.signedcontent' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.internal.composite' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.log.internal' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.osgi' version='3.7.2.v20120110-1415'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.osgi; singleton:=true&#xA;Bundle-Version: 3.7.2.v20120110-1415
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.osgi.services' version='3.3.0.v20110513' singleton='false'>
      <update id='org.eclipse.osgi.services' range='[0.0.0,3.3.0.v20110513)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.osgiServicesDes' value='OSGi Service Platform Release 4.2.0 Service Interfaces and Classes'/>
        <property name='df_LT.osgiServices' value='OSGi Release 4.2.0 Services'/>
        <property name='df_LT.eclipse.org' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%osgiServices'/>
        <property name='org.eclipse.equinox.p2.description' value='%osgiServicesDes'/>
        <property name='org.eclipse.equinox.p2.provider' value='%eclipse.org'/>
        <property name='org.eclipse.equinox.p2.contact' value='www.eclipse.org'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='16'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.services' version='3.3.0.v20110513'/>
        <provided namespace='osgi.bundle' name='org.eclipse.osgi.services' version='3.3.0.v20110513'/>
        <provided namespace='java.package' name='org.osgi.service.cm' version='1.3.0'/>
        <provided namespace='java.package' name='org.osgi.service.component' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.service.device' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.service.event' version='1.3.0'/>
        <provided namespace='java.package' name='org.osgi.service.http' version='1.2.1'/>
        <provided namespace='java.package' name='org.osgi.service.io' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.service.log' version='1.3.0'/>
        <provided namespace='java.package' name='org.osgi.service.metatype' version='1.2.0'/>
        <provided namespace='java.package' name='org.osgi.service.provisioning' version='1.2.0'/>
        <provided namespace='java.package' name='org.osgi.service.upnp' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.service.useradmin' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.service.wireadmin' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='16'>
        <required namespace='java.package' name='org.osgi.framework' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.service.http' range='[1.2.1,1.3.0)'/>
        <required namespace='java.package' name='org.osgi.service.io' range='[1.0.0,1.1.0)'/>
        <required namespace='java.package' name='javax.microedition.io' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.useradmin' range='[1.1.0,1.2.0)'/>
        <required namespace='java.package' name='org.osgi.service.component' range='[1.1.0,1.2.0)'/>
        <required namespace='java.package' name='org.osgi.service.log' range='[1.3.0,1.4.0)'/>
        <required namespace='java.package' name='org.osgi.service.device' range='[1.1.0,1.2.0)'/>
        <required namespace='java.package' name='org.osgi.service.wireadmin' range='[1.0.0,1.1.0)'/>
        <required namespace='java.package' name='javax.servlet.http' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.upnp' range='[1.1.0,1.2.0)'/>
        <required namespace='java.package' name='javax.servlet' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.cm' range='[1.3.0,1.4.0)'/>
        <required namespace='java.package' name='org.osgi.service.metatype' range='[1.2.0,1.3.0)'/>
        <required namespace='java.package' name='org.osgi.service.event' range='[1.3.0,1.4.0)'/>
        <required namespace='java.package' name='org.osgi.service.provisioning' range='[1.2.0,1.3.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.osgi.services' version='3.3.0.v20110513'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.osgi.services&#xA;Bundle-Version: 3.3.0.v20110513
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.search' version='3.7.0.v20110928-1504'>
      <update id='org.eclipse.search' range='[0.0.0,3.7.0.v20110928-1504)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Search Support'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='16'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.search' version='3.7.0.v20110928-1504'/>
        <provided namespace='osgi.bundle' name='org.eclipse.search' version='3.7.0.v20110928-1504'/>
        <provided namespace='java.package' name='org.eclipse.search.core.text' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.search.internal.core.text' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.search.internal.ui' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.search.internal.ui.text' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.search.internal.ui.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.search.ui' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.search.ui.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.search.ui.text' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.search2.internal.ui' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.search2.internal.ui.basic.views' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.search2.internal.ui.text' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.search2.internal.ui.text2' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='12'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filesystem' range='[1.3.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filebuffers' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.ide' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.workbench.texteditor' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface.text' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.forms' range='[3.4.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ltk.core.refactoring' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ltk.ui.refactoring' range='[3.5.0,4.0.0)'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.search' version='3.7.0.v20110928-1504'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.search; singleton:=true&#xA;Bundle-Version: 3.7.0.v20110928-1504
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.swt' version='3.7.2.v3740f'>
      <update id='org.eclipse.swt' range='[0.0.0,3.7.2.v3740f)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Standard Widget Toolkit'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='20'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt' version='3.7.2.v3740f'/>
        <provided namespace='osgi.bundle' name='org.eclipse.swt' version='3.7.2.v3740f'/>
        <provided namespace='java.package' name='org.eclipse.swt' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.accessibility' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.awt' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.browser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.custom' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.dnd' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.events' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.graphics' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.layout' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.opengl' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.printing' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.program' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.widgets' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.internal' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.internal.image' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.internal.theme' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='java.package' name='org.eclipse.swt.accessibility2' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.mozilla.xpcom' range='0.0.0' optional='true' greedy='false'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.swt' version='3.7.2.v3740f'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.swt; singleton:=true&#xA;Bundle-Version: 3.7.2.v3740f
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.swt.win32.win32.x86' version='3.7.2.v3740f'>
      <update id='org.eclipse.swt.win32.win32.x86' range='[0.0.0,3.7.2.v3740f)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.fragmentName' value='Standard Widget Toolkit for Windows'/>
        <property name='org.eclipse.equinox.p2.name' value='%fragmentName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='fragment'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.win32.win32.x86' version='3.7.2.v3740f'/>
        <provided namespace='osgi.bundle' name='org.eclipse.swt.win32.win32.x86' version='3.7.2.v3740f'/>
        <provided namespace='java.package' name='org.eclipse.swt.ole.win32' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.internal.gdip' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.internal.ole.win32' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.internal.win32' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.internal.opengl.win32' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='osgi.fragment' name='org.eclipse.swt' version='3.7.2.v3740f'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.eclipse.swt' range='[3.0.0,4.0.0)'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.swt.win32.win32.x86' version='3.7.2.v3740f'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.swt.win32.win32.x86; singleton:=true&#xA;Bundle-Version: 3.7.2.v3740f&#xA;Fragment-Host: org.eclipse.swt; bundle-version=&quot;[3.0.0,4.0.0)&quot;
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.team.core' version='3.6.0.I20110525-0800'>
      <update id='org.eclipse.team.core' range='[0.0.0,3.6.0.I20110525-0800)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Team Support Core'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='21'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.team.core' version='3.6.0.I20110525-0800'/>
        <provided namespace='osgi.bundle' name='org.eclipse.team.core' version='3.6.0.I20110525-0800'/>
        <provided namespace='java.package' name='org.eclipse.team.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.core.diff' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.core.diff.provider' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.core.history' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.core.history.provider' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.core.importing.provisional' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.core.mapping' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.core.mapping.provider' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.core.subscribers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.core.synchronize' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.core.variants' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.internal.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.internal.core.history' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.internal.core.importing' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.internal.core.mapping' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.internal.core.streams' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.internal.core.subscribers' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='[3.3.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filesystem' range='[1.1.0,2.0.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.team.core' version='3.6.0.I20110525-0800'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.team.core; singleton:=true&#xA;Bundle-Version: 3.6.0.I20110525-0800
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.team.ui' version='3.6.101.R37x_v20111109-0800'>
      <update id='org.eclipse.team.ui' range='[0.0.0,3.6.101.R37x_v20111109-0800)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Team Support UI'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='19'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.team.ui' version='3.6.101.R37x_v20111109-0800'/>
        <provided namespace='osgi.bundle' name='org.eclipse.team.ui' version='3.6.101.R37x_v20111109-0800'/>
        <provided namespace='java.package' name='org.eclipse.team.internal.ui' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.internal.ui.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.internal.ui.dialogs' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.internal.ui.history' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.internal.ui.mapping' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.internal.ui.preferences' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.internal.ui.registry' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.internal.ui.synchronize' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.internal.ui.synchronize.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.internal.ui.synchronize.patch' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.internal.ui.wizards' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.ui' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.ui.history' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.ui.mapping' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.ui.synchronize' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='12'>
        <required namespace='osgi.bundle' name='org.eclipse.ui.ide' range='[3.3.0,4.0.0)' optional='true'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='[3.3.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.team.core' range='[3.6.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.compare' range='[3.3.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.forms' range='[3.3.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.navigator' range='[3.3.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface.text' range='[3.3.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.editors' range='[3.3.0,4.0.0)'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
        <required namespace='java.package' name='com.ibm.icu.util' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.team.ui' version='3.6.101.R37x_v20111109-0800'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.team.ui; singleton:=true&#xA;Bundle-Version: 3.6.101.R37x_v20111109-0800
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.text' version='3.5.101.v20110928-1504' singleton='false'>
      <update id='org.eclipse.text' range='[0.0.0,3.5.101.v20110928-1504)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Text'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='11'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.text' version='3.5.101.v20110928-1504'/>
        <provided namespace='osgi.bundle' name='org.eclipse.text' version='3.5.101.v20110928-1504'/>
        <provided namespace='java.package' name='org.eclipse.jface.text' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.text.link' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.text.projection' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.text.source' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.text.templates' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.text.edits' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.text.undo' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='4'>
        <required namespace='osgi.bundle' name='org.eclipse.core.commands' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.5.0,4.0.0)'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
        <required namespace='java.package' name='com.ibm.icu.util' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.text' version='3.5.101.v20110928-1504'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.text&#xA;Bundle-Version: 3.5.101.v20110928-1504
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ui' version='3.7.0.v20110928-1505'>
      <update id='org.eclipse.ui' range='[0.0.0,3.7.0.v20110928-1505)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.Plugin.providerName' value='Eclipse.org'/>
        <property name='df_LT.Plugin.name' value='Eclipse UI'/>
        <property name='org.eclipse.equinox.p2.name' value='%Plugin.name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%Plugin.providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui' version='3.7.0.v20110928-1505'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ui' version='3.7.0.v20110928-1505'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.swt' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.workbench' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='[3.4.0,4.0.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ui' version='3.7.0.v20110928-1505'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ui; singleton:=true&#xA;Bundle-Version: 3.7.0.v20110928-1505
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ui.console' version='3.5.100.v20111007_r372'>
      <update id='org.eclipse.ui.console' range='[0.0.0,3.5.100.v20111007_r372)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Console'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.console' version='3.5.100.v20111007_r372'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ui.console' version='3.5.100.v20111007_r372'/>
        <provided namespace='java.package' name='org.eclipse.ui.console' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.console.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.console' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface.text' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.workbench.texteditor' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='[3.4.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.variables' range='[3.2.0,4.0.0)'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ui.console' version='3.5.100.v20111007_r372'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ui.console; singleton:=true&#xA;Bundle-Version: 3.5.100.v20111007_r372
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ui.editors' version='3.7.0.v20110928-1504'>
      <update id='org.eclipse.ui.editors' range='[0.0.0,3.7.0.v20110928-1504)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Default Text Editor'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.editors' version='3.7.0.v20110928-1504'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ui.editors' version='3.7.0.v20110928-1504'/>
        <provided namespace='java.package' name='org.eclipse.ui.editors.text' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.editors.text.templates' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.editors.quickdiff' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.editors.text' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.texteditor' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.texteditor' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='10'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.7.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='[3.4.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.ide' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface.text' range='[3.7.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.workbench.texteditor' range='[3.7.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filebuffers' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filesystem' range='[1.2.0,2.0.0)'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ui.editors' version='3.7.0.v20110928-1504'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ui.editors; singleton:=true&#xA;Bundle-Version: 3.7.0.v20110928-1504
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ui.forms' version='3.5.101.v20111011-1919' singleton='false'>
      <update id='org.eclipse.ui.forms' range='[0.0.0,3.5.101.v20111011-1919)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.name' value='Eclipse Forms'/>
        <property name='df_LT.provider-name' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%provider-name'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.forms' version='3.5.101.v20111011-1919'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ui.forms' version='3.5.101.v20111011-1919'/>
        <provided namespace='java.package' name='org.eclipse.ui.forms' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.forms.editor' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.forms.events' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.forms.widgets' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.forms' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.forms.widgets' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.6.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface' range='[3.6.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='[3.6.0,4.0.0)' optional='true'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ui.forms' version='3.5.101.v20111011-1919'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ui.forms&#xA;Bundle-Version: 3.5.101.v20111011-1919
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ui.ide' version='3.7.0.v20110928-1505'>
      <update id='org.eclipse.ui.ide' range='[0.0.0,3.7.0.v20110928-1505)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.Plugin.providerName' value='Eclipse.org'/>
        <property name='df_LT.Plugin.name' value='Eclipse IDE UI'/>
        <property name='org.eclipse.equinox.p2.name' value='%Plugin.name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%Plugin.providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='40'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.ide' version='3.7.0.v20110928-1505'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ui.ide' version='3.7.0.v20110928-1505'/>
        <provided namespace='java.package' name='org.eclipse.ui' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.dialogs' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.ide' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.ide.dialogs' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.ide.fileSystem' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.ide.undo' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.ide' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.ide.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.ide.commands' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.ide.dialogs' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.ide.filesystem' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.ide.handlers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.ide.misc' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.ide.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.ide.registry' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.ide.undo' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.views.bookmarkexplorer' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.views.framelist' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.views.markers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.views.navigator' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.views.properties' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.views.tasklist' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.wizards.datatransfer' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.wizards.newresource' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.part' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.views.bookmarkexplorer' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.views.framelist' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.views.markers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.views.markers.internal' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.views.navigator' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.views.properties' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.views.tasklist' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.wizards.datatransfer' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.wizards.newresource' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='12'>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='[3.7.0,4.0.0)' optional='true'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filesystem' range='[1.0.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.help' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.workbench' range='[3.7.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.views' range='[3.2.0,4.0.0)' optional='true'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface.text' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.forms' range='[3.3.0,4.0.0)' optional='true'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.engine' range='[2.0.0,3.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ui.ide' version='3.7.0.v20110928-1505'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ui.ide; singleton:=true&#xA;Bundle-Version: 3.7.0.v20110928-1505
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ui.navigator' version='3.5.101.v20120106-1355'>
      <update id='org.eclipse.ui.navigator' range='[0.0.0,3.5.101.v20120106-1355)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.Plugin.providerName' value='Eclipse.org'/>
        <property name='df_LT.Plugin.name' value='Common Navigator View'/>
        <property name='org.eclipse.equinox.p2.name' value='%Plugin.name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%Plugin.providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='13'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.navigator' version='3.5.101.v20120106-1355'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ui.navigator' version='3.5.101.v20120106-1355'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.navigator' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.navigator.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.navigator.dnd' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.navigator.extensions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.navigator.filters' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.navigator.framelist' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.navigator.sorters' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.navigator.wizards' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.navigator' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.6.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='[3.6.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='[3.4.0,4.0.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ui.navigator' version='3.5.101.v20120106-1355'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ui.navigator; singleton:=true&#xA;Bundle-Version: 3.5.101.v20120106-1355
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ui.navigator.resources' version='3.4.200.I20100601-0800'>
      <update id='org.eclipse.ui.navigator.resources' range='[0.0.0,3.4.200.I20100601-0800)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.Plugin.providerName' value='Eclipse.org'/>
        <property name='df_LT.Plugin.name' value='Navigator Workbench Components'/>
        <property name='org.eclipse.equinox.p2.name' value='%Plugin.name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%Plugin.providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.navigator.resources' version='3.4.200.I20100601-0800'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ui.navigator.resources' version='3.4.200.I20100601-0800'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.navigator.resources' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.navigator.resources.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.navigator.resources.plugin' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.navigator.resources.workbench' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.navigator.workingsets' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.navigator.resources' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='10'>
        <required namespace='osgi.bundle' name='org.eclipse.ui.ide' range='3.7.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='3.7.101'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface' range='3.7.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='3.7.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.navigator' range='3.5.101'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='3.7.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.views.properties.tabbed' range='3.5.200'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.workbench.texteditor' range='3.7.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ltk.core.refactoring' range='3.5.201'/>
        <required namespace='osgi.bundle' name='org.eclipse.ltk.ui.refactoring' range='3.6.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ui.navigator.resources' version='3.4.200.I20100601-0800'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ui.navigator.resources; singleton:=true&#xA;Bundle-Version: 3.4.200.I20100601-0800
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ui.views' version='3.6.0.v20110928-1505'>
      <update id='org.eclipse.ui.views' range='[0.0.0,3.6.0.v20110928-1505)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Views'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.views' version='3.6.0.v20110928-1505'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ui.views' version='3.6.0.v20110928-1505'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.views' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.views.contentoutline' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.views.properties' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.views.contentoutline' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.views.properties' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.help' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='[3.5.0,4.0.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ui.views' version='3.6.0.v20110928-1505'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ui.views; singleton:=true&#xA;Bundle-Version: 3.6.0.v20110928-1505
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ui.views.properties.tabbed' version='3.5.200.v20110928-1505'>
      <update id='org.eclipse.ui.views.properties.tabbed' range='[0.0.0,3.5.200.v20110928-1505)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.Plugin.providerName' value='Eclipse.org'/>
        <property name='df_LT.Plugin.name' value='Tabbed Properties View'/>
        <property name='org.eclipse.equinox.p2.name' value='%Plugin.name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%Plugin.providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.views.properties.tabbed' version='3.5.200.v20110928-1505'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ui.views.properties.tabbed' version='3.5.200.v20110928-1505'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.views.properties.tabbed' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.views.properties.tabbed.l10n' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.views.properties.tabbed.view' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.views.properties.tabbed' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='osgi.bundle' name='org.eclipse.ui.forms' range='[3.3.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.views' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='[3.3.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.2.0,4.0.0)'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ui.views.properties.tabbed' version='3.5.200.v20110928-1505'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ui.views.properties.tabbed;singleton:=true&#xA;Bundle-Version: 3.5.200.v20110928-1505
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ui.win32' version='3.2.200.v20110928-1505' singleton='false'>
      <update id='org.eclipse.ui.win32' range='[0.0.0,3.2.200.v20110928-1505)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.fragmentName' value='Eclipse UI Win32 Enhancements'/>
        <property name='org.eclipse.equinox.p2.name' value='%fragmentName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='fragment-win32'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.win32' version='3.2.200.v20110928-1505'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ui.win32' version='3.2.200.v20110928-1505'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.editorsupport.win32' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='osgi.fragment' name='org.eclipse.ui.ide' version='3.2.200.v20110928-1505'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.eclipse.ui.ide' range='[3.2.0,4.0.0)'/>
      </requires>
      <filter>
        (osgi.ws=win32)
      </filter>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ui.win32' version='3.2.200.v20110928-1505'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ui.win32&#xA;Bundle-Version: 3.2.200.v20110928-1505&#xA;Fragment-Host: org.eclipse.ui.ide;bundle-version=&quot;[3.2.0,4.0.0)&quot;
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ui.workbench' version='3.7.1.v20120104-1859'>
      <update id='org.eclipse.ui.workbench' range='[0.0.0,3.7.1.v20120104-1859)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Workbench'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='81'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.workbench' version='3.7.1.v20120104-1859'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ui.workbench' version='3.7.1.v20120104-1859'/>
        <provided namespace='java.package' name='org.eclipse.ui' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.about' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.activities' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.application' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.branding' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.browser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.commands' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.contexts' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.databinding' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.dialogs' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.dnd' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.fieldassist' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.handlers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.help' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.about' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.activities' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.activities.ws' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.application' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.browser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.commands' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.contexts' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.decorators' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.dialogs' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.dnd' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.editorsupport' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.expressions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.handlers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.help' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.intro' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.keys' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.keys.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.layout' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.menus' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.misc' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.operations' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.part' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.preferences' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.presentations' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.presentations.classic' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.presentations.defaultpresentation' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.presentations.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.progress' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.provisional.application' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.provisional.presentations' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.quickaccess' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.registry' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.services' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.splash' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.statushandlers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.testing' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.themes' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.tweaklets' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.wizards' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.wizards.preferences' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.intro' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.keys' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.menus' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.operations' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.part' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.plugin' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.preferences' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.presentations' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.progress' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.services' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.splash' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.statushandlers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.swt' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.testing' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.themes' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.views' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.wizards' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='13'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.6.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.help' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.swt' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='[3.4.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface.databinding' range='[1.3.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.databinding.property' range='[1.2.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.databinding.observable' range='[1.2.0,2.0.0)'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
        <required namespace='java.package' name='com.ibm.icu.util' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ui.workbench' version='3.7.1.v20120104-1859'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ui.workbench; singleton:=true&#xA;Bundle-Version: 3.7.1.v20120104-1859
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ui.workbench.texteditor' version='3.7.0.v20110928-1504'>
      <update id='org.eclipse.ui.workbench.texteditor' range='[0.0.0,3.7.0.v20110928-1504)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Text Editor Framework'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='16'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.workbench.texteditor' version='3.7.0.v20110928-1504'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ui.workbench.texteditor' version='3.7.0.v20110928-1504'/>
        <provided namespace='java.package' name='org.eclipse.ui.contentassist' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.texteditor' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.texteditor.quickdiff' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.texteditor.quickdiff.compare.equivalence' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.texteditor.rulers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.texteditor.spelling' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.texteditor' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.texteditor.link' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.texteditor.quickdiff' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.texteditor.rulers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.texteditor.spelling' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.texteditor.templates' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.compare.core' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='[3.4.100,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface.text' range='[3.7.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='[3.5.0,4.0.0)'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ui.workbench.texteditor' version='3.7.0.v20110928-1504'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ui.workbench.texteditor; singleton:=true&#xA;Bundle-Version: 3.7.0.v20110928-1504
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.update.configurator' version='3.3.100.v20100512'>
      <update id='org.eclipse.update.configurator' range='[0.0.0,3.3.100.v20100512)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Install/Update Configurator'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.update.configurator' version='3.3.100.v20100512'/>
        <provided namespace='osgi.bundle' name='org.eclipse.update.configurator' version='3.3.100.v20100512'/>
        <provided namespace='java.package' name='org.eclipse.update.configurator' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.update.internal.configurator' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.update.internal.configurator.branding' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='[3.2.0,4.0.0)'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.update.configurator' version='3.3.100.v20100512'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.update.configurator; singleton:=true&#xA;Bundle-Version: 3.3.100.v20100512
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.hamcrest.core' version='1.1.0.v20090501071000' singleton='false'>
      <update id='org.hamcrest.core' range='[0.0.0,1.1.0.v20090501071000)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Hamcrest Core Library of Matchers'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.hamcrest.core' version='1.1.0.v20090501071000'/>
        <provided namespace='osgi.bundle' name='org.hamcrest.core' version='1.1.0.v20090501071000'/>
        <provided namespace='java.package' name='org.hamcrest' version='1.1.0'/>
        <provided namespace='java.package' name='org.hamcrest.core' version='1.1.0'/>
        <provided namespace='java.package' name='org.hamcrest.internal' version='1.1.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.hamcrest.core' version='1.1.0.v20090501071000'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.hamcrest.core&#xA;Bundle-Version: 1.1.0.v20090501071000
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.junit' version='4.8.2.v4_8_2_v20110321-1705' singleton='false'>
      <update id='org.junit' range='[0.0.0,4.8.2.v4_8_2_v20110321-1705)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='JUnit Testing Framework'/>
        <property name='df_LT.providerName' value='Eclipse Orbit'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='31'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.junit' version='4.8.2.v4_8_2_v20110321-1705'/>
        <provided namespace='osgi.bundle' name='org.junit' version='4.8.2.v4_8_2_v20110321-1705'/>
        <provided namespace='java.package' name='junit.extensions' version='4.8.2'/>
        <provided namespace='java.package' name='junit.framework' version='4.8.2'/>
        <provided namespace='java.package' name='junit.runner' version='4.8.2'/>
        <provided namespace='java.package' name='junit.textui' version='4.8.2'/>
        <provided namespace='java.package' name='org.junit' version='4.8.2'/>
        <provided namespace='java.package' name='org.junit.experimental' version='4.8.2'/>
        <provided namespace='java.package' name='org.junit.experimental.categories' version='4.8.2'/>
        <provided namespace='java.package' name='org.junit.experimental.max' version='4.8.2'/>
        <provided namespace='java.package' name='org.junit.experimental.results' version='4.8.2'/>
        <provided namespace='java.package' name='org.junit.experimental.runners' version='4.8.2'/>
        <provided namespace='java.package' name='org.junit.experimental.theories' version='4.8.2'/>
        <provided namespace='java.package' name='org.junit.experimental.theories.internal' version='4.8.2'/>
        <provided namespace='java.package' name='org.junit.experimental.theories.suppliers' version='4.8.2'/>
        <provided namespace='java.package' name='org.junit.internal' version='4.8.2'/>
        <provided namespace='java.package' name='org.junit.internal.builders' version='4.8.2'/>
        <provided namespace='java.package' name='org.junit.internal.matchers' version='4.8.2'/>
        <provided namespace='java.package' name='org.junit.internal.requests' version='4.8.2'/>
        <provided namespace='java.package' name='org.junit.internal.runners' version='4.8.2'/>
        <provided namespace='java.package' name='org.junit.internal.runners.model' version='4.8.2'/>
        <provided namespace='java.package' name='org.junit.internal.runners.statements' version='4.8.2'/>
        <provided namespace='java.package' name='org.junit.matchers' version='4.8.2'/>
        <provided namespace='java.package' name='org.junit.rules' version='4.8.2'/>
        <provided namespace='java.package' name='org.junit.runner' version='4.8.2'/>
        <provided namespace='java.package' name='org.junit.runner.manipulation' version='4.8.2'/>
        <provided namespace='java.package' name='org.junit.runner.notification' version='4.8.2'/>
        <provided namespace='java.package' name='org.junit.runners' version='4.8.2'/>
        <provided namespace='java.package' name='org.junit.runners.model' version='4.8.2'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.hamcrest.core' range='1.1.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.junit' version='4.8.2.v4_8_2_v20110321-1705'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='zipped'>
            true
          </instruction>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.junit&#xA;Bundle-Version: 4.8.2.v4_8_2_v20110321-1705
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.junit4' version='4.8.1.v20100525' singleton='false'>
      <update id='org.junit4' range='[0.0.0,4.8.1.v20100525)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='JUnit Testing Framework Version 4'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='4'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.junit4' version='4.8.1.v20100525'/>
        <provided namespace='osgi.bundle' name='org.junit4' version='4.8.1.v20100525'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.hamcrest.core' range='1.1.0'/>
        <required namespace='osgi.bundle' name='org.junit' range='4.8.1'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.junit4' version='4.8.1.v20100525'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.junit4&#xA;Bundle-Version: 4.8.1.v20100525
          </instruction>
          <instruction key='zipped'>
            true
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.mortbay.jetty.server' version='6.1.23.v201012071420' singleton='false'>
      <update id='org.mortbay.jetty.server' range='[0.0.0,6.1.23.v201012071420)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='Jetty Server'/>
        <property name='org.eclipse.equinox.p2.description' value='Jetty server core'/>
        <property name='org.eclipse.equinox.p2.provider' value='Mort Bay Consulting'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://jetty.mortbay.org'/>
      </properties>
      <provides size='17'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.mortbay.jetty.server' version='6.1.23.v201012071420'/>
        <provided namespace='osgi.bundle' name='org.mortbay.jetty.server' version='6.1.23.v201012071420'/>
        <provided namespace='java.package' name='org.mortbay.jetty' version='6.1.23'/>
        <provided namespace='java.package' name='org.mortbay.io.nio' version='6.1.23'/>
        <provided namespace='java.package' name='org.mortbay.servlet.jetty' version='6.1.23'/>
        <provided namespace='java.package' name='org.mortbay.io' version='6.1.23'/>
        <provided namespace='java.package' name='org.mortbay.jetty.bio' version='6.1.23'/>
        <provided namespace='java.package' name='org.mortbay.jetty.security' version='6.1.23'/>
        <provided namespace='java.package' name='org.mortbay.jetty.webapp' version='6.1.23'/>
        <provided namespace='java.package' name='org.mortbay.xml' version='6.1.23'/>
        <provided namespace='java.package' name='org.mortbay.jetty.nio' version='6.1.23'/>
        <provided namespace='java.package' name='org.mortbay.jetty.handler' version='6.1.23'/>
        <provided namespace='java.package' name='org.mortbay.resource' version='6.1.23'/>
        <provided namespace='java.package' name='org.mortbay.jetty.servlet' version='6.1.23'/>
        <provided namespace='java.package' name='org.mortbay.io.bio' version='6.1.23'/>
        <provided namespace='java.package' name='org.mortbay.jetty.deployer' version='6.1.23'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='17'>
        <required namespace='java.package' name='org.mortbay.servlet' range='6.1.0'/>
        <required namespace='java.package' name='javax.servlet' range='2.5.0'/>
        <required namespace='java.package' name='org.mortbay.jetty.handler.management' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.servlet.http' range='2.5.0'/>
        <required namespace='java.package' name='javax.net.ssl' range='0.0.0'/>
        <required namespace='java.package' name='org.apache.jasper.servlet' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.servlet.resources' range='2.5.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.servlet.jsp' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.mortbay.component' range='6.1.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.mortbay.util.ajax' range='6.1.0'/>
        <required namespace='java.package' name='org.mortbay.util' range='6.1.0'/>
        <required namespace='java.package' name='javax.security.cert' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.mortbay.thread' range='6.1.0'/>
        <required namespace='java.package' name='org.mortbay.log' range='6.1.0'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.mortbay.jetty.server' version='6.1.23.v201012071420'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.mortbay.jetty.server&#xA;Bundle-Version: 6.1.23.v201012071420
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.mortbay.jetty.util' version='6.1.23.v201012071420' singleton='false'>
      <update id='org.mortbay.jetty.util' range='[0.0.0,6.1.23.v201012071420)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='Jetty Utilities'/>
        <property name='org.eclipse.equinox.p2.description' value='Utility classes for Jetty'/>
        <property name='org.eclipse.equinox.p2.provider' value='Mort Bay Consulting'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://jetty.mortbay.org'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.mortbay.jetty.util' version='6.1.23.v201012071420'/>
        <provided namespace='osgi.bundle' name='org.mortbay.jetty.util' version='6.1.23.v201012071420'/>
        <provided namespace='java.package' name='org.mortbay.log' version='6.1.23'/>
        <provided namespace='java.package' name='org.mortbay.util.ajax' version='6.1.23'/>
        <provided namespace='java.package' name='org.mortbay.servlet' version='6.1.23'/>
        <provided namespace='java.package' name='org.mortbay.thread' version='6.1.23'/>
        <provided namespace='java.package' name='org.mortbay.util' version='6.1.23'/>
        <provided namespace='java.package' name='org.mortbay.component' version='6.1.23'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='java.package' name='org.slf4j' range='1.3.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.servlet' range='0.0.0'/>
        <required namespace='java.package' name='javax.servlet.http' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.mortbay.jetty.util' version='6.1.23.v201012071420'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.mortbay.jetty.util&#xA;Bundle-Version: 6.1.23.v201012071420
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='tooling.org.eclipse.update.feature.default' version='1.0.0' singleton='false'>
      <hostRequirements size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='feature' range='0.0.0' optional='true' multiple='true' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='tooling.org.eclipse.update.feature.default' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='feature' range='0.0.0' optional='true' multiple='true' greedy='false'/>
      </requires>
      <filter>
        (org.eclipse.update.install.features=true)
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='install'>
            installFeature(feature:${artifact},featureId:default,featureVersion:default)
          </instruction>
          <instruction key='uninstall'>
            uninstallFeature(feature:${artifact},featureId:default,featureVersion:default)
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='tooling.osgi.bundle.default' version='1.0.0' singleton='false'>
      <hostRequirements size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='0.0.0' multiple='true' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='tooling.osgi.bundle.default' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='0.0.0' multiple='true' greedy='false'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='unconfigure'>

          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:4);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='tooling.source.default' version='1.0.0' singleton='false'>
      <hostRequirements size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='source' range='0.0.0' optional='true' multiple='true' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='tooling.source.default' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='source' range='0.0.0' optional='true' multiple='true' greedy='false'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='install'>
            addSourceBundle(bundle:${artifact})
          </instruction>
          <instruction key='uninstall'>
            removeSourceBundle(bundle:${artifact})
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingorg.coocox.coide.rcp.product.config.win32.win32.x86' version='0.0.0' singleton='false'>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingorg.coocox.coide.rcp.product.config.win32.win32.x86' version='0.0.0'/>
        <provided namespace='toolingorg.coocox.coide.rcp.product' name='org.coocox.coide.rcp.product.config' version='0.0.0'/>
      </provides>
      <filter>
        (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='unconfigure'>
            setProgramProperty(propName:osgi.splashPath,propValue:);setProgramProperty(propName:eclipse.application,propValue:);setProgramProperty(propName:eclipse.product,propValue:);
          </instruction>
          <instruction key='configure'>
            setProgramProperty(propName:osgi.splashPath,propValue:platform${#58}/base/plugins/org.coocox.coide.rcp);setProgramProperty(propName:eclipse.application,propValue:org.coocox.coide.rcp.application);setProgramProperty(propName:eclipse.product,propValue:org.coocox.coide.rcp.product);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingorg.coocox.coide.rcp.product.configuration' version='0.0.0'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingorg.coocox.coide.rcp.product.configuration' version='0.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86org.eclipse.update.configurator' range='[3.3.100.v20100512,3.3.100.v20100512]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.coocox.coide.rcp.product.config.win32.win32.x86' range='raw:[-M,-M]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
    </unit>
    <unit id='toolingorg.coocox.coide.rcp.product_root.win32.win32.x86' version='0.0.0' singleton='false'>
      <properties size='1'>
        <property name='org.eclipse.pde.build.default' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingorg.coocox.coide.rcp.product_root.win32.win32.x86' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <filter>
        (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='unconfigure'>
            setLauncherName()
          </instruction>
          <instruction key='configure'>
            setLauncherName(name:CoIDE.exe)
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingorg.eclipse.core.runtime' version='3.7.0.v20110110' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.7.0.v20110110,3.7.0.v20110110]' greedy='false'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
        <property name='org.eclipse.pde.build.default' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.core.runtime' version='3.7.0.v20110110'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.7.0.v20110110,3.7.0.v20110110]' greedy='false'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='install'>
            installBundle(bundle:${artifact});
          </instruction>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact});
          </instruction>
          <instruction key='unconfigure'>
            setStartLevel(startLevel:-1);markStarted(started:false);
          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:4);markStarted(started:true);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingorg.eclipse.equinox.common' version='3.6.0.v20110523' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.6.0.v20110523,3.6.0.v20110523]' greedy='false'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
        <property name='org.eclipse.pde.build.default' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.common' version='3.6.0.v20110523'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.6.0.v20110523,3.6.0.v20110523]' greedy='false'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='install'>
            installBundle(bundle:${artifact});
          </instruction>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact});
          </instruction>
          <instruction key='unconfigure'>
            setStartLevel(startLevel:-1);markStarted(started:false);
          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:2);markStarted(started:true);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingorg.eclipse.equinox.launcher' version='1.2.0.v20110502' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.launcher' range='[1.2.0.v20110502,1.2.0.v20110502]' greedy='false'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
        <property name='org.eclipse.pde.build.default' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher' version='1.2.0.v20110502'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.launcher' range='[1.2.0.v20110502,1.2.0.v20110502]' greedy='false'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='install'>
            installBundle(bundle:${artifact});
          </instruction>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact});
          </instruction>
          <instruction key='unconfigure'>
            removeProgramArg(programArg:-startup);removeProgramArg(programArg:@artifact);
          </instruction>
          <instruction key='configure'>
            addProgramArg(programArg:-startup);addProgramArg(programArg:@artifact);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingorg.eclipse.equinox.launcher.win32.win32.x86' version='1.1.100.v20110502' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.launcher.win32.win32.x86' range='[1.1.100.v20110502,1.1.100.v20110502]' greedy='false'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
        <property name='org.eclipse.pde.build.default' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher.win32.win32.x86' version='1.1.100.v20110502'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.launcher.win32.win32.x86' range='[1.1.100.v20110502,1.1.100.v20110502]' greedy='false'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='install'>
            installBundle(bundle:${artifact});
          </instruction>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact});
          </instruction>
          <instruction key='unconfigure'>
            removeProgramArg(programArg:--launcher.library);removeProgramArg(programArg:@artifact);
          </instruction>
          <instruction key='configure'>
            addProgramArg(programArg:--launcher.library);addProgramArg(programArg:@artifact);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingorg.eclipse.osgi' version='3.7.2.v20120110-1415' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='[3.7.2.v20120110-1415,3.7.2.v20120110-1415]' greedy='false'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
        <property name='org.eclipse.pde.build.default' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.osgi' version='3.7.2.v20120110-1415'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='[3.7.2.v20120110-1415,3.7.2.v20120110-1415]' greedy='false'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='install'>
            installBundle(bundle:${artifact});
          </instruction>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact});
          </instruction>
          <instruction key='unconfigure'>
            setStartLevel(startLevel:-1);markStarted(started:false);
          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:-1);markStarted(started:true);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingorg.eclipse.update.configurator' version='3.3.100.v20100512' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.update.configurator' range='[3.3.100.v20100512,3.3.100.v20100512]' greedy='false'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
        <property name='org.eclipse.pde.build.default' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.update.configurator' version='3.3.100.v20100512'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.update.configurator' range='[3.3.100.v20100512,3.3.100.v20100512]' greedy='false'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='install'>
            installBundle(bundle:${artifact});
          </instruction>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact});
          </instruction>
          <instruction key='unconfigure'>
            setStartLevel(startLevel:-1);markStarted(started:false);setProgramProperty(propName:org.eclipse.update.reconcile, propValue:);
          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:4);markStarted(started:true);setProgramProperty(propName:org.eclipse.update.reconcile, propValue:false);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingwin32.win32.x86org.eclipse.update.configurator' version='3.3.100.v20100512' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.update.configurator' range='3.3.100.v20100512'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86org.eclipse.update.configurator' version='3.3.100.v20100512'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='toolingwin32.win32.x86' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.update.configurator' range='3.3.100.v20100512'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='unconfigure'>
            setProgramProperty(propName:org.eclipse.update.reconcile, propValue:);
          </instruction>
          <instruction key='configure'>
            setProgramProperty(propName:org.eclipse.update.reconcile, propValue:false);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
  </units>
  <iusProperties size='170'>
    <iuProperties id='org.coocox.coide.rcp.product' version='0.0.0'>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.coocox.coide.rcp.product_root.win32.win32.x86' version='1.0.0'>
      <properties size='1'>
        <property name='unzipped|@artifact|E:\Inno setup\export\CoIDE' value='E:\Inno setup\export\CoIDE\CoIDE.exe|'/>
      </properties>
    </iuProperties>
  </iusProperties>
</profile>
