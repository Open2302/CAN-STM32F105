<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='profile' timestamp='1413857819723'>
  <properties size='5'>
    <property name='org.eclipse.equinox.p2.installFolder' value='E:\Inno setup\export\CoIDE'/>
    <property name='org.eclipse.equinox.p2.cache' value='E:\Inno setup\export\CoIDE'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='false'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.nl=zh_CN,osgi.ws=win32,osgi.arch=x86,osgi.os=win32'/>
  </properties>
</profile>
